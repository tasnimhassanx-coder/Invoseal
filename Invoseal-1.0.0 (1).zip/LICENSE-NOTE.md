# Licence note

**Invoseal 1.0.0** is sold as source code through the Vibe96 marketplace under the marketplace's standard licence
for purchased source code. In plain words:

* You may install and run Invoseal for your own business and for your own clients, modify it, and rebrand the panel
  (`INVOSEAL_BRAND_*`).
* You may not resell, redistribute or publish the source code (original or modified) as a competing product or template.
* No warranty is given beyond what the marketplace terms state.

## Third-party components

Laravel (MIT), Filament (MIT), Livewire (MIT), mPDF (GPL-2.0-only), bacon/bacon-qr-code (BSD-2-Clause), brick/math (MIT),
Tailwind CSS (MIT), Vite (MIT), Inter Variable font via @fontsource-variable/inter (SIL OFL 1.1). Each keeps its own licence;
see `composer.lock` / `package-lock.json` and the packages' own LICENSE files.

> **mPDF is GPL-2.0-only.** It is used server-side to render PDFs and is not distributed as part of a combined
> proprietary binary by this package, but if you redistribute a bundled copy of Invoseal *with* mPDF, the GPL terms
> of mPDF apply to that copy. If this matters to your use case, ask your lawyer or swap the PDF renderer
> (`app/Services/InvoicePdf.php` is the only place that uses it).

## Regulatory note (important)

Invoseal is software, not legal or tax advice, and it is **not an official ZATCA product or endorsed by ZATCA**.
ZATCA's rules and API change; you are responsible for validating your integration against ZATCA's sandbox and
simulation environments (and, where required, for the registration of your solution) before issuing real invoices.
The product was built and tested without access to ZATCA's servers; see README → "ZATCA compliance status".
