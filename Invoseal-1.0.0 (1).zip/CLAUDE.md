# CLAUDE.md — working on Invoseal

Self-hosted ZATCA Phase 2 e-invoicing gateway. Laravel 12 + Filament 4, PHP 8.3, MySQL 8 / MariaDB (SQLite for tests and local trials).
The application lives in `Laravel Project/`; run every command from there.

## Commands
```bash
composer install && npm ci && npm run build      # npm run build must be re-run after editing resources/css/filament/admin/theme.css
cp .env.example .env && php artisan key:generate
php artisan migrate:fresh --seed                 # DEMO_MODE=true adds fictional demo data
php artisan test                                 # 41 tests, in-memory SQLite, no network
php artisan invoseal:retry-pending | invoseal:check-certificates | invoseal:alert-overdue
```

## Map
* `app/Zatca/` — the ZATCA engine, framework-free where possible:
  `Dto/` (InvoiceData, Party, Line) → `Calculator` (money maths, brick/math, HALF_UP) → `Xml/UblInvoiceBuilder` →
  `Crypto/InvoiceSigner` (hash, ECDSA, XAdES, QR) · `Crypto/CsrGenerator` · `Crypto/CertificateInfo` · `Qr/QrPayload` · `Api/ZatcaClient` · `Validation/InvoiceValidator`.
* `app/Services/` — `InvoiceService` (issue: validate → number chain under `lockForUpdate` → sign → store), `SubmissionService` (clearance/reporting, status machine, retries), `EgsOnboardingService` (CSR → compliance → production), `ArchiveService`, `InvoicePdf`, `AuditLogger`.
* `app/Filament/` — admin panel (resources, widgets, pages). Closure parameters in Filament callbacks must be named `$state`, `$record`, `$get`, `$set`, `$data`, `$query`… or type-hinted with the model class — other names are not injectable.
* `app/Http/` — API controllers, `AuthenticateApiKey` middleware, payload rules. `routes/api.php` is mounted at `/api/v1`.
* `app/Policies/` + `app/Filament/Concerns/ScopedToCompanies.php` — authorisation and company scoping (admin sees all, others only their companies).
* `lang/{en,bn,ar}/invoseal.php` — user-facing messages and validation issue texts. Add an issue code in all three.
* `config/invoseal.php` — product settings (all env-driven).

## Rules that must not break
1. **Hash chain**: ICV/PIH are allocated per EGS unit inside a transaction with `lockForUpdate`. Never renumber, delete or edit an issued invoice (model guard + policy enforce it).
2. **Canonicalisation**: the XML is built compact (no whitespace); the invoice hash is the SHA-256 of the C14N form without `UBLExtensions`, `cac:Signature` and the QR reference. Changing the builder changes hashes — run `tests/Unit/Zatca/SigningTest.php`.
3. **Secrets**: `private_key`, `compliance_secret`, `production_secret`, `webhook_secret` are encrypted with `APP_KEY`. Never log them; never put real keys in fixtures (tests use a throw-away certificate from `App\Support\DemoCertificate`).
4. **Authorisation**: every mutating endpoint/action checks the policy *and* scopes the company. Tests in `AdminPanelTest` and `ApiTest` cover it — extend them with any new write path.
5. **Money**: strings/BigDecimal only; never floats for amounts.

## Conventions
PSR-12 (`vendor/bin/pint` if installed), strict types in `app/Zatca`, English identifiers, small classes, tests next to behaviour. ZATCA wording and code lists follow the official XML Implementation Standard.
