# ZATCA onboarding guide

Invoseal's EGS wizard performs ZATCA's three-step CSID onboarding for one e-invoicing generation solution (EGS) unit.

1. **Prepare** (outside Invoseal): register your taxpayer account on the Fatoora portal. Create an **OTP** for the unit
   (portal → *Onboard new solution unit/device*). OTPs are single-use and short-lived — create it right before step 2.
2. In Invoseal: **EGS Units → New**, pick the company and environment (`Sandbox` = developer portal, `Simulation`, `Production`),
   choose which invoice types the unit will issue (standard / simplified).
3. Open the unit and run, in order:
   * **1 · Generate keys & CSR** — a secp256k1 key pair is created *on your server*; the private key is stored encrypted.
   * **2 · Get compliance certificate** — enter the OTP; Invoseal sends the CSR and stores the compliance CSID.
   * **3 · Run compliance checks** — signed sample invoices (standard/simplified × invoice/credit/debit, for the types you chose) go to ZATCA's compliance checker. All must pass.
   * **4 · Go live** — requests the production CSID. The unit can now issue real invoices for that environment.
4. **Renewal**: the dashboard warns `INVOSEAL_CERT_WARNING_DAYS` (30) days before expiry; use *Renew certificate* with a fresh OTP.

Recommended path: Sandbox → Simulation → Production, each with its own EGS unit.

## Before you issue real invoices
* Validate a handful of invoices of every type with ZATCA's official SDK / the Simulation environment and compare the XML.
* Confirm with ZATCA (or your adviser) whether you must register as a solution provider when you operate Invoseal for third parties.
* Keep the server clock synchronised (NTP) and the queue worker running.

## Known limits (1.0)
SAR only · line-level discounts only · ECDSA certificate signature must fit the 1-byte TLV length (normal ZATCA certificates do) ·
the ZATCA endpoints could not be reached while developing, so the HTTP flow is verified with simulated responses.
