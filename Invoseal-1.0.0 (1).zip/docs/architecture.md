# Architecture

```
ERP / POS / website
        │  JSON (Bearer key)
        ▼
 REST API ──► InvoiceService.issue()
                 1. InvoiceValidator  (36 plain-language checks, EN/BN/AR)
                 2. Calculator        (line/doc totals, brick/math, HALF_UP)
                 3. number chain      (ICV + PIH per EGS unit, DB lock)
                 4. UblInvoiceBuilder (UBL 2.1, compact XML)
                 5. InvoiceSigner     (C14N hash → ECDSA → XAdES → QR)
                 6. store + ArchiveService
                 ▼
        SubmissionService ──► ZatcaClient ──► clearance (B2B) / reporting (B2C)
                 │ transport error → pending + next_retry_at → `invoseal:retry-pending` (every minute)
                 └ result → status, webhook (DeliverWebhookJob), audit log
```

Invoice status: `pending → submitting → cleared | reported | rejected | failed`.
Pending invoices are retried with back-off (1 m, 5 m, 15 m, 1 h, 3 h, 6 h) until `INVOSEAL_RETRY_MAX_HOURS`, then marked `failed`
(still replayable). A simplified invoice must be reported within 24 h — the panel warns at 20 h.

## Data model

```mermaid
erDiagram
  companies ||--o{ branches : has
  companies ||--o{ egs_units : owns
  companies ||--o{ invoices : issues
  companies ||--o{ api_keys : has
  companies }o--o{ users : "company_user"
  egs_units ||--o{ invoices : signs
  invoices ||--|{ invoice_lines : contains
  invoices ||--o{ submissions : "ZATCA attempts"
  invoices ||--o{ webhook_deliveries : notifies
  users ||--o{ audit_logs : acts
```

Full DDL: `database/schema.sql`.

## Security model
* Roles — admin (all), manager (setup + invoices), operator (invoices), viewer (read-only); non-admins only see assigned companies.
* API keys — stored as SHA-256 hashes, shown once, abilities, optional IP/CIDR allowlist, rate limit, revocation; forwarded headers trusted only from `TRUSTED_PROXIES`.
* Secrets — EGS private keys, CSID secrets and webhook secrets are encrypted with `APP_KEY`.
* Invoices are immutable and cannot be deleted during the retention period; every sensitive action is written to the audit log.
