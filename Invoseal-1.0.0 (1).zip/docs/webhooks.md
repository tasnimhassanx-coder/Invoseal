# Webhooks

Set **Webhook URL** on a company (Companies → Edit). Invoseal POSTs JSON when an invoice reaches a final state.

| Event | When |
|---|---|
| `invoice.cleared` | B2B invoice cleared by ZATCA |
| `invoice.reported` | B2C invoice reported |
| `invoice.rejected` | ZATCA rejected it — fix and issue a corrected invoice |
| `invoice.failed` | Gave up after the retry window |

```json
{ "event": "invoice.cleared", "created_at": "2026-11-14T10:15:00+00:00",
  "data": { "uuid": "…", "invoice_number": "INV-1001", "external_reference": "ERP-77", "type": "standard",
            "sub_type": "invoice", "status": "cleared", "total": "230.00", "vat": "30.00",
            "invoice_hash": "…", "has_warnings": false, "error": null } }
```

Verify the signature (PHP):
```php
[$t, $v1] = array_map(fn ($p) => explode('=', $p, 2)[1], explode(',', $_SERVER['HTTP_X_INVOSEAL_SIGNATURE']));
$ok = hash_equals(hash_hmac('sha256', $t.'.'.file_get_contents('php://input'), $secret), $v1) && abs(time() - (int) $t) < 300;
```
Answer with any 2xx. Other answers are retried after 30 s, 2 min, 10 min, 1 h, 4 h; failed deliveries can be redelivered from *Webhook Deliveries*.
