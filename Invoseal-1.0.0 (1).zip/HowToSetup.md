# How to set up Invoseal

Two supported ways: **A) a VPS** (Ubuntu 22.04/24.04, Nginx + PHP-FPM) or **B) Docker**. Pick one.
Requirements: PHP 8.3 (extensions: `mbstring intl gd zip xml curl bcmath openssl pdo_mysql`), MySQL 8 / MariaDB 10.6+,
Composer 2, Node 20+ (only to build the CSS/JS once), outbound HTTPS to `gw-fatoora.zatca.gov.sa`.
Minimum server: 1 vCPU, 1 GB RAM, 10 GB disk. The server clock must be accurate (NTP) — ZATCA checks timestamps.

The application is the folder **`Laravel Project/`**. On the server we call it `/var/www/invoseal` (rename the folder when you upload it).

---

## A) VPS (Nginx + PHP-FPM + Supervisor + cron)

### 1. Packages
```bash
sudo apt update && sudo apt install -y nginx mysql-server unzip git supervisor certbot python3-certbot-nginx \
  php8.3-fpm php8.3-cli php8.3-mysql php8.3-mbstring php8.3-intl php8.3-gd php8.3-zip php8.3-xml php8.3-curl php8.3-bcmath
curl -sS https://getcomposer.org/installer | php && sudo mv composer.phar /usr/local/bin/composer
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt install -y nodejs
```

### 2. Database
```bash
sudo mysql <<'SQL'
CREATE DATABASE invoseal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'invoseal'@'localhost' IDENTIFIED BY 'a-long-random-password';
GRANT ALL PRIVILEGES ON invoseal.* TO 'invoseal'@'localhost';
SQL
```
Two ways to create the tables — use **one**:
* **Recommended:** `php artisan migrate --force` (step 4).
* **Plain SQL:** `mysql invoseal < database/schema.sql` then (optional) `mysql invoseal < database/seed.sql`. The schema file also records the migrations, so `php artisan migrate` later only applies newer ones.

### 3. Upload and install
```bash
sudo mkdir -p /var/www/invoseal && sudo chown $USER: /var/www/invoseal
# upload the contents of "Laravel Project/" into /var/www/invoseal, then:
cd /var/www/invoseal
composer install --no-dev --optimize-autoloader
npm ci && npm run build            # builds public/build (the admin theme)
cp .env.example .env && php artisan key:generate
```
Edit `.env`: `APP_URL`, `DB_*`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `INVOSEAL_BRAND_*`. **Back up `APP_KEY`** — without it the encrypted
ZATCA private keys cannot be read.

### 4. Migrate, first administrator, permissions
```bash
php artisan migrate --force
php artisan db:seed --force        # creates the admin from ADMIN_EMAIL / ADMIN_PASSWORD (a random password is printed if you leave it empty)
php artisan config:cache && php artisan route:cache && php artisan view:cache
sudo chown -R www-data:www-data storage bootstrap/cache && sudo chmod -R ug+rwX storage bootstrap/cache
```

### 5. Nginx
`/etc/nginx/sites-available/invoseal`:
```nginx
server {
    server_name invoseal.example.com;
    root /var/www/invoseal/public;
    index index.php;
    client_max_body_size 20M;
    location / { try_files $uri $uri/ /index.php?$query_string; }
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    }
    location ~ /\.(?!well-known) { deny all; }
}
```
```bash
sudo ln -s /etc/nginx/sites-available/invoseal /etc/nginx/sites-enabled/ && sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d invoseal.example.com        # HTTPS (required for production)
```

### 6. Queue worker and scheduler (do not skip — retries, webhooks and alerts depend on them)
`/etc/supervisor/conf.d/invoseal-worker.conf`:
```ini
[program:invoseal-worker]
command=php /var/www/invoseal/artisan queue:work --sleep=3 --tries=3 --max-time=3600
user=www-data
autostart=true
autorestart=true
stopwaitsecs=3600
stdout_logfile=/var/log/invoseal-worker.log
```
```bash
sudo supervisorctl reread && sudo supervisorctl update
sudo crontab -u www-data -e      # add:
* * * * * php /var/www/invoseal/artisan schedule:run >> /dev/null 2>&1
```

### 7. Sign in
Open `https://invoseal.example.com/admin` and sign in with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` you set.
(If you imported `database/seed.sql` instead: `admin@invoseal.test` / `password` — **change it immediately** under *Users*.)

---

## B) Docker

```bash
# in the package root (where docker-compose.yml is)
cp "Laravel Project/.env.example" .env
docker compose run --rm --no-deps -e APP_KEY=x app php artisan key:generate --show   # copy the printed key into .env as APP_KEY=
# edit .env: APP_URL, DB_PASSWORD (required), ADMIN_EMAIL, ADMIN_PASSWORD
docker compose up -d --build
```
The stack: `web` (nginx, port `WEB_PORT`, default 8080) · `app` (php-fpm; runs migrations and seeds the first admin on start) ·
`queue` (worker) · `scheduler` (runs `schedule:run` every minute) · `db` (MySQL 8, data in the `dbdata` volume).
Open `http://localhost:8080/admin`. Put a TLS-terminating proxy (Caddy, Traefik, Nginx, a cloud LB) in front for production and set
`TRUSTED_PROXIES` in `.env` to its address.

Useful: `docker compose logs -f app queue` · `docker compose exec app php artisan invoseal:retry-pending` ·
backup `docker compose exec db sh -c 'mysqldump -u"$MYSQL_USER" -p"$MYSQL_PASSWORD" "$MYSQL_DATABASE"' > backup.sql`.

---

## Branding
In `.env`: `INVOSEAL_BRAND_NAME="Your Company"`, `INVOSEAL_BRAND_COLOR=#0f766e`, optional `INVOSEAL_BRAND_LOGO=images/logo.svg`
(a file you place in `public/images/`). Then `php artisan config:cache`. The favicon is `public/images/favicon.svg`.
For deeper theme changes edit `resources/css/filament/admin/theme.css` and run `npm run build`.

## First steps after login
1. **Companies → New**: legal name, 15-digit VAT number (starts and ends with 3), CR number, national address (building no. 4 digits, postal code 5 digits).
2. **EGS Units → New**, open it and walk through the wizard: *Generate keys & CSR* → *Get compliance certificate* (needs the OTP from the Fatoora portal) → *Run compliance checks* → *Go live*. Start with the **Sandbox** environment. See `docs/zatca-onboarding.md`.
3. **API Keys → Create API key**, copy the key (shown once) into your ERP, and `POST /api/v1/invoices` (see `docs/openapi.yaml`).
4. Optional: set a **webhook URL** on the company to be told when invoices are cleared/reported/rejected.
5. Create more **Users** (admin / manager / operator / viewer) and assign them to companies.

## Demo mode (never in production)
`DEMO_MODE=true php artisan migrate:fresh --seed --force` creates a fictional company, a throw-away (non-ZATCA) certificate and ~40 invoices
whose ZATCA answers are simulated (the onboarding wizard and invoice clearance/reporting work end-to-end without any ZATCA account); the login form is pre-filled with `admin@invoseal.test` / `password`, user management is locked and `php artisan invoseal:demo-reset` (scheduled nightly at 03:00) rebuilds the data. A ready-to-upload demo bundle with `vendor/` and a SQLite database (no Composer/MySQL needed) is available separately as `Invoseal-demo.zip`.

## Upgrading / backups
* Back up the database **and** `.env` (APP_KEY) and `storage/app` (archived XML/PDF).
* Upgrade: replace the files, `composer install --no-dev -o && npm ci && npm run build && php artisan migrate --force && php artisan optimize && sudo supervisorctl restart invoseal-worker`.
* Invoices are legal records: do not truncate the `invoices` table; the app refuses to delete invoices inside the retention period (`INVOSEAL_RETENTION_YEARS`).

## Troubleshooting
| Symptom | Fix |
|---|---|
| 500 error / blank page | `storage/` and `bootstrap/cache` writable by the web user; check `storage/logs/laravel.log`. |
| Panel has no styling | `npm run build` was not run (Docker does it for you). |
| "No payload / decryption error" on an EGS unit | `APP_KEY` changed. Restore the original key. |
| Invoices stay *Pending* | Queue worker / cron not running, or the server cannot reach `gw-fatoora.zatca.gov.sa` (firewall). `php artisan invoseal:retry-pending` shows what happens. |
| API key IP allowlist blocks you behind a proxy | Set `TRUSTED_PROXIES` so the real client IP is used. |
| Compliance step fails with an OTP error | OTPs are single-use and expire in about an hour; create a new one in the Fatoora portal. |
