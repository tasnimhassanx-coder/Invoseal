#!/bin/sh
set -e
cd /var/www/html

if [ -z "$APP_KEY" ]; then
  echo "ERROR: APP_KEY is empty. Generate one with:  docker compose run --rm --no-deps -e APP_KEY=x app php artisan key:generate --show" >&2
  echo "       then put it into .env (APP_KEY=base64:...). Keep a backup: it encrypts the ZATCA private keys." >&2
  exit 1
fi

# Only the web container (php-fpm) prepares the database; queue and scheduler wait for it.
if [ "$1" = "php-fpm" ]; then
  echo "Waiting for the database..."
  i=0
  until php -r 'try { new PDO("mysql:host=".getenv("DB_HOST").";port=".(getenv("DB_PORT")?:3306).";dbname=".getenv("DB_DATABASE"), getenv("DB_USERNAME"), getenv("DB_PASSWORD")); } catch (Throwable $e) { fwrite(STDERR, $e->getMessage()."\n"); exit(1); }' 2>/dev/null; do
    i=$((i+1)); [ $i -gt 60 ] && { echo "Database not reachable" >&2; exit 1; }; sleep 2
  done
  php artisan migrate --force
  php artisan storage:link --force >/dev/null 2>&1 || true
  php artisan config:cache && php artisan route:cache && php artisan view:cache && php artisan event:cache
  if [ "$(php artisan tinker --execute='echo App\Models\User::count();' 2>/dev/null | tail -n1)" = "0" ]; then
    php artisan db:seed --force
  fi
else
  sleep 15   # give the web container time to run migrations
  php artisan config:cache
fi

chown -R www-data:www-data storage bootstrap/cache
exec "$@"
