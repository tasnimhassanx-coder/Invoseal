# Changelog

## 1.0.0 — 2026-11-14

First release.

* REST API (invoices create/validate/list/show/xml/pdf/retry), API keys with abilities, IP allowlist, rate limit, idempotency.
* ZATCA Phase 2 core: UBL 2.1 builder, ICV/PIH hash chain, ECDSA signature, XAdES SignedProperties, TLV QR, CSR generator.
* Clearance (B2B) and reporting (B2C) clients, compliance CSID → production CSID onboarding and renewal.
* Pre-validation with plain-language errors in English, Bengali and Arabic.
* Retry queue with back-off, scheduler commands (retry, certificate expiry, overdue reporting), webhooks with HMAC signature.
* Archive: immutable invoices, signed XML, bilingual PDF/A-3 with embedded XML, integrity verification.
* Filament 4 admin panel: dashboard, invoices, onboarding wizard, companies/branches/EGS units, API keys, users, audit log, webhook deliveries; light/dark theme.
* Multi-company with roles (admin, manager, operator, viewer) and per-company scoping.
* Demo mode: simulated ZATCA gateway, locked user management, nightly `invoseal:demo-reset`.
* Docker stack, MySQL schema + seed, OpenAPI spec, 41 automated tests.

Planned: 1.1 UAE PINT-AE profile.
