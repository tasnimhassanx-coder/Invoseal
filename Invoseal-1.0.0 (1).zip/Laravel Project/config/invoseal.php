<?php

return [
    'name' => env('INVOSEAL_NAME', 'Invoseal'),
    'version' => '1.0.0',

    // Branding of the admin panel
    'brand' => [
        'name' => env('INVOSEAL_BRAND_NAME', 'Invoseal'),
        'color' => env('INVOSEAL_BRAND_COLOR', '#0f766e'),
        'logo' => env('INVOSEAL_BRAND_LOGO'),         // optional path under /public
    ],

    // 'sync' = the API call returns once ZATCA answered; 'async' = returns immediately, the queue submits.
    'submission_mode' => env('INVOSEAL_SUBMISSION_MODE', 'sync'),

    // Years a tax document has to stay archived (KSA: at least 6)
    'retention_years' => (int) env('INVOSEAL_RETENTION_YEARS', 6),

    // Retry schedule (seconds) for transport errors / ZATCA downtime; the invoice is marked failed afterwards.
    'retry_backoff' => [60, 300, 900, 3600, 10800, 21600],
    'retry_max_hours' => (int) env('INVOSEAL_RETRY_MAX_HOURS', 168),

    // Warn about certificates that expire within this many days
    'certificate_warning_days' => (int) env('INVOSEAL_CERT_WARNING_DAYS', 30),

    // Simplified invoices must be reported within 24h; warn after this many hours
    'reporting_warning_hours' => 20,

    // API
    'api_rate_limit' => (int) env('INVOSEAL_API_RATE_LIMIT', 120), // requests per minute per key

    // Gateway override (leave empty to use the official ZATCA URLs for the company's environment)
    'zatca_base_url' => env('ZATCA_BASE_URL'),
    'zatca_timeout' => (int) env('ZATCA_TIMEOUT', 30),

    // Demo mode: pre-fills the login form with the demo account (never enable in production)
    'demo_mode' => (bool) env('DEMO_MODE', false),
    'demo_email' => env('DEMO_EMAIL', 'admin@invoseal.test'),
    'demo_password' => env('DEMO_PASSWORD', 'password'),

    // First administrator created by `php artisan db:seed`
    'admin' => [
        'name' => env('ADMIN_NAME', 'Administrator'),
        'email' => env('ADMIN_EMAIL'),
        'password' => env('ADMIN_PASSWORD'),
    ],

    'archive_disk' => env('INVOSEAL_ARCHIVE_DISK', 'local'),
];
