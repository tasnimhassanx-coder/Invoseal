@php
    $s = $getRecord()->status;
    $order = ['draft' => 0, 'csr_ready' => 1, 'compliance_issued' => 2, 'compliance_passed' => 3, 'active' => 4, 'expired' => 4, 'revoked' => 4];
    $at = $order[$s->value] ?? 0;
    $steps = ['Generate keys & CSR', 'Compliance certificate', 'Compliance checks', 'Production certificate'];
@endphp
<ol class="inv-steps">
    @foreach($steps as $i => $label)
        @php($state = $at > $i ? 'done' : ($at === $i ? 'current' : 'todo'))
        <li class="inv-step inv-step-{{ $state }}">
            <span class="inv-step-dot">@if($state === 'done')✓@else{{ $i + 1 }}@endif</span>
            <span class="inv-step-label">{{ $label }}</span>
        </li>
    @endforeach
</ol>
@if($s->value === 'active')
    <p class="inv-step-note">This unit is live and signing invoices.</p>
@elseif($s->value === 'expired')
    <p class="inv-step-note" style="color:#e11d48">The production certificate has expired. Renew it before issuing invoices.</p>
@endif
