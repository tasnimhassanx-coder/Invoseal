@php
    $raw = $getRecord()->finalXml();
    $doc = new \DOMDocument('1.0', 'UTF-8');
    $doc->preserveWhiteSpace = false;
    $doc->formatOutput = true;
    $pretty = @$doc->loadXML($raw, LIBXML_NONET) ? $doc->saveXML() : $raw;
@endphp
<pre class="inv-mono" style="max-height: 28rem; overflow: auto; padding: 1rem; border-radius: .8rem; background: rgb(15 23 42 / .04); white-space: pre; word-break: normal;">{{ $pretty }}</pre>
