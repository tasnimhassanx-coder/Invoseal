@php($payload = $getRecord()->qr_code)
<div class="inv-qr" title="ZATCA TLV QR">{!! \App\Support\QrImage::svg($payload, 168, 0) !!}</div>
