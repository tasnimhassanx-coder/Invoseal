@php($results = $getRecord()->compliance_results ?? [])
@if(!$results)
    <p style="color:var(--gray-500);font-size:.875rem">Run step 3 to see how ZATCA's compliance checker rates each sample invoice.</p>
@else
    <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:.55rem">
        @foreach($results as $r)
            <li>
                <div style="display:flex;gap:.5rem;align-items:center">
                    <span style="display:inline-flex;width:1.2rem;height:1.2rem;border-radius:999px;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;color:#fff;background:{{ $r['passed'] ? '#10b981' : '#f43f5e' }}">{{ $r['passed'] ? '✓' : '✕' }}</span>
                    <span style="font-size:.875rem;font-weight:500">{{ $r['label'] }}</span>
                </div>
                @foreach($r['messages'] ?? [] as $m)
                    <div style="margin-inline-start:1.7rem;font-size:.76rem;color:var(--gray-500)">{{ $m }}</div>
                @endforeach
            </li>
        @endforeach
    </ul>
@endif
