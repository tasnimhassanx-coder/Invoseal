<ul style="display:flex;flex-direction:column;gap:.6rem;list-style:none;padding:0;margin:0">
    @foreach($labels as $key => $label)
        @php($ok = $checks[$key] ?? false)
        <li style="display:flex;align-items:center;gap:.6rem">
            <span style="display:inline-flex;width:1.35rem;height:1.35rem;border-radius:999px;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:#fff;background:{{ $ok ? '#10b981' : '#f43f5e' }}">{{ $ok ? '✓' : '✕' }}</span>
            <span>{{ $label }}</span>
        </li>
    @endforeach
</ul>
