@if (config('invoseal.demo_mode'))
    <div class="inv-demo-banner">Live demo · fictional data · ZATCA is simulated · resets every night</div>
@endif
