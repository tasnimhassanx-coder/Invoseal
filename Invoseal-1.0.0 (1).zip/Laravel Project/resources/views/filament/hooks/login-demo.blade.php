@if (config('invoseal.demo_mode'))
    <div class="inv-demo-note">
        <strong>Live demo</strong>
        <span>Sign in as <code>admin@invoseal.test</code> / <code>password</code> — data resets nightly.</span>
    </div>
@endif
