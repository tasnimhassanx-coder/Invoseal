@php
    $isStd = $i->type === 'standard';
    $title = match ($i->sub_type) {
        'credit_note' => ['Credit Note', 'إشعار دائن'],
        'debit_note' => ['Debit Note', 'إشعار مدين'],
        default => $isStd ? ['Tax Invoice', 'فاتورة ضريبية'] : ['Simplified Tax Invoice', 'فاتورة ضريبية مبسطة'],
    };
    $money = fn ($v) => number_format((float) $v, 2);
@endphp
<style>
    body { font-family: dejavusans, sans-serif; font-size: 9.5pt; color: #0f172a; }
    h1 { font-size: 17pt; margin: 0; color: #0f766e; }
    .ar { direction: rtl; font-size: 11pt; color: #334155; }
    .muted { color: #64748b; }
    table { border-collapse: collapse; width: 100%; }
    .meta td { padding: 3px 0; vertical-align: top; }
    .lines th { background: #0f766e; color: #fff; padding: 6px 5px; font-size: 8.5pt; text-align: left; }
    .lines td { padding: 6px 5px; border-bottom: 0.5pt solid #e2e8f0; }
    .r { text-align: right; }
    .totals td { padding: 4px 6px; }
    .grand td { font-weight: bold; font-size: 11pt; border-top: 1pt solid #0f766e; }
    .box { border: 0.5pt solid #cbd5e1; padding: 8px; }
    .badge { background: #ecfdf5; color: #047857; padding: 2px 8px; font-size: 8pt; }
</style>

<table>
    <tr>
        <td style="width:62%">
            <h1>{{ $title[0] }}</h1>
            <div class="ar">{{ $title[1] }}</div>
        </td>
        <td class="r" style="width:38%">
            <div style="font-size:12pt;font-weight:bold">{{ $c->name }}</div>
            @if($c->name_ar)<div class="ar" style="text-align:right">{{ $c->name_ar }}</div>@endif
            <div class="muted">{{ $c->addressLine() }}</div>
            <div class="muted">VAT / الرقم الضريبي: {{ $c->vat_number }}</div>
            @if($c->crn)<div class="muted">CR / السجل التجاري: {{ $c->crn }}</div>@endif
        </td>
    </tr>
</table>
<br>
<table class="meta">
    <tr>
        <td style="width:50%">
            <b>Invoice No. / رقم الفاتورة:</b> {{ $i->invoice_number }}<br>
            <b>Issue date / تاريخ الإصدار:</b> <span dir="ltr">{{ $i->issue_date->format("Y-m-d") }} {{ substr((string) $i->issue_time, 0, 8) }}</span><br>
            @if($i->billing_reference)<b>Original invoice / الفاتورة الأصلية:</b> {{ $i->billing_reference }}<br>@endif
            @if($i->reason)<b>Reason / السبب:</b> {{ $i->reason }}<br>@endif
            <span class="badge">{{ strtoupper($i->status->value) }}</span>
        </td>
        <td style="width:50%">
            <b>Buyer / المشتري:</b> {{ $i->buyer_name ?: '—' }}<br>
            @if($i->buyer_vat)<b>VAT / الرقم الضريبي:</b> {{ $i->buyer_vat }}<br>@endif
            @if(!empty($i->buyer['street']))
                <span class="muted">{{ trim(($i->buyer['building'] ?? '').' '.$i->buyer['street'].', '.($i->buyer['district'] ?? '').', '.($i->buyer['city'] ?? '').' '.($i->buyer['postal_zone'] ?? '')) }}</span>
            @endif
        </td>
    </tr>
</table>
<br>
<table class="lines">
    <thead>
        <tr>
            <th style="width:4%">#</th>
            <th style="width:36%">Item / الصنف</th>
            <th class="r" style="width:9%">Qty</th>
            <th class="r" style="width:13%">Unit price</th>
            <th class="r" style="width:10%">Discount</th>
            <th class="r" style="width:9%">VAT %</th>
            <th class="r" style="width:9%">VAT</th>
            <th class="r" style="width:13%">Total</th>
        </tr>
    </thead>
    <tbody>
    @foreach($i->lines as $l)
        <tr>
            <td>{{ $l->line_no }}</td>
            <td>{{ $l->name }}</td>
            <td class="r">{{ rtrim(rtrim(number_format((float) $l->quantity, 6, '.', ''), '0'), '.') }}</td>
            <td class="r">{{ $money($l->unit_price) }}</td>
            <td class="r">{{ $money($l->discount) }}</td>
            <td class="r">{{ $money($l->tax_percent) }}</td>
            <td class="r">{{ $money($l->tax) }}</td>
            <td class="r">{{ $money($l->gross) }}</td>
        </tr>
    @endforeach
    </tbody>
</table>
<br>
<table>
    <tr>
        <td style="width:50%;vertical-align:top">
            @if($qr)
                <div class="box" style="width:42mm;text-align:center">
                    <img src="{{ \App\Support\QrImage::dataUri($qr, 300) }}" width="132" height="132" />
                </div>
                <div class="muted" style="font-size:7.5pt">ZATCA QR / رمز الاستجابة السريعة</div>
            @endif
        </td>
        <td style="width:50%">
            <table class="totals">
                <tr><td>Subtotal (excl. VAT) / المجموع بدون ضريبة</td><td class="r">{{ $money($i->tax_exclusive) }} {{ $i->currency }}</td></tr>
                <tr><td>VAT / ضريبة القيمة المضافة</td><td class="r">{{ $money($i->tax_amount) }} {{ $i->currency }}</td></tr>
                <tr class="grand"><td>Total / الإجمالي</td><td class="r">{{ $money($i->tax_inclusive) }} {{ $i->currency }}</td></tr>
            </table>
        </td>
    </tr>
</table>
<br>
<div class="muted" style="font-size:7.5pt">
    UUID {{ $i->uuid }} · ICV {{ $i->icv }} · Hash {{ $i->invoice_hash }}<br>
    The signed ZATCA XML is embedded in this PDF (PDF/A-3). Generated by Invoseal.
</div>
