<span class="inv-brand">
    <svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="invg" x1="4" y1="2" x2="36" y2="38" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#14b8a6"/><stop offset="1" stop-color="#0f766e"/>
            </linearGradient>
        </defs>
        <path d="M20 2.5 34.5 8v10.6c0 9.2-6 16.3-14.5 19-8.5-2.7-14.5-9.8-14.5-19V8L20 2.5Z" fill="url(#invg)"/>
        <path d="M12.5 20.5 18 26l10-11.5" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <span class="inv-brand-name">{{ config('invoseal.brand.name') }}</span>
</span>
