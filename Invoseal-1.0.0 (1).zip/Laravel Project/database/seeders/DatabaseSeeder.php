<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(AdminSeeder::class);

        if (config('invoseal.demo_mode')) {
            $this->call(DemoSeeder::class);
        }
    }
}
