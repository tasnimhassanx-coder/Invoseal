<?php

namespace Database\Seeders;

use App\Enums\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

/**
 * Creates the first administrator from ADMIN_EMAIL / ADMIN_PASSWORD.
 * In demo mode the well-known demo account is used. Otherwise, if no password is configured,
 * a random one is generated and printed once — there is never a default password in production.
 */
class AdminSeeder extends Seeder
{
    public function run(): void
    {
        $demo = (bool) config('invoseal.demo_mode');
        $email = config('invoseal.admin.email') ?: ($demo ? config('invoseal.demo_email') : 'admin@example.com');
        $password = config('invoseal.admin.password') ?: ($demo ? config('invoseal.demo_password') : null);

        $generated = false;
        if (! $password) {
            $password = Str::password(16, symbols: false);
            $generated = true;
        }

        User::updateOrCreate(['email' => $email], [
            'name' => config('invoseal.admin.name') ?: 'Administrator',
            'password' => $password,
            'role' => Role::Admin,
            'is_active' => true,
            'locale' => 'en',
            'email_verified_at' => now(),
        ]);

        if ($generated && $this->command) {
            $this->command->warn("Administrator created: {$email}  /  {$password}   (shown once — change it after signing in)");
        }
    }
}
