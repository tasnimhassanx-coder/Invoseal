<?php

namespace Database\Seeders;

use App\Enums\EgsStatus;
use App\Enums\Role;
use App\Models\ApiKey;
use App\Models\Branch;
use App\Models\Company;
use App\Models\EgsUnit;
use App\Models\Invoice;
use App\Models\User;
use App\Services\InvoiceService;
use App\Support\DemoCertificate;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Http;

/**
 * Demo data: a fictional Riyadh company, an EGS unit holding a throw-away (non-ZATCA) certificate and
 * ~40 invoices. ZATCA answers are simulated with Http::fake() so the full pipeline runs offline.
 * Everything here is fictional and clearly marked as demo data. Never run in production.
 */
class DemoSeeder extends Seeder
{
    public function run(): void
    {
        if (Company::where('vat_number', '300000000000003')->exists()) {
            return;
        }
        \App\Support\DemoZatcaSimulator::$paused = true;

        $company = Company::create([
            'name' => 'Al Noor Trading Co. (Demo)', 'name_ar' => 'شركة النور التجارية (تجريبي)',
            'vat_number' => '300000000000003', 'crn' => '1010000000', 'id_scheme' => 'CRN',
            'business_category' => 'Supply activities', 'street' => 'Prince Sultan Road', 'building_number' => '3242',
            'plot_identification' => '4533', 'district' => 'Al Murabba', 'city' => 'Riyadh', 'postal_zone' => '12222',
            'country' => 'SA', 'environment' => 'sandbox', 'is_active' => true,
            'webhook_secret' => 'whsec_demo_'.bin2hex(random_bytes(12)),
        ]);
        $branch = Branch::create(['company_id' => $company->id, 'name' => 'Riyadh HQ']);

        $cert = DemoCertificate::make($company->vat_number, $company->name);
        $egs = EgsUnit::create([
            'company_id' => $company->id, 'branch_id' => $branch->id, 'name' => 'POS-01 · Showroom', 'environment' => 'sandbox',
            'invoice_types' => '1100', 'status' => EgsStatus::Active,
            'private_key' => $cert['private_key'],
            'production_certificate' => base64_encode(preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $cert['certificate'])),
            'production_secret' => 'demo-secret', 'certificate_expires_at' => now()->addMonths(11), 'onboarded_at' => now()->subDays(20), 'last_icv' => 0,
        ]);
        // A second unit that is still being onboarded, so the wizard is visible in the demo.
        EgsUnit::create([
            'company_id' => $company->id, 'branch_id' => $branch->id, 'name' => 'POS-02 · Warehouse', 'environment' => 'sandbox',
            'invoice_types' => '1100', 'status' => EgsStatus::Draft,
        ]);

        ApiKey::issue($company, 'ERP integration (demo)', ApiKey::ABILITIES);

        $viewer = User::updateOrCreate(['email' => 'viewer@invoseal.test'], [
            'name' => 'Demo Viewer', 'password' => config('invoseal.demo_password'), 'role' => Role::Viewer, 'is_active' => true, 'locale' => 'en',
        ]);
        $viewer->companies()->sync([$company->id]);

        $this->invoices($company, $egs);
        \App\Support\DemoZatcaSimulator::$paused = false;
    }

    private function invoices(Company $company, EgsUnit $egs): void
    {
        $svc = app(InvoiceService::class);
        $buyers = [
            ['name' => 'Riyadh Builders Co.', 'vat' => '310000000000003', 'street' => 'King Fahd Road', 'building' => '1234', 'district' => 'Olaya', 'city' => 'Riyadh', 'postal_zone' => '11564'],
            ['name' => 'Jeddah Medical Supplies', 'vat' => '320000000000003', 'street' => 'Tahlia Street', 'building' => '5678', 'district' => 'Al Rawdah', 'city' => 'Jeddah', 'postal_zone' => '23434'],
            ['name' => 'Dammam Logistics LLC', 'vat' => '330000000000003', 'street' => 'Prince Mohammed Road', 'building' => '4321', 'district' => 'Al Faisaliyah', 'city' => 'Dammam', 'postal_zone' => '32245'],
        ];
        $items = [
            ['Office chair (ergonomic)', 480, 'S'], ['A4 paper, 5 reams', 96, 'S'], ['Laptop 14"', 3250, 'S'], ['Printer toner', 310, 'S'],
            ['Standing desk', 1450, 'S'], ['Wireless keyboard', 135, 'S'], ['Delivery (export)', 250, 'Z'], ['Training book (zero-rated)', 85, 'Z'],
        ];
        mt_srand(96);
        $n = 0;
        $mode = 'report';
        $ok = fn (array $extra) => ['validationResults' => ['status' => 'PASS', 'warningMessages' => [], 'errorMessages' => []]] + $extra;
        Http::fake(function () use (&$mode, $ok) {
            return match ($mode) {
                'reject' => Http::response(['validationResults' => ['status' => 'ERROR', 'warningMessages' => [], 'errorMessages' => [[
                    'type' => 'ERROR', 'code' => 'BR-KSA-F-06-C23', 'category' => 'KSA', 'message' => 'Demo: simulated ZATCA rejection (invalid buyer address).', 'status' => 'ERROR']]]], 400),
                'clear_warn' => Http::response(['clearanceStatus' => 'CLEARED', 'clearedInvoice' => base64_encode('<Invoice>demo</Invoice>'), 'validationResults' => ['status' => 'WARNING', 'errorMessages' => [],
                    'warningMessages' => [['type' => 'WARNING', 'code' => 'BR-KSA-98', 'category' => 'KSA', 'message' => 'Demo warning: buyer identification scheme not recommended.', 'status' => 'WARNING']]]], 200),
                'clear' => Http::response($ok(['clearanceStatus' => 'CLEARED', 'clearedInvoice' => base64_encode('<Invoice>demo</Invoice>')]), 200),
                'down' => Http::response('Service Unavailable', 503),
                default => Http::response($ok(['reportingStatus' => 'REPORTED']), 200),
            };
        });

        for ($day = 13; $day >= 0; $day--) {
            $count = $day === 0 ? 3 : mt_rand(2, 4);
            for ($i = 0; $i < $count; $i++) {
                $n++;
                $standard = $n % 3 === 0;
                $lines = [];
                foreach ((array) array_rand($items, mt_rand(1, 3)) as $k) {
                    [$name, $price, $cat] = $items[$k];
                    $lines[] = ['name' => $name, 'quantity' => mt_rand(1, 4), 'unit_price' => $price,
                        'tax_category' => $cat, 'tax_percent' => $cat === 'S' ? 15 : 0,
                        'exemption_code' => $cat === 'Z' ? 'VATEX-SA-32' : null, 'exemption_reason' => $cat === 'Z' ? 'Export of goods' : null];
                }
                $date = now('Asia/Riyadh')->subDays($day);
                // simulate ZATCA: mostly accepted, a few warnings, one rejection
                $reject = $n === 12;
                $mode = $reject ? 'reject' : ($standard ? ($n % 7 === 0 ? 'clear_warn' : 'clear') : 'report');
                $payload = [
                    'invoice_number' => sprintf('INV-%s-%04d', $date->format('ym'), $n),
                    'external_reference' => 'DEMO-'.$n,
                    'issue_date' => $date->format('Y-m-d'),
                    'issue_time' => sprintf('%02d:%02d:%02d', mt_rand(9, 20), mt_rand(0, 59), mt_rand(0, 59)),
                    'buyer' => $standard ? $buyers[$n % 3] : ['name' => ''],
                    'lines' => $lines,
                ];
                $r = $svc->issue($company, $payload, $egs);
                if ($r->invoice) {
                    Invoice::whereKey($r->invoice->id)->update(['created_at' => $date, 'updated_at' => $date]);
                }
            }
        }

        $mode = 'report';
        // one credit note against the first invoice
        $first = Invoice::where('company_id', $company->id)->where('type', 'simplified')->where('status', 'reported')->orderBy('id')->first();
        if ($first) {
            $svc->issue($company, [
                'invoice_number' => 'CN-'.now()->format('ym').'-0001', 'sub_type' => 'credit_note', 'billing_reference' => $first->invoice_number,
                'reason' => 'Returned goods', 'buyer' => ['name' => ''],
                'lines' => [['name' => 'Returned item', 'quantity' => 1, 'unit_price' => 100, 'tax_category' => 'S', 'tax_percent' => 15]],
            ], $egs);
        }

        // one invoice waiting for ZATCA (simulated downtime) so the retry queue is visible
        $mode = 'down';
        $svc->issue($company, [
            'invoice_number' => 'INV-'.now()->format('ym').'-9999', 'external_reference' => 'DEMO-pending',
            'buyer' => ['name' => ''], 'lines' => [['name' => 'Gift card', 'quantity' => 1, 'unit_price' => 200, 'tax_category' => 'S', 'tax_percent' => 15]],
        ], $egs);
    }
}
