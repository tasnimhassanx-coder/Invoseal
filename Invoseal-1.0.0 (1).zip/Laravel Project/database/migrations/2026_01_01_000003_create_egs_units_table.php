<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // An EGS unit = one e-invoicing generation solution instance with its own certificate and invoice chain.
        Schema::create('egs_units', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('company_id')->constrained()->cascadeOnDelete();
            $table->foreignId('branch_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('environment', 12)->default('sandbox');
            $table->string('invoice_types', 4)->default('1100');   // [standard][simplified][0][0]
            $table->string('status', 24)->default('draft')->index();
            $table->longText('private_key')->nullable();            // encrypted
            $table->longText('csr')->nullable();
            $table->longText('compliance_certificate')->nullable();
            $table->text('compliance_secret')->nullable();          // encrypted
            $table->string('compliance_request_id', 40)->nullable();
            $table->longText('production_certificate')->nullable();
            $table->text('production_secret')->nullable();          // encrypted
            $table->string('production_request_id', 40)->nullable();
            $table->timestamp('certificate_issued_at')->nullable();
            $table->timestamp('certificate_expires_at')->nullable()->index();
            $table->json('compliance_results')->nullable();
            $table->unsignedBigInteger('last_icv')->default(0);
            $table->string('last_pih', 100)->nullable();
            $table->timestamp('onboarded_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egs_units');
    }
};
