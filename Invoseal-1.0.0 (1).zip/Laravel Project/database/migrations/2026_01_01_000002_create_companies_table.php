<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('name');
            $table->string('name_ar')->nullable();
            $table->string('vat_number', 15)->index();
            $table->string('crn', 30)->nullable();
            $table->string('id_scheme', 10)->default('CRN');
            $table->string('street')->nullable();
            $table->string('building_number', 10)->nullable();
            $table->string('plot_identification', 10)->nullable();
            $table->string('district')->nullable();
            $table->string('city')->nullable();
            $table->string('postal_zone', 10)->nullable();
            $table->string('country', 2)->default('SA');
            $table->string('business_category')->default('Supply activities');
            $table->string('environment', 12)->default('sandbox'); // sandbox | simulation | production
            $table->string('webhook_url', 500)->nullable();
            $table->text('webhook_secret')->nullable();            // encrypted
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('branches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('code', 30)->nullable();
            $table->string('city')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['company_id', 'code']);
        });

        Schema::create('company_user', function (Blueprint $table) {
            $table->foreignId('company_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->primary(['company_id', 'user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('company_user');
        Schema::dropIfExists('branches');
        Schema::dropIfExists('companies');
    }
};
