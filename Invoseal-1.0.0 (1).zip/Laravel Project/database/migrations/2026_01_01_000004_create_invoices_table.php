<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('company_id')->constrained()->restrictOnDelete();
            $table->foreignId('egs_unit_id')->constrained()->restrictOnDelete();
            $table->string('external_reference', 100)->nullable();     // caller's own id -> idempotency
            $table->string('invoice_number', 127);
            $table->string('type', 12);                                 // standard | simplified
            $table->string('sub_type', 12)->default('invoice');         // invoice | credit_note | debit_note
            $table->date('issue_date');
            $table->time('issue_time');
            $table->date('supply_date')->nullable();
            $table->string('currency', 3)->default('SAR');
            $table->string('payment_means', 3)->default('10');
            $table->string('billing_reference')->nullable();
            $table->string('reason')->nullable();
            $table->string('note', 500)->nullable();
            $table->string('buyer_name')->nullable();
            $table->string('buyer_vat', 15)->nullable();
            $table->json('buyer')->nullable();
            $table->decimal('line_extension', 14, 2)->default(0);
            $table->decimal('tax_exclusive', 14, 2)->default(0);
            $table->decimal('tax_amount', 14, 2)->default(0);
            $table->decimal('tax_inclusive', 14, 2)->default(0);
            $table->unsignedBigInteger('icv');
            $table->string('pih', 100);
            $table->string('invoice_hash', 100);
            $table->longText('signed_xml');
            $table->longText('cleared_xml')->nullable();
            $table->text('qr_code')->nullable();
            $table->string('status', 16)->default('pending')->index();  // pending|submitting|cleared|reported|rejected|failed
            $table->boolean('has_warnings')->default(false);
            $table->unsignedSmallInteger('attempts')->default(0);
            $table->timestamp('next_retry_at')->nullable()->index();
            $table->timestamp('submitted_at')->nullable();
            $table->text('last_error')->nullable();
            $table->date('retention_until')->index();
            $table->timestamps();

            $table->unique(['company_id', 'invoice_number']);
            $table->unique(['company_id', 'external_reference']);
            $table->unique(['egs_unit_id', 'icv']);
            $table->index(['company_id', 'issue_date']);
            $table->index(['company_id', 'status']);
        });

        Schema::create('invoice_lines', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('line_no');
            $table->string('name');
            $table->decimal('quantity', 16, 6);
            $table->string('unit_code', 3)->default('PCE');
            $table->decimal('unit_price', 16, 4);
            $table->decimal('discount', 14, 2)->default(0);
            $table->string('tax_category', 1)->default('S');
            $table->decimal('tax_percent', 5, 2)->default(15);
            $table->string('exemption_code', 40)->nullable();
            $table->string('exemption_reason')->nullable();
            $table->decimal('net', 14, 2);
            $table->decimal('tax', 14, 2);
            $table->decimal('gross', 14, 2);
            $table->unique(['invoice_id', 'line_no']);
        });

        Schema::create('submissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->string('endpoint', 16);                             // clearance | reporting
            $table->unsignedSmallInteger('attempt');
            $table->unsignedSmallInteger('http_status')->default(0);
            $table->string('result', 16);                               // accepted | warning | rejected | error
            $table->json('errors')->nullable();
            $table->json('warnings')->nullable();
            $table->json('response')->nullable();
            $table->string('transport_error', 500)->nullable();
            $table->unsignedInteger('duration_ms')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->index(['invoice_id', 'attempt']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('submissions');
        Schema::dropIfExists('invoice_lines');
        Schema::dropIfExists('invoices');
    }
};
