-- Invoseal 1.0.0 — MySQL 8 / MariaDB 10.6+ schema (generated from the Laravel migrations)
-- Equivalent to: php artisan migrate
-- Import into an empty database created with utf8mb4:
--   CREATE DATABASE invoseal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---- 0001_01_01_000000_create_users_table ----
create table `users` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `email` varchar(255) not null, `email_verified_at` timestamp null, `password` varchar(255) not null, `remember_token` varchar(100) null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `users` add unique `users_email_unique`(`email`);
create table `password_reset_tokens` (`email` varchar(255) not null, `token` varchar(255) not null, `created_at` timestamp null, primary key (`email`)) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
create table `sessions` (`id` varchar(255) not null, `user_id` bigint unsigned null, `ip_address` varchar(45) null, `user_agent` text null, `payload` longtext not null, `last_activity` int not null, primary key (`id`)) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `sessions` add index `sessions_user_id_index`(`user_id`);
alter table `sessions` add index `sessions_last_activity_index`(`last_activity`);

-- ---- 0001_01_01_000001_create_cache_table ----
create table `cache` (`key` varchar(255) not null, `value` mediumtext not null, `expiration` int not null, primary key (`key`)) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
create table `cache_locks` (`key` varchar(255) not null, `owner` varchar(255) not null, `expiration` int not null, primary key (`key`)) default character set utf8mb4 collate 'utf8mb4_unicode_ci';

-- ---- 0001_01_01_000002_create_jobs_table ----
create table `jobs` (`id` bigint unsigned not null auto_increment primary key, `queue` varchar(255) not null, `payload` longtext not null, `attempts` tinyint unsigned not null, `reserved_at` int unsigned null, `available_at` int unsigned not null, `created_at` int unsigned not null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `jobs` add index `jobs_queue_index`(`queue`);
create table `job_batches` (`id` varchar(255) not null, `name` varchar(255) not null, `total_jobs` int not null, `pending_jobs` int not null, `failed_jobs` int not null, `failed_job_ids` longtext not null, `options` mediumtext null, `cancelled_at` int null, `created_at` int not null, `finished_at` int null, primary key (`id`)) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
create table `failed_jobs` (`id` bigint unsigned not null auto_increment primary key, `uuid` varchar(255) not null, `connection` text not null, `queue` text not null, `payload` longtext not null, `exception` longtext not null, `failed_at` timestamp not null default CURRENT_TIMESTAMP) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `failed_jobs` add unique `failed_jobs_uuid_unique`(`uuid`);

-- ---- 2026_01_01_000001_add_roles_to_users_table ----
alter table `users` add `role` varchar(20) not null default 'viewer' after `password`;
alter table `users` add `is_active` tinyint(1) not null default '1' after `role`;
alter table `users` add `locale` varchar(5) not null default 'en' after `is_active`;
alter table `users` add `last_login_at` timestamp null after `locale`;
alter table `users` add index `users_role_index`(`role`);

-- ---- 2026_01_01_000002_create_companies_table ----
create table `companies` (`id` bigint unsigned not null auto_increment primary key, `uuid` char(36) not null, `name` varchar(255) not null, `name_ar` varchar(255) null, `vat_number` varchar(15) not null, `crn` varchar(30) null, `id_scheme` varchar(10) not null default 'CRN', `street` varchar(255) null, `building_number` varchar(10) null, `plot_identification` varchar(10) null, `district` varchar(255) null, `city` varchar(255) null, `postal_zone` varchar(10) null, `country` varchar(2) not null default 'SA', `business_category` varchar(255) not null default 'Supply activities', `environment` varchar(12) not null default 'sandbox', `webhook_url` varchar(500) null, `webhook_secret` text null, `is_active` tinyint(1) not null default '1', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `companies` add unique `companies_uuid_unique`(`uuid`);
alter table `companies` add index `companies_vat_number_index`(`vat_number`);
create table `branches` (`id` bigint unsigned not null auto_increment primary key, `company_id` bigint unsigned not null, `name` varchar(255) not null, `code` varchar(30) null, `city` varchar(255) null, `is_active` tinyint(1) not null default '1', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `branches` add constraint `branches_company_id_foreign` foreign key (`company_id`) references `companies` (`id`) on delete cascade;
alter table `branches` add unique `branches_company_id_code_unique`(`company_id`, `code`);
create table `company_user` (`company_id` bigint unsigned not null, `user_id` bigint unsigned not null, primary key (`company_id`, `user_id`)) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `company_user` add constraint `company_user_company_id_foreign` foreign key (`company_id`) references `companies` (`id`) on delete cascade;
alter table `company_user` add constraint `company_user_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade;

-- ---- 2026_01_01_000003_create_egs_units_table ----
create table `egs_units` (`id` bigint unsigned not null auto_increment primary key, `uuid` char(36) not null, `company_id` bigint unsigned not null, `branch_id` bigint unsigned null, `name` varchar(255) not null, `environment` varchar(12) not null default 'sandbox', `invoice_types` varchar(4) not null default '1100', `status` varchar(24) not null default 'draft', `private_key` longtext null, `csr` longtext null, `compliance_certificate` longtext null, `compliance_secret` text null, `compliance_request_id` varchar(40) null, `production_certificate` longtext null, `production_secret` text null, `production_request_id` varchar(40) null, `certificate_issued_at` timestamp null, `certificate_expires_at` timestamp null, `compliance_results` json null, `last_icv` bigint unsigned not null default '0', `last_pih` varchar(100) null, `onboarded_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `egs_units` add constraint `egs_units_company_id_foreign` foreign key (`company_id`) references `companies` (`id`) on delete cascade;
alter table `egs_units` add constraint `egs_units_branch_id_foreign` foreign key (`branch_id`) references `branches` (`id`) on delete set null;
alter table `egs_units` add unique `egs_units_uuid_unique`(`uuid`);
alter table `egs_units` add index `egs_units_status_index`(`status`);
alter table `egs_units` add index `egs_units_certificate_expires_at_index`(`certificate_expires_at`);

-- ---- 2026_01_01_000004_create_invoices_table ----
create table `invoices` (`id` bigint unsigned not null auto_increment primary key, `uuid` char(36) not null, `company_id` bigint unsigned not null, `egs_unit_id` bigint unsigned not null, `external_reference` varchar(100) null, `invoice_number` varchar(127) not null, `type` varchar(12) not null, `sub_type` varchar(12) not null default 'invoice', `issue_date` date not null, `issue_time` time not null, `supply_date` date null, `currency` varchar(3) not null default 'SAR', `payment_means` varchar(3) not null default '10', `billing_reference` varchar(255) null, `reason` varchar(255) null, `note` varchar(500) null, `buyer_name` varchar(255) null, `buyer_vat` varchar(15) null, `buyer` json null, `line_extension` decimal(14, 2) not null default '0', `tax_exclusive` decimal(14, 2) not null default '0', `tax_amount` decimal(14, 2) not null default '0', `tax_inclusive` decimal(14, 2) not null default '0', `icv` bigint unsigned not null, `pih` varchar(100) not null, `invoice_hash` varchar(100) not null, `signed_xml` longtext not null, `cleared_xml` longtext null, `qr_code` text null, `status` varchar(16) not null default 'pending', `has_warnings` tinyint(1) not null default '0', `attempts` smallint unsigned not null default '0', `next_retry_at` timestamp null, `submitted_at` timestamp null, `last_error` text null, `retention_until` date not null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `invoices` add constraint `invoices_company_id_foreign` foreign key (`company_id`) references `companies` (`id`) on delete restrict;
alter table `invoices` add constraint `invoices_egs_unit_id_foreign` foreign key (`egs_unit_id`) references `egs_units` (`id`) on delete restrict;
alter table `invoices` add unique `invoices_company_id_invoice_number_unique`(`company_id`, `invoice_number`);
alter table `invoices` add unique `invoices_company_id_external_reference_unique`(`company_id`, `external_reference`);
alter table `invoices` add unique `invoices_egs_unit_id_icv_unique`(`egs_unit_id`, `icv`);
alter table `invoices` add index `invoices_company_id_issue_date_index`(`company_id`, `issue_date`);
alter table `invoices` add index `invoices_company_id_status_index`(`company_id`, `status`);
alter table `invoices` add unique `invoices_uuid_unique`(`uuid`);
alter table `invoices` add index `invoices_status_index`(`status`);
alter table `invoices` add index `invoices_next_retry_at_index`(`next_retry_at`);
alter table `invoices` add index `invoices_retention_until_index`(`retention_until`);
create table `invoice_lines` (`id` bigint unsigned not null auto_increment primary key, `invoice_id` bigint unsigned not null, `line_no` smallint unsigned not null, `name` varchar(255) not null, `quantity` decimal(16, 6) not null, `unit_code` varchar(3) not null default 'PCE', `unit_price` decimal(16, 4) not null, `discount` decimal(14, 2) not null default '0', `tax_category` varchar(1) not null default 'S', `tax_percent` decimal(5, 2) not null default '15', `exemption_code` varchar(40) null, `exemption_reason` varchar(255) null, `net` decimal(14, 2) not null, `tax` decimal(14, 2) not null, `gross` decimal(14, 2) not null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `invoice_lines` add constraint `invoice_lines_invoice_id_foreign` foreign key (`invoice_id`) references `invoices` (`id`) on delete cascade;
alter table `invoice_lines` add unique `invoice_lines_invoice_id_line_no_unique`(`invoice_id`, `line_no`);
create table `submissions` (`id` bigint unsigned not null auto_increment primary key, `invoice_id` bigint unsigned not null, `endpoint` varchar(16) not null, `attempt` smallint unsigned not null, `http_status` smallint unsigned not null default '0', `result` varchar(16) not null, `errors` json null, `warnings` json null, `response` json null, `transport_error` varchar(500) null, `duration_ms` int unsigned not null default '0', `created_at` timestamp not null default CURRENT_TIMESTAMP) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `submissions` add constraint `submissions_invoice_id_foreign` foreign key (`invoice_id`) references `invoices` (`id`) on delete cascade;
alter table `submissions` add index `submissions_invoice_id_attempt_index`(`invoice_id`, `attempt`);

-- ---- 2026_01_01_000005_create_api_and_audit_tables ----
create table `api_keys` (`id` bigint unsigned not null auto_increment primary key, `company_id` bigint unsigned not null, `name` varchar(255) not null, `key_prefix` varchar(12) not null, `key_hash` varchar(64) not null, `abilities` json null, `ip_allowlist` json null, `last_used_at` timestamp null, `last_used_ip` varchar(45) null, `expires_at` timestamp null, `revoked_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `api_keys` add constraint `api_keys_company_id_foreign` foreign key (`company_id`) references `companies` (`id`) on delete cascade;
alter table `api_keys` add index `api_keys_key_prefix_index`(`key_prefix`);
alter table `api_keys` add unique `api_keys_key_hash_unique`(`key_hash`);
create table `audit_logs` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned null, `api_key_id` bigint unsigned null, `company_id` bigint unsigned null, `action` varchar(60) not null, `subject_type` varchar(60) null, `subject_id` bigint unsigned null, `ip` varchar(45) null, `meta` json null, `created_at` timestamp not null default CURRENT_TIMESTAMP) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `audit_logs` add constraint `audit_logs_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete set null;
alter table `audit_logs` add constraint `audit_logs_api_key_id_foreign` foreign key (`api_key_id`) references `api_keys` (`id`) on delete set null;
alter table `audit_logs` add constraint `audit_logs_company_id_foreign` foreign key (`company_id`) references `companies` (`id`) on delete set null;
alter table `audit_logs` add index `audit_logs_subject_type_subject_id_index`(`subject_type`, `subject_id`);
alter table `audit_logs` add index `audit_logs_action_index`(`action`);
alter table `audit_logs` add index `audit_logs_created_at_index`(`created_at`);
create table `webhook_deliveries` (`id` bigint unsigned not null auto_increment primary key, `company_id` bigint unsigned not null, `invoice_id` bigint unsigned null, `event` varchar(40) not null, `url` varchar(500) not null, `payload` json not null, `attempts` smallint unsigned not null default '0', `last_status` smallint unsigned null, `status` varchar(12) not null default 'pending', `last_error` varchar(500) null, `delivered_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `webhook_deliveries` add constraint `webhook_deliveries_company_id_foreign` foreign key (`company_id`) references `companies` (`id`) on delete cascade;
alter table `webhook_deliveries` add constraint `webhook_deliveries_invoice_id_foreign` foreign key (`invoice_id`) references `invoices` (`id`) on delete set null;
alter table `webhook_deliveries` add index `webhook_deliveries_status_index`(`status`);

-- ---- 2026_01_01_000006_create_notifications_table ----
create table `notifications` (`id` char(36) not null, `type` varchar(255) not null, `notifiable_type` varchar(255) not null, `notifiable_id` bigint unsigned not null, `data` text not null, `read_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null, primary key (`id`)) default character set utf8mb4 collate 'utf8mb4_unicode_ci';
alter table `notifications` add index `notifications_notifiable_type_notifiable_id_index`(`notifiable_type`, `notifiable_id`);

-- Migration bookkeeping so that `php artisan migrate` afterwards sees everything as applied
CREATE TABLE IF NOT EXISTS `migrations` (`id` int unsigned NOT NULL AUTO_INCREMENT, `migration` varchar(255) NOT NULL, `batch` int NOT NULL, PRIMARY KEY (`id`)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
INSERT INTO `migrations` (`migration`, `batch`) VALUES
('0001_01_01_000000_create_users_table', 1),
('0001_01_01_000001_create_cache_table', 1),
('0001_01_01_000002_create_jobs_table', 1),
('2026_01_01_000001_add_roles_to_users_table', 1),
('2026_01_01_000002_create_companies_table', 1),
('2026_01_01_000003_create_egs_units_table', 1),
('2026_01_01_000004_create_invoices_table', 1),
('2026_01_01_000005_create_api_and_audit_tables', 1),
('2026_01_01_000006_create_notifications_table', 1);

SET FOREIGN_KEY_CHECKS = 1;
