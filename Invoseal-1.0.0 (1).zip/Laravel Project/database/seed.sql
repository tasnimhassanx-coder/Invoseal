-- Invoseal 1.0.0 — starter data for MySQL 8 / MariaDB (run AFTER schema.sql)
--
-- Creates: one administrator, one fictional demo company with a branch and an EGS unit that is
-- waiting for onboarding. It deliberately contains NO private keys and NO ZATCA certificates
-- (those are encrypted with your own APP_KEY and are created in the panel: EGS Units → onboarding wizard).
--
-- First login:  admin@invoseal.test  /  password      ← CHANGE THE PASSWORD IMMEDIATELY (Users → Edit)
-- For a full demo with ~40 sample invoices use instead:  DEMO_MODE=true php artisan db:seed

SET NAMES utf8mb4;

INSERT INTO `users` (`name`, `email`, `email_verified_at`, `password`, `role`, `is_active`, `locale`, `created_at`, `updated_at`) VALUES
('Administrator', 'admin@invoseal.test', NOW(), '$2y$12$XLZ0jXiYeoDW2QyfJpdXWOBM6vYyRUEHX/SQSDzq0q4Q.wsxKukfq', 'admin', 1, 'en', NOW(), NOW());

INSERT INTO `companies` (`uuid`, `name`, `name_ar`, `vat_number`, `crn`, `id_scheme`, `street`, `building_number`, `plot_identification`, `district`, `city`, `postal_zone`, `country`, `business_category`, `environment`, `is_active`, `created_at`, `updated_at`) VALUES
('3f6f0a52-8a3d-4d0e-9d5c-6f6a2b1c0001', 'Al Noor Trading Co. (Demo)', 'شركة النور التجارية (تجريبي)', '300000000000003', '1010000000', 'CRN', 'Prince Sultan Road', '3242', '4533', 'Al Murabba', 'Riyadh', '12222', 'SA', 'Supply activities', 'sandbox', 1, NOW(), NOW());

INSERT INTO `branches` (`company_id`, `name`, `is_active`, `created_at`, `updated_at`) VALUES (1, 'Riyadh HQ', 1, NOW(), NOW());

INSERT INTO `egs_units` (`uuid`, `company_id`, `branch_id`, `name`, `environment`, `invoice_types`, `status`, `last_icv`, `created_at`, `updated_at`) VALUES
('3f6f0a52-8a3d-4d0e-9d5c-6f6a2b1c1001', 1, 1, 'POS-01 · Showroom', 'sandbox', '1100', 'draft', 0, NOW(), NOW());
