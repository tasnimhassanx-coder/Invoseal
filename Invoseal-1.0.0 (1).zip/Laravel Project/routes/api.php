<?php

use App\Http\Controllers\Api\InvoiceApiController;
use App\Http\Controllers\Api\MetaApiController;
use Illuminate\Support\Facades\Route;

Route::get('health', [MetaApiController::class, 'health']);

Route::middleware('api.key')->group(function () {
    Route::get('me', [MetaApiController::class, 'me']);
});

Route::middleware('api.key:invoices:read')->group(function () {
    Route::get('invoices', [InvoiceApiController::class, 'index']);
    Route::get('invoices/{uuid}', [InvoiceApiController::class, 'show'])->whereUuid('uuid');
    Route::get('invoices/{uuid}/xml', [InvoiceApiController::class, 'xml'])->whereUuid('uuid');
    Route::get('invoices/{uuid}/pdf', [InvoiceApiController::class, 'pdf'])->whereUuid('uuid');
});

Route::middleware('api.key:invoices:write')->group(function () {
    Route::post('invoices/validate', [InvoiceApiController::class, 'validateOnly']);
    Route::post('invoices', [InvoiceApiController::class, 'store']);
    Route::post('invoices/{uuid}/retry', [InvoiceApiController::class, 'retry'])->whereUuid('uuid');
});
