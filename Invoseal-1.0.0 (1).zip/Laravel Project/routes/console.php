<?php

use Illuminate\Support\Facades\Schedule;

// Everything below is driven by ONE cron entry:  * * * * * php /path/to/artisan schedule:run
Schedule::command('invoseal:retry-pending')->everyMinute()->withoutOverlapping();
Schedule::command('invoseal:check-certificates')->dailyAt('06:00');
Schedule::command('invoseal:alert-overdue')->hourly();
Schedule::command('queue:prune-failed --hours=720')->daily();

// Public demo only: rebuild fictional data every night (no effect unless DEMO_MODE=true)
if (config('invoseal.demo_mode')) {
    Schedule::command('invoseal:demo-reset')->dailyAt('03:00');
}
