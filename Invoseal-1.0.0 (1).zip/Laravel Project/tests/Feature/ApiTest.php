<?php

namespace Tests\Feature;

use App\Models\ApiKey;
use App\Models\Company;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Tests\Support\MakesCompany;
use Tests\TestCase;

class ApiTest extends TestCase
{
    use MakesCompany, RefreshDatabase;

    private Company $company;

    private string $key;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('local');
        Http::fake(['*' => Http::response(['reportingStatus' => 'REPORTED', 'validationResults' => ['warningMessages' => [], 'errorMessages' => []]], 200)]);
        $this->company = $this->makeCompany();
        $this->makeActiveUnit($this->company);
        [, $this->key] = ApiKey::issue($this->company, 'ERP');
    }

    private function h(?string $key = null, array $extra = []): array
    {
        return array_merge(['Authorization' => 'Bearer '.($key ?? $this->key), 'Accept' => 'application/json'], $extra);
    }

    public function test_health_is_public(): void
    {
        $this->getJson('/api/v1/health')->assertOk()->assertJson(['status' => 'ok']);
    }

    public function test_requires_valid_key(): void
    {
        $this->getJson('/api/v1/invoices')->assertStatus(401);
        $this->getJson('/api/v1/invoices', $this->h('isk_wrong'))->assertStatus(401);
    }

    public function test_revoked_and_expired_keys_are_rejected(): void
    {
        [$k1, $p1] = ApiKey::issue($this->company, 'old');
        $k1->update(['revoked_at' => now()]);
        $this->getJson('/api/v1/me', $this->h($p1))->assertStatus(401);
        [, $p2] = ApiKey::issue($this->company, 'exp', ApiKey::ABILITIES, null, now()->subDay());
        $this->getJson('/api/v1/me', $this->h($p2))->assertStatus(401);
    }

    public function test_abilities_are_enforced(): void
    {
        [, $ro] = ApiKey::issue($this->company, 'read-only', ['invoices:read']);
        $this->getJson('/api/v1/invoices', $this->h($ro))->assertOk();
        $this->postJson('/api/v1/invoices', $this->payload(), $this->h($ro))->assertStatus(403);
    }

    public function test_ip_allowlist_is_enforced(): void
    {
        [, $k] = ApiKey::issue($this->company, 'locked', ApiKey::ABILITIES, ['203.0.113.0/24']);
        $this->getJson('/api/v1/me', $this->h($k))->assertStatus(403);
        // a spoofed forwarding header must not unlock the key (proxies are untrusted by default)
        $this->getJson('/api/v1/me', $this->h($k, ['X-Forwarded-For' => '203.0.113.9']))->assertStatus(403);
        $this->withServerVariables(['REMOTE_ADDR' => '203.0.113.9'])->getJson('/api/v1/me', $this->h($k))->assertOk();
    }

    public function test_create_show_list_xml_pdf(): void
    {
        $res = $this->postJson('/api/v1/invoices', $this->payload(['invoice_number' => 'API-1', 'external_reference' => 'ERP-1']), $this->h())
            ->assertCreated()->assertJsonPath('data.status', 'reported')->assertJsonPath('data.totals.total', '115.00');
        $uuid = $res->json('data.uuid');

        $this->postJson('/api/v1/invoices', $this->payload(['invoice_number' => 'API-1b', 'external_reference' => 'ERP-1']), $this->h())
            ->assertOk()->assertJsonPath('duplicate', true)->assertJsonPath('data.uuid', $uuid);

        $this->getJson("/api/v1/invoices/{$uuid}", $this->h())->assertOk()->assertJsonCount(1, 'data.lines');
        $this->getJson('/api/v1/invoices?status=reported', $this->h())->assertOk()->assertJsonPath('meta.total', 1);
        $this->get("/api/v1/invoices/{$uuid}/xml", $this->h())->assertOk()->assertHeader('Content-Type', 'application/xml; charset=UTF-8');
        $this->get("/api/v1/invoices/{$uuid}/pdf", $this->h())->assertOk()->assertHeader('Content-Type', 'application/pdf');
    }

    public function test_validation_errors_are_localised(): void
    {
        $r = $this->postJson('/api/v1/invoices', $this->payload(['buyer' => ['name' => 'X', 'vat' => '12345'], 'type' => 'standard']), $this->h(null, ['Accept-Language' => 'ar']))
            ->assertStatus(422);
        $codes = array_column($r->json('errors'), 'code');
        $this->assertContains('BUYER_VAT_INVALID', $codes);
        $msg = collect($r->json('errors'))->firstWhere('code', 'BUYER_VAT_INVALID')['message'];
        $this->assertStringContainsString('15 رقماً', $msg);
    }

    public function test_shape_errors_use_the_same_envelope(): void
    {
        $this->postJson('/api/v1/invoices', ['invoice_number' => 'X'], $this->h())
            ->assertStatus(422)->assertJsonPath('errors.0.code', 'VALIDATION');
    }

    public function test_validate_endpoint_does_not_consume_numbers(): void
    {
        $this->postJson('/api/v1/invoices/validate', $this->payload(), $this->h())
            ->assertOk()->assertJsonPath('valid', true)->assertJsonPath('totals.tax_inclusive', '115.00');
        $this->assertSame(0, (int) $this->company->egsUnits()->first()->last_icv);
    }

    public function test_company_isolation(): void
    {
        $uuid = $this->postJson('/api/v1/invoices', $this->payload(), $this->h())->json('data.uuid');
        $other = $this->makeCompany(['name' => 'Other', 'vat_number' => '399999999800003']);
        [, $otherKey] = ApiKey::issue($other, 'x');
        $this->getJson("/api/v1/invoices/{$uuid}", $this->h($otherKey))->assertNotFound();
        $this->getJson('/api/v1/invoices', $this->h($otherKey))->assertJsonPath('meta.total', 0);
    }

    public function test_reported_invoice_cannot_be_retried(): void
    {
        $uuid = $this->postJson('/api/v1/invoices', $this->payload(), $this->h())->json('data.uuid');
        $this->postJson("/api/v1/invoices/{$uuid}/retry", [], $this->h())->assertStatus(409);
    }

    public function test_rate_limit(): void
    {
        config(['invoseal.api_rate_limit' => 3]);
        for ($i = 0; $i < 3; $i++) {
            $this->getJson('/api/v1/me', $this->h())->assertOk();
        }
        $this->getJson('/api/v1/me', $this->h())->assertStatus(429);
    }

    public function test_unknown_api_route_is_json_404(): void
    {
        $this->getJson('/api/v1/nope')->assertNotFound()->assertJson(['message' => 'Not found.']);
    }
}
