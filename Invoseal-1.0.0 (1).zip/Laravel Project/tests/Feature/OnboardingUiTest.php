<?php

namespace Tests\Feature;

use App\Enums\EgsStatus;
use App\Enums\Role;
use App\Filament\Resources\EgsUnitResource\Pages\ViewEgsUnit;
use App\Models\EgsUnit;
use App\Models\User;
use App\Support\DemoCertificate;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Livewire\Livewire;
use Tests\Support\MakesCompany;
use Tests\TestCase;

class OnboardingUiTest extends TestCase
{
    use MakesCompany, RefreshDatabase;

    public function test_full_onboarding_wizard_against_simulated_zatca(): void
    {
        $company = $this->makeCompany();
        $user = User::factory()->create(['role' => Role::Manager, 'is_active' => true]);
        $user->companies()->sync([$company->id]);
        $this->actingAs($user);

        $egs = EgsUnit::create(['company_id' => $company->id, 'name' => 'POS-9', 'environment' => 'sandbox', 'invoice_types' => '1100', 'status' => EgsStatus::Draft]);

        $cert = DemoCertificate::make($company->vat_number);
        $body = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $cert['certificate']);
        $token = base64_encode($body);
        Http::fake([
            '*/compliance/invoices' => Http::response(['validationResults' => ['status' => 'PASS', 'warningMessages' => [], 'errorMessages' => []], 'reportingStatus' => 'REPORTED', 'clearanceStatus' => 'CLEARED'], 200),
            '*/compliance' => Http::response(['requestID' => 1234567890123, 'dispositionMessage' => 'ISSUED', 'binarySecurityToken' => $token, 'secret' => 'compliance-secret'], 200),
            '*/production/csids' => Http::response(['requestID' => 987654321, 'dispositionMessage' => 'ISSUED', 'binarySecurityToken' => $token, 'secret' => 'production-secret'], 200),
        ]);

        $page = Livewire::test(ViewEgsUnit::class, ['record' => $egs->id]);

        $page->callAction('csr')->assertHasNoActionErrors();
        $this->assertSame(EgsStatus::CsrReady, $egs->fresh()->status);
        $this->assertStringContainsString('BEGIN CERTIFICATE REQUEST', $egs->fresh()->csr);

        $page->callAction('compliance', ['otp' => '123456'])->assertHasNoActionErrors();
        $this->assertSame(EgsStatus::ComplianceIssued, $egs->fresh()->status);

        $page->callAction('checks')->assertHasNoActionErrors();
        $this->assertSame(EgsStatus::CompliancePassed, $egs->fresh()->status);

        $page->callAction('activate')->assertHasNoActionErrors();
        $fresh = $egs->fresh();
        $this->assertSame(EgsStatus::Active, $fresh->status);
        $this->assertNotNull($fresh->production_certificate);
        $this->assertNotNull($fresh->certificate_expires_at);
    }

    public function test_viewer_cannot_see_onboarding_actions(): void
    {
        $company = $this->makeCompany();
        $user = User::factory()->create(['role' => Role::Viewer, 'is_active' => true]);
        $user->companies()->sync([$company->id]);
        $egs = EgsUnit::create(['company_id' => $company->id, 'name' => 'POS-9', 'environment' => 'sandbox', 'invoice_types' => '1100', 'status' => EgsStatus::Draft]);

        Livewire::actingAs($user)->test(ViewEgsUnit::class, ['record' => $egs->id])->assertActionHidden('csr');
    }
}
