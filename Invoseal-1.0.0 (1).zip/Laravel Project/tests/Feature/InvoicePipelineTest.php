<?php

namespace Tests\Feature;

use App\Enums\InvoiceStatus;
use App\Models\Invoice;
use App\Services\InvoiceService;
use App\Zatca\Crypto\InvoiceSigner;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Tests\Support\MakesCompany;
use Tests\TestCase;

class InvoicePipelineTest extends TestCase
{
    use MakesCompany, RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('local');
    }

    private function svc(): InvoiceService
    {
        return app(InvoiceService::class);
    }

    public function test_simplified_invoice_is_signed_chained_and_reported(): void
    {
        Http::fake(['*' => Http::response(['reportingStatus' => 'REPORTED', 'validationResults' => ['status' => 'PASS', 'warningMessages' => [], 'errorMessages' => []]], 200)]);
        $company = $this->makeCompany();
        $egs = $this->makeActiveUnit($company);

        $r1 = $this->svc()->issue($company, $this->payload(['invoice_number' => 'A-1']));
        $r2 = $this->svc()->issue($company, $this->payload(['invoice_number' => 'A-2']));

        $this->assertTrue($r1->ok() && $r2->ok());
        $this->assertSame(InvoiceStatus::Reported, $r1->invoice->status);
        $this->assertSame(1, $r1->invoice->icv);
        $this->assertSame(2, $r2->invoice->icv);
        $this->assertSame(InvoiceSigner::firstPreviousHash(), $r1->invoice->pih);
        $this->assertSame($r1->invoice->invoice_hash, $r2->invoice->pih, 'hash chain');
        $this->assertSame('115.00', (string) $r1->invoice->tax_inclusive);
        $this->assertNotNull($r1->invoice->qr_code);
        $this->assertTrue((new InvoiceSigner())->verify($r1->invoice->signed_xml)['signature']);
        $this->assertSame(2, (int) $egs->fresh()->last_icv);
        Storage::disk('local')->assertExists('archive/'.$company->uuid.'/'.now()->format('Y').'/'.now()->format('m').'/'.$r1->invoice->uuid.'.xml');
        Http::assertSent(fn ($req) => str_contains($req->url(), '/invoices/reporting/single') && $req->hasHeader('Accept-Version', 'V2'));
    }

    public function test_standard_invoice_is_cleared_and_stores_cleared_xml(): void
    {
        Http::fake(['*' => Http::response(['clearanceStatus' => 'CLEARED', 'clearedInvoice' => base64_encode('<Invoice>cleared</Invoice>'), 'validationResults' => ['warningMessages' => [], 'errorMessages' => []]], 200)]);
        $company = $this->makeCompany();
        $this->makeActiveUnit($company);
        $buyer = ['name' => 'Buyer Co', 'vat' => '399999999800003', 'street' => 'King Fahd', 'building' => '1234', 'district' => 'Olaya', 'city' => 'Riyadh', 'postal_zone' => '11564'];

        $r = $this->svc()->issue($company, $this->payload(['buyer' => $buyer]));

        $this->assertSame('standard', $r->invoice->type);
        $this->assertSame(InvoiceStatus::Cleared, $r->invoice->status);
        $this->assertSame('<Invoice>cleared</Invoice>', $r->invoice->cleared_xml);
        Http::assertSent(fn ($req) => str_contains($req->url(), '/invoices/clearance/single') && $req->hasHeader('Clearance-Status', '1'));
    }

    public function test_rejection_is_recorded_with_plain_error(): void
    {
        Http::fake(['*' => Http::response(['validationResults' => ['status' => 'ERROR', 'errorMessages' => [['type' => 'ERROR', 'code' => 'BR-KSA-X', 'category' => 'KSA', 'message' => 'Bad thing', 'status' => 'ERROR']], 'warningMessages' => []]], 400)]);
        $company = $this->makeCompany();
        $this->makeActiveUnit($company);

        $r = $this->svc()->issue($company, $this->payload());

        $this->assertSame(InvoiceStatus::Rejected, $r->invoice->status);
        $this->assertStringContainsString('BR-KSA-X', $r->invoice->last_error);
        $this->assertSame(1, $r->invoice->submissions()->count());
        $this->assertSame('rejected', $r->invoice->submissions()->first()->result);
    }

    public function test_zatca_downtime_keeps_invoice_pending_and_schedules_retry(): void
    {
        Http::fake(['*' => Http::sequence()
            ->push('Service Unavailable', 503)
            ->push(['reportingStatus' => 'REPORTED', 'validationResults' => ['warningMessages' => [], 'errorMessages' => []]], 200)]);
        $company = $this->makeCompany();
        $this->makeActiveUnit($company);

        $r = $this->svc()->issue($company, $this->payload());

        $this->assertSame(InvoiceStatus::Pending, $r->invoice->status);
        $this->assertNotNull($r->invoice->next_retry_at);
        $this->assertSame(1, $r->invoice->attempts);

        // later ZATCA recovers: the retry command + job deliver it
        Invoice::whereKey($r->invoice->id)->update(['next_retry_at' => now()->subMinute()]);
        config(['queue.default' => 'sync']);
        $this->artisan('invoseal:retry-pending')->assertSuccessful();
        $this->assertSame(InvoiceStatus::Reported, $r->invoice->fresh()->status);
    }

    public function test_idempotent_by_external_reference(): void
    {
        Http::fake(['*' => Http::response(['reportingStatus' => 'REPORTED', 'validationResults' => []], 200)]);
        $company = $this->makeCompany();
        $this->makeActiveUnit($company);

        $a = $this->svc()->issue($company, $this->payload(['external_reference' => 'ERP-9', 'invoice_number' => 'X-1']));
        $b = $this->svc()->issue($company, $this->payload(['external_reference' => 'ERP-9', 'invoice_number' => 'X-2']));

        $this->assertTrue($b->duplicate);
        $this->assertSame($a->invoice->id, $b->invoice->id);
        $this->assertSame(1, Invoice::count());
    }

    public function test_prevalidation_blocks_and_explains_in_three_languages(): void
    {
        $company = $this->makeCompany(['vat_number' => '123']);
        $this->makeActiveUnit($company);

        $r = $this->svc()->issue($company, $this->payload(['lines' => []]));

        $this->assertFalse($r->ok());
        $codes = array_column($r->issuesArray(), 'code');
        $this->assertContains('SELLER_VAT_INVALID', $codes);
        $this->assertContains('NO_LINES', $codes);
        $this->assertStringContainsString('15 digits', collect($r->issuesArray('en'))->firstWhere('code', 'SELLER_VAT_INVALID')['message']);
        $this->assertStringContainsString('১৫ অঙ্কের', collect($r->issuesArray('bn'))->firstWhere('code', 'SELLER_VAT_INVALID')['message']);
        $this->assertStringContainsString('15 رقماً', collect($r->issuesArray('ar'))->firstWhere('code', 'SELLER_VAT_INVALID')['message']);
        $this->assertSame(0, Invoice::count());
        $this->assertSame(0, (int) $company->egsUnits()->first()->last_icv, 'a rejected payload must not consume a chain number');
    }

    public function test_no_active_unit_is_reported(): void
    {
        $company = $this->makeCompany();
        $r = $this->svc()->issue($company, $this->payload());
        $this->assertContains('NO_ACTIVE_EGS', array_column($r->issuesArray(), 'code'));
    }

    public function test_invoices_cannot_be_deleted_during_retention(): void
    {
        Http::fake(['*' => Http::response(['reportingStatus' => 'REPORTED', 'validationResults' => []], 200)]);
        $company = $this->makeCompany();
        $this->makeActiveUnit($company);
        $inv = $this->svc()->issue($company, $this->payload())->invoice;
        $this->expectException(\LogicException::class);
        $inv->delete();
    }
}
