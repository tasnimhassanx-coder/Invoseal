<?php

namespace Tests\Feature;

use App\Services\InvoicePdf;
use App\Services\InvoiceService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Tests\Support\MakesCompany;
use Tests\TestCase;

class PdfTest extends TestCase
{
    use MakesCompany, RefreshDatabase;

    public function test_pdf_a3_with_embedded_xml_and_arabic(): void
    {
        Storage::fake('local');
        Http::fake(['*' => Http::response(['reportingStatus' => 'REPORTED', 'validationResults' => []], 200)]);
        $company = $this->makeCompany(['name_ar' => 'شركة توريد التكنولوجيا']);
        $this->makeActiveUnit($company);
        $inv = app(InvoiceService::class)->issue($company, $this->payload(['lines' => [['name' => 'دفتر ملاحظات | Notebook', 'quantity' => 2, 'unit_price' => 50]]]))->invoice;

        $pdf = (new InvoicePdf())->render($inv);

        $this->assertStringStartsWith('%PDF-1.', $pdf);
        $this->assertStringContainsString('/AFRelationship', $pdf, 'embedded associated file');
        $this->assertStringContainsString('pdfaid', $pdf, 'PDF/A identification in XMP');
        $this->assertGreaterThan(20000, strlen($pdf));
        file_put_contents(storage_path('app/sample-invoice.pdf'), $pdf);
    }
}
