<?php

namespace Tests\Feature;

use App\Enums\Role;
use App\Filament\Resources\ApiKeyResource\Pages\ListApiKeys;
use App\Filament\Resources\InvoiceResource\Pages\CreateInvoice;
use App\Filament\Resources\InvoiceResource\Pages\ListInvoices;
use App\Models\ApiKey;
use App\Models\Company;
use App\Models\Invoice;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Livewire\Livewire;
use Tests\Support\MakesCompany;
use Tests\TestCase;

class AdminPanelTest extends TestCase
{
    use MakesCompany, RefreshDatabase;

    private Company $a;

    private Company $b;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('local');
        Http::fake(['*' => Http::response(['reportingStatus' => 'REPORTED', 'validationResults' => ['warningMessages' => [], 'errorMessages' => []]], 200)]);
        $this->a = $this->makeCompany(['name' => 'Company A']);
        $this->b = $this->makeCompany(['name' => 'Company B', 'vat_number' => '399999999800003']);
        $this->makeActiveUnit($this->a);
        $this->makeActiveUnit($this->b);
    }

    private function user(Role $role, array $companies = []): User
    {
        $u = User::factory()->create(['role' => $role, 'is_active' => true]);
        $u->companies()->sync(array_map(fn ($c) => $c->id, $companies));

        return $u;
    }

    public function test_guests_are_sent_to_login_and_login_page_renders(): void
    {
        $this->get('/admin')->assertRedirect('/admin/login');
        $this->get('/admin/login')->assertOk()->assertSee('Invoseal');
    }

    public function test_inactive_user_cannot_enter_panel(): void
    {
        $u = User::factory()->create(['role' => Role::Admin, 'is_active' => false]);
        $this->actingAs($u)->get('/admin')->assertForbidden();
    }

    public function test_admin_can_open_every_page(): void
    {
        $this->actingAs($this->user(Role::Admin));
        foreach (['', '/invoices', '/invoices/create', '/companies', '/companies/create', '/egs-units', '/egs-units/create',
            '/api-keys', '/users', '/users/create', '/audit-logs', '/webhook-deliveries'] as $path) {
            $this->get('/admin'.$path)->assertOk();
        }
    }

    public function test_viewer_is_read_only_and_cannot_see_admin_areas(): void
    {
        $this->actingAs($this->user(Role::Viewer, [$this->a]));
        $this->get('/admin/invoices')->assertOk();
        $this->get('/admin/invoices/create')->assertForbidden();
        $this->get('/admin/users')->assertForbidden();
        $this->get('/admin/companies/create')->assertForbidden();
        $this->get('/admin/egs-units/create')->assertForbidden();
    }

    public function test_operator_cannot_manage_setup(): void
    {
        $this->actingAs($this->user(Role::Operator, [$this->a]));
        $this->get('/admin/invoices/create')->assertOk();
        $this->get('/admin/users')->assertForbidden();
        $this->get('/admin/companies/create')->assertForbidden();
    }

    public function test_company_scoping_hides_other_companies_invoices(): void
    {
        $svc = app(\App\Services\InvoiceService::class);
        $ia = $svc->issue($this->a, $this->payload())->invoice;
        $ib = $svc->issue($this->b, $this->payload())->invoice;

        $user = $this->user(Role::Operator, [$this->a]);
        $this->actingAs($user);

        Livewire::test(ListInvoices::class)
            ->assertCanSeeTableRecords([$ia])
            ->assertCanNotSeeTableRecords([$ib]);

        $this->get('/admin/invoices/'.$ia->id)->assertOk();
        $this->get('/admin/invoices/'.$ib->id)->assertNotFound();
        $this->get('/admin/companies/'.$this->b->id.'/edit')->assertNotFound();
    }

    public function test_invoice_form_issues_a_signed_invoice(): void
    {
        $this->actingAs($this->user(Role::Operator, [$this->a]));

        Livewire::test(CreateInvoice::class)
            ->fillForm([
                'company_id' => $this->a->id, 'invoice_number' => 'FORM-1', 'type' => 'simplified', 'sub_type' => 'invoice',
                'lines' => [['name' => 'Widget', 'quantity' => 2, 'unit_price' => 100, 'discount' => 0, 'tax_category' => 'S', 'unit_code' => 'PCE']],
            ])
            ->call('create')
            ->assertHasNoFormErrors();

        $inv = Invoice::where('invoice_number', 'FORM-1')->firstOrFail();
        $this->assertSame('230.00', (string) $inv->tax_inclusive);
        $this->assertSame($this->a->id, $inv->company_id);
        $this->assertNotEmpty($inv->signed_xml);
    }

    public function test_operator_cannot_issue_for_a_company_they_do_not_belong_to(): void
    {
        $this->actingAs($this->user(Role::Operator, [$this->a]));

        Livewire::test(CreateInvoice::class)
            ->fillForm([
                'company_id' => $this->b->id, 'invoice_number' => 'FORM-X', 'type' => 'simplified', 'sub_type' => 'invoice',
                'lines' => [['name' => 'Widget', 'quantity' => 1, 'unit_price' => 10, 'tax_category' => 'S', 'unit_code' => 'PCE']],
            ])
            ->call('create')
            ->assertHasFormErrors(['company_id']);

        $this->assertSame(0, Invoice::count());
    }

    public function test_api_key_is_created_once_and_can_be_revoked(): void
    {
        $this->actingAs($this->user(Role::Manager, [$this->a]));

        Livewire::test(ListApiKeys::class)
            ->callAction('create', ['company_id' => $this->a->id, 'name' => 'ERP', 'abilities' => ['invoices:read']])
            ->assertHasNoActionErrors();

        $key = ApiKey::firstOrFail();
        $this->assertSame(['invoices:read'], $key->abilities);
        $this->assertNull($key->revoked_at);

        Livewire::test(ListApiKeys::class)->callTableAction('revoke', $key);
        $this->assertNotNull($key->fresh()->revoked_at);
        $this->assertNull(ApiKey::findByPlain('invoseal_invalid'));
    }

    public function test_viewer_cannot_create_api_keys(): void
    {
        $this->actingAs($this->user(Role::Viewer, [$this->a]));
        $this->get('/admin/api-keys')->assertForbidden();
    }
}
