<?php

declare(strict_types=1);

namespace Tests\Unit\Zatca;

use App\Zatca\Calculator;
use App\Zatca\Crypto\CertificateInfo;
use App\Zatca\Crypto\InvoiceSigner;
use App\Zatca\Dto\InvoiceData;
use App\Zatca\Dto\Line;
use App\Zatca\Dto\Party;
use App\Zatca\Qr\QrPayload;
use App\Zatca\Xml\UblInvoiceBuilder;
use PHPUnit\Framework\TestCase;
use Tests\Support\TestCertificate;

final class SigningTest extends TestCase
{
    private function invoice(string $type = InvoiceData::TYPE_SIMPLIFIED): InvoiceData
    {
        $seller = new Party('Maximum Speed Tech Supply LTD', '399999999900003', '1010010000', 'CRN', 'Prince Sultan', '3242', '4533', 'Al-Murabba', 'Riyadh', '12222');
        $buyer = $type === InvoiceData::TYPE_STANDARD
            ? new Party('Buyer Co', '399999999800003', '2050010000', 'CRN', 'King Fahd', '1234', null, 'Olaya', 'Riyadh', '11564')
            : new Party('');
        $inv = new InvoiceData('INV-0001', $type, InvoiceData::SUB_INVOICE, '2026-11-10', '10:15:30', $seller, $buyer, [
            new Line('Notebook', '33', '3.00', '0', 'S', '15'),
            new Line('Pen', '2', '102.00', '3.00', 'S', '15'),
        ]);
        $inv->uuid = '8e6000cf-1a98-4174-b3e7-b5d5954bc10d';
        $inv->icv = 1;
        $inv->pih = InvoiceSigner::firstPreviousHash();

        return (new Calculator())->apply($inv);
    }

    public function test_first_previous_hash_constant(): void
    {
        $this->assertSame(
            'NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==',
            InvoiceSigner::firstPreviousHash()
        );
    }

    public function test_totals(): void
    {
        $inv = $this->invoice();
        // 33*3.00 = 99.00 ; 2*102.00-3.00 = 201.00 => 300.00 ; VAT 15% = 45.00
        $this->assertSame('300.00', $inv->lineExtension);
        $this->assertSame('45.00', $inv->taxAmount);
        $this->assertSame('345.00', $inv->taxInclusive);
        $this->assertSame('345.00', $inv->payable);
        $this->assertSame('14.85', $inv->lines[0]->tax);
        $this->assertSame('113.85', $inv->lines[0]->gross);
    }

    public function test_sign_and_verify_simplified(): void
    {
        $c = TestCertificate::make();
        $xml = (new UblInvoiceBuilder())->build($this->invoice());
        $signer = new InvoiceSigner();
        $res = $signer->sign($xml, $c['certificate'], $c['private_key']);

        $v = $signer->verify($res['xml']);
        $this->assertTrue($v['hash'], 'invoice hash');
        $this->assertTrue($v['signature'], 'ECDSA signature');
        $this->assertTrue($v['signed_properties'], 'signed properties digest');
        $this->assertTrue($v['certificate_digest'], 'certificate digest');
        $this->assertNotNull($res['qr']);
        $this->assertStringContainsString('<cbc:ID>QR</cbc:ID>', $res['xml']);

        $tags = QrPayload::decode($res['qr']);
        $this->assertSame('Maximum Speed Tech Supply LTD', $tags[1]);
        $this->assertSame('399999999900003', $tags[2]);
        $this->assertSame('2026-11-10T10:15:30', $tags[3]);
        $this->assertSame('345.00', $tags[4]);
        $this->assertSame('45.00', $tags[5]);
        $this->assertSame($res['hash'], $tags[6]);
        $this->assertSame($res['signature'], $tags[7]);
        $this->assertSame(CertificateInfo::fromAny($c['certificate'])->publicKeyDer, $tags[8]);
        $this->assertNotSame('', $tags[9]);
    }

    public function test_standard_invoice_has_no_qr_reference(): void
    {
        $c = TestCertificate::make();
        $xml = (new UblInvoiceBuilder())->build($this->invoice(InvoiceData::TYPE_STANDARD));
        $res = (new InvoiceSigner())->sign($xml, $c['certificate'], $c['private_key']);
        $this->assertNull($res['qr']);
        $this->assertTrue((new InvoiceSigner())->verify($res['xml'])['hash']);
    }

    public function test_tampering_is_detected(): void
    {
        $c = TestCertificate::make();
        $signer = new InvoiceSigner();
        $res = $signer->sign((new UblInvoiceBuilder())->build($this->invoice()), $c['certificate'], $c['private_key']);
        $tampered = str_replace('345.00', '999.00', $res['xml']);
        $v = $signer->verify($tampered);
        $this->assertFalse($v['hash']);
        $this->assertFalse($v['signature']);
    }

    public function test_hash_ignores_extensions_signature_and_qr(): void
    {
        $c = TestCertificate::make();
        $signer = new InvoiceSigner();
        $xml = (new UblInvoiceBuilder())->build($this->invoice());
        $res = $signer->sign($xml, $c['certificate'], $c['private_key']);
        $this->assertSame($signer->invoiceHash($xml), $signer->invoiceHash($res['xml']));
    }

    public function test_certificate_info(): void
    {
        $c = TestCertificate::make();
        $info = CertificateInfo::fromAny($c['certificate']);
        $this->assertStringStartsWith('CN=TST-886431145-', $info->issuerName);
        $this->assertNotSame('', $info->serialDecimal);
        $this->assertNotSame('', $info->signatureBytes);
        $this->assertFalse($info->isExpired());
    }
}
