<?php

namespace Tests\Support;

use App\Enums\EgsStatus;
use App\Models\Company;
use App\Models\EgsUnit;

trait MakesCompany
{
    protected function makeCompany(array $over = []): Company
    {
        return Company::create(array_merge([
            'name' => 'Maximum Speed Tech Supply LTD', 'vat_number' => '399999999900003', 'crn' => '1010010000',
            'street' => 'Prince Sultan', 'building_number' => '3242', 'plot_identification' => '4533',
            'district' => 'Al-Murabba', 'city' => 'Riyadh', 'postal_zone' => '12222',
            'environment' => 'sandbox',
        ], $over));
    }

    /** An already-onboarded EGS unit holding a throw-away self-signed certificate. */
    protected function makeActiveUnit(Company $company, string $types = '1100'): EgsUnit
    {
        $c = TestCertificate::make($company->vat_number);

        return EgsUnit::create([
            'company_id' => $company->id, 'name' => 'POS-1', 'environment' => 'sandbox', 'invoice_types' => $types,
            'status' => EgsStatus::Active,
            'private_key' => $c['private_key'],
            'production_certificate' => base64_encode(preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $c['certificate'])),
            'production_secret' => 'secret',
            'certificate_expires_at' => now()->addYear(),
            'last_icv' => 0,
        ]);
    }

    protected function payload(array $over = []): array
    {
        return array_merge([
            'invoice_number' => 'INV-'.uniqid(),
            'buyer' => ['name' => ''],
            'lines' => [['name' => 'Notebook', 'quantity' => 2, 'unit_price' => 50, 'tax_category' => 'S', 'tax_percent' => 15]],
        ], $over);
    }
}
