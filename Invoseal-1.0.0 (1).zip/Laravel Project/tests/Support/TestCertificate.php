<?php

declare(strict_types=1);

namespace Tests\Support;

use App\Support\DemoCertificate;

/** Creates a throw-away self-signed secp256k1 certificate shaped like a ZATCA EGS certificate (tests only). */
final class TestCertificate
{
    /** @return array{private_key:string,certificate:string} */
    public static function make(string $vat = '399999999900003'): array
    {
        return DemoCertificate::make($vat, 'Maximum Speed Tech Supply LTD');
    }
}
