<?php

namespace App\Enums;

enum InvoiceStatus: string
{
    case Pending = 'pending';       // signed locally, waiting for (re)submission
    case Submitting = 'submitting';
    case Cleared = 'cleared';       // standard invoice cleared by ZATCA
    case Reported = 'reported';     // simplified invoice reported to ZATCA
    case Rejected = 'rejected';     // ZATCA refused it; needs a corrected invoice
    case Failed = 'failed';         // gave up after retries (network / ZATCA unavailable)

    public function label(): string
    {
        return __('invoseal.status.'.$this->value);
    }

    public function color(): string
    {
        return match ($this) {
            self::Cleared, self::Reported => 'success',
            self::Pending, self::Submitting => 'warning',
            self::Rejected, self::Failed => 'danger',
        };
    }

    public function isFinal(): bool
    {
        return in_array($this, [self::Cleared, self::Reported, self::Rejected], true);
    }
}
