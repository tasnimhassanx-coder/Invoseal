<?php

namespace App\Enums;

enum Role: string
{
    case Admin = 'admin';
    case Manager = 'manager';
    case Operator = 'operator';
    case Viewer = 'viewer';

    public function label(): string
    {
        return __('invoseal.roles.'.$this->value);
    }

    /** Can create / retry invoices. */
    public function canIssue(): bool
    {
        return in_array($this, [self::Admin, self::Manager, self::Operator], true);
    }

    /** Can manage companies, EGS units, API keys. */
    public function canManage(): bool
    {
        return in_array($this, [self::Admin, self::Manager], true);
    }
}
