<?php

namespace App\Enums;

enum EgsStatus: string
{
    case Draft = 'draft';
    case CsrReady = 'csr_ready';
    case ComplianceIssued = 'compliance_issued';
    case CompliancePassed = 'compliance_passed';
    case Active = 'active';
    case Expired = 'expired';
    case Revoked = 'revoked';

    public function label(): string
    {
        return __('invoseal.egs_status.'.$this->value);
    }

    public function color(): string
    {
        return match ($this) {
            self::Active => 'success',
            self::Draft, self::CsrReady => 'gray',
            self::ComplianceIssued, self::CompliancePassed => 'info',
            self::Expired, self::Revoked => 'danger',
        };
    }
}
