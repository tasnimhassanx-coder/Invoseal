<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Public demo: never talk to ZATCA, simulate it locally (see DemoZatcaSimulator).
        if (config('invoseal.demo_mode') && ! app()->runningUnitTests()) {
            \App\Support\DemoZatcaSimulator::register();
        }
    }
}
