<?php

namespace App\Policies;

use App\Models\ApiKey;
use App\Models\User;

class ApiKeyPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->is_active && $user->canManage();
    }

    public function view(User $user, \Illuminate\Database\Eloquent\Model $record): bool
    {
        return $user->canManage() && $this->owns($user, $record);
    }

    public function create(User $user): bool
    {
        return $user->canManage();
    }

    public function update(User $user, ApiKey $key): bool
    {
        return $user->canManage() && $this->owns($user, $key);
    }

    public function delete(User $user, ApiKey $key): bool
    {
        return $user->canManage() && $this->owns($user, $key);
    }

    public function deleteAny(User $user): bool
    {
        return false;
    }
}
