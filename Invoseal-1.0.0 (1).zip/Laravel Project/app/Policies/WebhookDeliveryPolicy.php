<?php

namespace App\Policies;

use App\Models\User;

class WebhookDeliveryPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->is_active && $user->canManage();
    }

    public function view(User $user, \Illuminate\Database\Eloquent\Model $record): bool
    {
        return $user->canManage() && $this->owns($user, $record);
    }

    public function create(User $user): bool
    {
        return false;
    }

    public function update(User $user, \Illuminate\Database\Eloquent\Model $record): bool
    {
        return $user->canManage() && $this->owns($user, $record);
    }

    public function delete(User $user, \Illuminate\Database\Eloquent\Model $record): bool
    {
        return false;
    }

    public function deleteAny(User $user): bool
    {
        return false;
    }
}
