<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

/**
 * Role matrix used by every resource. Visibility is additionally narrowed to the user's own
 * companies in each Filament resource query (see App\Filament\Concerns\ScopedToCompanies).
 *
 *   admin    everything, all companies
 *   manager  companies / EGS units / API keys of assigned companies, issue invoices
 *   operator issue and retry invoices
 *   viewer   read-only
 */
abstract class BasePolicy
{
    protected function owns(User $user, Model $record, string $column = 'company_id'): bool
    {
        $ids = $user->companyIds();

        return $ids === null || in_array($record->{$column}, $ids, true);
    }

    public function viewAny(User $user): bool
    {
        return $user->is_active;
    }

    public function view(User $user, Model $record): bool
    {
        return $user->is_active && $this->owns($user, $record);
    }
}
