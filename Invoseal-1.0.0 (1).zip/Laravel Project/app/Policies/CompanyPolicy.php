<?php

namespace App\Policies;

use App\Models\Company;
use App\Models\User;

class CompanyPolicy extends BasePolicy
{
    protected function owns(User $user, \Illuminate\Database\Eloquent\Model $record, string $column = 'id'): bool
    {
        return parent::owns($user, $record, 'id');
    }

    public function create(User $user): bool
    {
        return $user->isAdmin();
    }

    public function update(User $user, Company $company): bool
    {
        return $user->canManage() && $this->owns($user, $company);
    }

    public function delete(User $user, Company $company): bool
    {
        return $user->isAdmin() && ! $company->invoices()->exists();
    }

    public function deleteAny(User $user): bool
    {
        return false;
    }
}
