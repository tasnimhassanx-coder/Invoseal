<?php

namespace App\Policies;

use App\Models\Branch;
use App\Models\User;

class BranchPolicy extends BasePolicy
{
    public function create(User $user): bool
    {
        return $user->is_active && $user->canManage();
    }

    public function update(User $user, Branch $branch): bool
    {
        return $user->is_active && $user->canManage() && $this->owns($user, $branch);
    }

    public function delete(User $user, Branch $branch): bool
    {
        return $user->isAdmin() && ! $branch->egsUnits()->exists();
    }

    public function deleteAny(User $user): bool
    {
        return false;
    }
}
