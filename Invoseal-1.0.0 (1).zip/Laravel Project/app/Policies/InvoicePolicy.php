<?php

namespace App\Policies;

use App\Models\Invoice;
use App\Models\User;

class InvoicePolicy extends BasePolicy
{
    public function create(User $user): bool
    {
        return $user->is_active && $user->canIssue();
    }

    public function retry(User $user, Invoice $invoice): bool
    {
        return $user->is_active && $user->canIssue() && $this->owns($user, $invoice);
    }

    // Tax documents are immutable and are never deleted by users.
    public function update(User $user, Invoice $invoice): bool
    {
        return false;
    }

    public function delete(User $user, Invoice $invoice): bool
    {
        return false;
    }

    public function deleteAny(User $user): bool
    {
        return false;
    }
}
