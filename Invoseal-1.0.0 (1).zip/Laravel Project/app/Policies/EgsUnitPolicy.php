<?php

namespace App\Policies;

use App\Models\EgsUnit;
use App\Models\User;

class EgsUnitPolicy extends BasePolicy
{
    public function create(User $user): bool
    {
        return $user->canManage();
    }

    public function update(User $user, EgsUnit $unit): bool
    {
        return $user->canManage() && $this->owns($user, $unit);
    }

    public function delete(User $user, EgsUnit $unit): bool
    {
        return $user->isAdmin() && ! $unit->invoices()->exists();
    }

    public function deleteAny(User $user): bool
    {
        return false;
    }
}
