<?php

namespace App\Filament\Resources;

use App\Filament\Concerns\ScopedToCompanies;
use App\Filament\Resources\WebhookDeliveryResource\Pages;
use App\Jobs\DeliverWebhookJob;
use App\Models\WebhookDelivery;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class WebhookDeliveryResource extends Resource
{
    use ScopedToCompanies;

    protected static ?string $model = WebhookDelivery::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPaperAirplane;

    protected static string|\UnitEnum|null $navigationGroup = 'Gateway';

    protected static ?int $navigationSort = 3;

    protected static ?string $modelLabel = 'webhook delivery';

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('id', 'desc')
            ->modifyQueryUsing(fn ($query) => $query->with(['company', 'invoice']))
            ->poll('30s')
            ->columns([
                TextColumn::make('created_at')->label('Created')->since()->sortable(),
                TextColumn::make('event')->badge()->color('gray')->fontFamily('mono')->searchable(),
                TextColumn::make('invoice.invoice_number')->label('Invoice')->weight(FontWeight::SemiBold)->placeholder('—')->searchable(),
                TextColumn::make('company.name')->toggleable(),
                TextColumn::make('url')->limit(40)->tooltip(fn (WebhookDelivery $r) => $r->url)->toggleable(),
                TextColumn::make('status')->badge()->color(fn (string $state) => match ($state) { 'delivered' => 'success', 'failed' => 'danger', default => 'warning' }),
                TextColumn::make('last_status')->label('HTTP')->placeholder('—')->alignCenter(),
                TextColumn::make('attempts')->alignCenter(),
                TextColumn::make('last_error')->limit(40)->tooltip(fn (WebhookDelivery $r) => $r->last_error)->placeholder('—')->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([SelectFilter::make('status')->native(false)->options(['pending' => 'Pending', 'delivered' => 'Delivered', 'failed' => 'Failed'])])
            ->recordActions([
                Action::make('redeliver')->label('Redeliver')->icon(Heroicon::OutlinedArrowPath)->color('gray')
                    ->visible(fn (WebhookDelivery $r) => $r->status !== 'delivered' && auth()->user()->can('update', $r))
                    ->action(function (WebhookDelivery $r) {
                        abort_unless(auth()->user()->can('update', $r), 403);
                        $r->update(['status' => 'pending', 'attempts' => 0, 'last_error' => null]);
                        DeliverWebhookJob::dispatch($r->id);
                        Notification::make()->title('Redelivery queued')->success()->send();
                    }),
            ])
            ->emptyStateIcon(Heroicon::OutlinedPaperAirplane)->emptyStateHeading('No webhook deliveries')
            ->emptyStateDescription('Set a webhook URL on a company to be notified when invoices are cleared, reported or rejected.');
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListWebhookDeliveries::route('/')];
    }
}
