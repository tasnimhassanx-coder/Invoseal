<?php

namespace App\Filament\Resources\EgsUnitResource\Pages;

use App\Filament\Resources\EgsUnitResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListEgsUnits extends ListRecords
{
    protected static string $resource = EgsUnitResource::class;

    protected function getHeaderActions(): array
    {
        return [CreateAction::make()->label('New EGS unit')];
    }
}
