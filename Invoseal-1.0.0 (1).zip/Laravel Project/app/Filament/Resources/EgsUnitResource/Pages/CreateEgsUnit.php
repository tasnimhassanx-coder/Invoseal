<?php

namespace App\Filament\Resources\EgsUnitResource\Pages;

use App\Filament\Resources\EgsUnitResource;
use App\Services\AuditLogger;
use Filament\Resources\Pages\CreateRecord;

class CreateEgsUnit extends CreateRecord
{
    protected static string $resource = EgsUnitResource::class;

    protected static bool $canCreateAnother = false;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['invoice_types'] = EgsUnitResource::typesToFlags((array) ($this->data['types'] ?? []));
        unset($data['types']);

        return $data;
    }

    protected function afterCreate(): void
    {
        AuditLogger::log('egs.created', $this->record);
    }

    protected function getRedirectUrl(): string
    {
        return EgsUnitResource::getUrl('view', ['record' => $this->record]);
    }
}
