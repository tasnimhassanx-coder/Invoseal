<?php

namespace App\Filament\Resources\EgsUnitResource\Pages;

use App\Enums\EgsStatus;
use App\Filament\Resources\EgsUnitResource;
use App\Models\EgsUnit;
use App\Services\EgsOnboardingService;
use Filament\Actions\Action;
use Filament\Actions\EditAction;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ViewRecord;
use Filament\Support\Icons\Heroicon;
use Throwable;

/** The onboarding wizard lives here: each step is one action, shown only when it is the next logical step. */
class ViewEgsUnit extends ViewRecord
{
    protected static string $resource = EgsUnitResource::class;

    public function getTitle(): string
    {
        return $this->record->name;
    }

    public function getSubheading(): ?string
    {
        return $this->record->company->name.' · '.ucfirst($this->record->environment);
    }

    private function run(callable $fn, string $success): void
    {
        try {
            $fn();
            $this->record->refresh();
            Notification::make()->success()->title($success)->send();
        } catch (Throwable $e) {
            report($e);
            Notification::make()->danger()->persistent()->title('Step failed')->body($e->getMessage())->send();
        }
    }

    private function can(): bool
    {
        return auth()->user()->can('update', $this->record);
    }

    protected function getHeaderActions(): array
    {
        $svc = fn () => app(EgsOnboardingService::class);

        return [
            Action::make('csr')
                ->label(fn (EgsUnit $r) => $r->csr ? 'Regenerate keys & CSR' : '1 · Generate keys & CSR')
                ->icon(Heroicon::OutlinedKey)->color(fn (EgsUnit $r) => $r->csr ? 'gray' : 'primary')
                ->visible(fn (EgsUnit $r) => $this->can() && ! in_array($r->status, [EgsStatus::Active, EgsStatus::Expired], true))
                ->requiresConfirmation()->modalDescription($this->record->csr ? 'This replaces the existing key and any certificates already issued for it.' : 'A secp256k1 key pair and the ZATCA CSR are created on this server.')
                ->action(fn (EgsUnit $r) => $this->run(fn () => $svc()->prepare($r), 'Key pair and CSR generated')),

            Action::make('compliance')
                ->label('2 · Get compliance certificate')->icon(Heroicon::OutlinedShieldCheck)
                ->visible(fn (EgsUnit $r) => $this->can() && $r->status === EgsStatus::CsrReady)
                ->modalHeading('Enter the one-time password (OTP)')
                ->modalDescription('Generate the OTP in the ZATCA Fatoora portal (Onboard new solution unit). It is valid for a few minutes.')
                ->schema([TextInput::make('otp')->label('OTP')->required()->maxLength(12)->placeholder('123456')->autofocus()])
                ->action(fn (EgsUnit $r, array $data) => $this->run(fn () => $svc()->requestComplianceCertificate($r, $data['otp']), 'Compliance certificate received')),

            Action::make('checks')
                ->label(fn (EgsUnit $r) => $r->status === EgsStatus::CompliancePassed ? 'Re-run compliance checks' : '3 · Run compliance checks')->icon(Heroicon::OutlinedClipboardDocumentCheck)
                ->color(fn (EgsUnit $r) => $r->status === EgsStatus::CompliancePassed ? 'gray' : 'primary')
                ->visible(fn (EgsUnit $r) => $this->can() && in_array($r->status, [EgsStatus::ComplianceIssued, EgsStatus::CompliancePassed], true))
                ->requiresConfirmation()->modalDescription('Signed sample invoices of every type this unit will issue are sent to ZATCA\'s compliance checker.')
                ->action(function (EgsUnit $r) use ($svc) {
                    $this->run(function () use ($r, $svc) {
                        $res = $svc()->runComplianceChecks($r);
                        $bad = count(array_filter($res, fn ($x) => ! $x['passed']));
                        if ($bad) {
                            throw new \RuntimeException("{$bad} of ".count($res).' sample invoices did not pass. See the results panel below.');
                        }
                    }, 'All compliance checks passed');
                }),

            Action::make('activate')
                ->label('4 · Go live')->icon(Heroicon::OutlinedCheckBadge)->color('success')
                ->visible(fn (EgsUnit $r) => $this->can() && $r->status === EgsStatus::CompliancePassed)
                ->requiresConfirmation()->modalDescription('Requests the production certificate. The unit can then issue real, ZATCA-reportable invoices.')
                ->action(fn (EgsUnit $r) => $this->run(fn () => $svc()->activate($r), 'The unit is live')),

            Action::make('renew')
                ->label('Renew certificate')->icon(Heroicon::OutlinedArrowPath)->color('warning')
                ->visible(fn (EgsUnit $r) => $this->can() && $r->status === EgsStatus::Active)
                ->modalHeading('Renew the production certificate')
                ->modalDescription('Generate a new OTP in the Fatoora portal. The invoice chain continues without interruption.')
                ->schema([TextInput::make('otp')->label('OTP')->required()->maxLength(12)])
                ->action(fn (EgsUnit $r, array $data) => $this->run(fn () => $svc()->renew($r, $data['otp']), 'Certificate renewed')),

            EditAction::make()->visible(fn (EgsUnit $r) => $this->can() && ! $r->production_certificate),
        ];
    }
}
