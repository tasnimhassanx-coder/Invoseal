<?php

namespace App\Filament\Resources\EgsUnitResource\Pages;

use App\Filament\Resources\EgsUnitResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditEgsUnit extends EditRecord
{
    protected static string $resource = EgsUnitResource::class;

    protected function getHeaderActions(): array
    {
        return [DeleteAction::make()];
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        $data['invoice_types'] = EgsUnitResource::typesToFlags((array) ($this->data['types'] ?? []));
        unset($data['types']);

        return $data;
    }
}
