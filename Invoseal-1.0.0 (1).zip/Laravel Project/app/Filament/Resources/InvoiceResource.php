<?php

namespace App\Filament\Resources;

use App\Enums\InvoiceStatus;
use App\Filament\Concerns\ScopedToCompanies;
use App\Filament\Resources\InvoiceResource\Pages;
use App\Models\Company;
use App\Models\Invoice;
use BackedEnum;
use Filament\Forms\Components\DatePicker;
use Filament\Infolists\Components\RepeatableEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\ViewEntry;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class InvoiceResource extends Resource
{
    use ScopedToCompanies;

    protected static ?string $model = Invoice::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedDocumentCheck;

    protected static string|\UnitEnum|null $navigationGroup = 'Gateway';

    protected static ?int $navigationSort = 1;

    protected static ?string $recordTitleAttribute = 'invoice_number';

    protected static ?string $modelLabel = 'invoice';

    public static function getNavigationBadge(): ?string
    {
        $n = static::getEloquentQuery()->whereIn('status', ['rejected', 'failed'])->count();

        return $n > 0 ? (string) $n : null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return 'danger';
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['invoice_number', 'uuid', 'buyer_name', 'external_reference'];
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->with('company'))
            ->defaultSort('id', 'desc')
            ->columns([
                TextColumn::make('invoice_number')->label('Invoice')->searchable()->sortable()->weight(FontWeight::SemiBold)
                    ->description(fn (Invoice $r) => $r->buyer_name ?: ($r->type === 'simplified' ? 'Walk-in customer' : null)),
                TextColumn::make('type')->badge()
                    ->formatStateUsing(fn (string $state, Invoice $r) => ($state === 'standard' ? 'B2B' : 'B2C').($r->sub_type !== 'invoice' ? ' · '.($r->sub_type === 'credit_note' ? 'Credit' : 'Debit') : ''))
                    ->color(fn (string $state) => $state === 'standard' ? 'info' : 'gray'),
                TextColumn::make('company.name')->label('Company')->toggleable(isToggledHiddenByDefault: fn () => Company::count() <= 1)->limit(24),
                TextColumn::make('issue_date')->date('d M Y')->sortable()->description(fn (Invoice $r) => substr((string) $r->issue_time, 0, 5)),
                TextColumn::make('tax_inclusive')->label('Total (SAR)')->money('SAR')->sortable()->alignEnd()->weight(FontWeight::SemiBold)
                    ->description(fn (Invoice $r) => 'VAT '.number_format((float) $r->tax_amount, 2)),
                TextColumn::make('status')->badge()->sortable()
                    ->formatStateUsing(fn (InvoiceStatus $state) => $state->label())->color(fn (InvoiceStatus $state) => $state->color()),
                IconColumn::make('has_warnings')->label('')->boolean()->trueIcon(Heroicon::OutlinedExclamationTriangle)->falseIcon('')
                    ->trueColor('warning')->tooltip('ZATCA returned warnings'),
                TextColumn::make('icv')->label('ICV')->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('external_reference')->label('ERP ref')->searchable()->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('created_at')->since()->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('status')->multiple()->options(collect(InvoiceStatus::cases())->mapWithKeys(fn ($s) => [$s->value => $s->label()])->all()),
                SelectFilter::make('type')->options(['standard' => 'Standard (B2B)', 'simplified' => 'Simplified (B2C)']),
                SelectFilter::make('sub_type')->label('Kind')->options(['invoice' => 'Invoice', 'credit_note' => 'Credit note', 'debit_note' => 'Debit note']),
                SelectFilter::make('company_id')->label('Company')->relationship('company', 'name', fn (Builder $query) => auth()->user()->scopeCompanies($query, 'id')),
                Filter::make('issue_date')->schema([DatePicker::make('from'), DatePicker::make('until')])
                    ->query(fn (Builder $query, array $data) => $query->when($data['from'] ?? null, fn ($q, $v) => $q->whereDate('issue_date', '>=', $v))
                        ->when($d['until'] ?? null, fn ($q, $v) => $q->whereDate('issue_date', '<=', $v))),
            ])
            ->recordUrl(fn (Invoice $r) => static::getUrl('view', ['record' => $r]))
            ->striped()
            ->poll('30s')
            ->emptyStateIcon(Heroicon::OutlinedDocumentCheck)
            ->emptyStateHeading('No invoices yet')
            ->emptyStateDescription('Invoices sent through the API, or created here, will appear in this list.');
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->columns(3)->components([
            Section::make('Summary')->columnSpan(2)->columns(3)->schema([
                TextEntry::make('invoice_number')->label('Invoice')->weight(FontWeight::Bold)->size('lg')->copyable(),
                TextEntry::make('status')->badge()->formatStateUsing(fn (InvoiceStatus $state) => $state->label())->color(fn (InvoiceStatus $state) => $state->color()),
                TextEntry::make('type')->badge()->formatStateUsing(fn ($state) => $state === 'standard' ? 'Standard (B2B) · clearance' : 'Simplified (B2C) · reporting'),
                TextEntry::make('issue_date')->date('d M Y')->helperText(fn (Invoice $r) => substr((string) $r->issue_time, 0, 8).' (Riyadh)'),
                TextEntry::make('company.name')->label('Seller'),
                TextEntry::make('buyer_name')->label('Buyer')->placeholder('Walk-in customer')->helperText(fn (Invoice $r) => $r->buyer_vat ? 'VAT '.$r->buyer_vat : null),
                TextEntry::make('tax_exclusive')->label('Subtotal')->money('SAR'),
                TextEntry::make('tax_amount')->label('VAT')->money('SAR'),
                TextEntry::make('tax_inclusive')->label('Total')->money('SAR')->weight(FontWeight::Bold)->size('lg'),
                TextEntry::make('billing_reference')->label('Original invoice')->visible(fn (Invoice $r) => $r->isCreditOrDebit()),
                TextEntry::make('reason')->visible(fn (Invoice $r) => $r->isCreditOrDebit())->columnSpan(2),
                TextEntry::make('last_error')->label('Last ZATCA message')->color('danger')->columnSpanFull()->visible(fn (Invoice $r) => filled($r->last_error)),
            ]),
            Section::make('ZATCA QR')->columnSpan(1)->schema([
                ViewEntry::make('qr_code')->hiddenLabel()->view('filament.entries.qr')->visible(fn (Invoice $r) => filled($r->qr_code)),
                TextEntry::make('qr_placeholder')->hiddenLabel()->default('Standard invoices receive their QR code from ZATCA when they are cleared.')
                    ->visible(fn (Invoice $r) => blank($r->qr_code))->color('gray'),
            ]),
            Section::make('Line items')->columnSpanFull()->schema([
                RepeatableEntry::make('lines')->label('')->table([
                    \Filament\Infolists\Components\RepeatableEntry\TableColumn::make('Item'),
                    \Filament\Infolists\Components\RepeatableEntry\TableColumn::make('Qty'),
                    \Filament\Infolists\Components\RepeatableEntry\TableColumn::make('Unit price'),
                    \Filament\Infolists\Components\RepeatableEntry\TableColumn::make('Discount'),
                    \Filament\Infolists\Components\RepeatableEntry\TableColumn::make('VAT'),
                    \Filament\Infolists\Components\RepeatableEntry\TableColumn::make('Total'),
                ])->schema([
                    TextEntry::make('name'),
                    TextEntry::make('quantity')->formatStateUsing(fn ($state) => rtrim(rtrim((string) $state, '0'), '.')),
                    TextEntry::make('unit_price')->money('SAR'),
                    TextEntry::make('discount')->money('SAR'),
                    TextEntry::make('tax_percent')->formatStateUsing(fn ($state, $record) => rtrim(rtrim((string) $state, '0'), '.').'% '.($record->tax_category ?? '')),
                    TextEntry::make('gross')->money('SAR')->weight(FontWeight::SemiBold),
                ]),
            ]),
            Section::make('ZATCA submissions')->columnSpan(2)->collapsible()->schema([
                RepeatableEntry::make('submissions')->label('')->schema([
                    Grid::make(4)->schema([
                        TextEntry::make('attempt')->label('Attempt'),
                        TextEntry::make('result')->badge()->color(fn ($state) => match ($state) { 'accepted' => 'success', 'warning' => 'warning', 'rejected' => 'danger', default => 'gray' }),
                        TextEntry::make('http_status')->label('HTTP'),
                        TextEntry::make('created_at')->since(),
                    ]),
                    TextEntry::make('errors')->label('Errors')->listWithLineBreaks()->color('danger')->visible(fn ($record) => filled($record?->errors))
                        ->formatStateUsing(fn ($state) => is_array($state) ? (($state['code'] ?? '').' '.($state['message'] ?? '')) : $state),
                    TextEntry::make('warnings')->label('Warnings')->listWithLineBreaks()->color('warning')->visible(fn ($record) => filled($record?->warnings))
                        ->formatStateUsing(fn ($state) => is_array($state) ? (($state['code'] ?? '').' '.($state['message'] ?? '')) : $state),
                    TextEntry::make('transport_error')->label('Network')->color('danger')->visible(fn ($record) => filled($record?->transport_error)),
                ])->placeholder('Not submitted yet'),
            ]),
            Section::make('Integrity')->columnSpan(1)->collapsible()->schema([
                TextEntry::make('uuid')->label('UUID')->copyable()->extraAttributes(['class' => 'inv-mono']),
                TextEntry::make('icv')->label('Invoice counter (ICV)'),
                TextEntry::make('invoice_hash')->label('Invoice hash')->copyable()->extraAttributes(['class' => 'inv-mono']),
                TextEntry::make('pih')->label('Previous invoice hash')->extraAttributes(['class' => 'inv-mono']),
                TextEntry::make('retention_until')->label('Archived until')->date('d M Y'),
            ]),
            Section::make('Signed XML')->columnSpanFull()->collapsible()->collapsed()->schema([
                ViewEntry::make('signed_xml')->label('')->view('filament.entries.xml'),
            ]),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListInvoices::route('/'),
            'create' => Pages\CreateInvoice::route('/create'),
            'view' => Pages\ViewInvoice::route('/{record}'),
        ];
    }
}
