<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AuditLogResource\Pages;
use App\Models\AuditLog;
use App\Models\Company;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class AuditLogResource extends Resource
{
    protected static ?string $model = AuditLog::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedClipboardDocumentList;

    protected static string|\UnitEnum|null $navigationGroup = 'Administration';

    protected static ?int $navigationSort = 2;

    protected static ?string $modelLabel = 'audit entry';

    protected static ?string $pluralModelLabel = 'audit log';

    public static function getEloquentQuery(): Builder
    {
        $q = parent::getEloquentQuery()->with(['user', 'company', 'apiKey']);
        $user = auth()->user();
        if (! $user) {
            return $q->whereRaw('1 = 0');
        }
        $ids = $user->companyIds();

        return $ids === null ? $q : $q->whereIn('company_id', $ids);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('id', 'desc')
            ->poll('60s')
            ->columns([
                TextColumn::make('created_at')->label('When')->dateTime('d M Y, H:i:s')->sortable()->description(fn (AuditLog $r) => $r->created_at?->diffForHumans()),
                TextColumn::make('action')->badge()->color('gray')->searchable()->fontFamily('mono'),
                TextColumn::make('actor')->state(fn (AuditLog $r) => $r->user?->name ?? ($r->apiKey ? 'API · '.$r->apiKey->name : 'System'))->weight(FontWeight::Medium),
                TextColumn::make('company.name')->placeholder('—')->toggleable(),
                TextColumn::make('subject')->state(fn (AuditLog $r) => $r->subject_type ? $r->subject_type.' #'.$r->subject_id : '—')->toggleable(),
                TextColumn::make('ip')->label('IP')->fontFamily('mono')->toggleable()->placeholder('—'),
                TextColumn::make('meta')->state(fn (AuditLog $r) => $r->meta ? json_encode($r->meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null)
                    ->limit(60)->tooltip(fn (AuditLog $r) => $r->meta ? json_encode($r->meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null)->toggleable(),
            ])
            ->filters([
                SelectFilter::make('company_id')->label('Company')->native(false)
                    ->options(fn () => auth()->user()->scopeCompanies(Company::query(), 'id')->orderBy('name')->pluck('name', 'id')),
                SelectFilter::make('action')->native(false)->searchable()
                    ->options(fn () => AuditLog::query()->distinct()->orderBy('action')->pluck('action', 'action')),
            ])
            ->emptyStateIcon(Heroicon::OutlinedClipboardDocumentList)->emptyStateHeading('Nothing recorded yet');
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListAuditLogs::route('/')];
    }
}
