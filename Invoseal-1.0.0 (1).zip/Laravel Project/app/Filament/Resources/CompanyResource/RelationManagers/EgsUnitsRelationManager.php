<?php

namespace App\Filament\Resources\CompanyResource\RelationManagers;

use App\Filament\Resources\EgsUnitResource;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class EgsUnitsRelationManager extends RelationManager
{
    protected static string $relationship = 'egsUnits';

    protected static ?string $title = 'EGS units';

    public function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->weight('semibold'),
            TextColumn::make('status')->badge()->formatStateUsing(fn ($state) => $state->label())->color(fn ($state) => $state->color()),
            TextColumn::make('environment')->badge()->color('gray'),
            TextColumn::make('certificate_expires_at')->label('Certificate expires')->date('d M Y')->placeholder('-'),
            TextColumn::make('last_icv')->label('Invoices signed'),
        ])->recordUrl(fn ($record) => EgsUnitResource::getUrl('view', ['record' => $record]))
            ->emptyStateHeading('No EGS units')->emptyStateDescription('Create one under Setup → EGS units, then run the onboarding wizard.');
    }
}
