<?php

namespace App\Filament\Resources\CompanyResource\RelationManagers;

use Filament\Actions\CreateAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class BranchesRelationManager extends RelationManager
{
    protected static string $relationship = 'branches';

    public function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('name')->required()->maxLength(255),
            TextInput::make('code')->maxLength(30),
            TextInput::make('city'),
            Toggle::make('is_active')->default(true),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->weight('semibold'), TextColumn::make('code'), TextColumn::make('city'),
            IconColumn::make('is_active')->boolean(),
        ])->headerActions([CreateAction::make()])->recordActions([EditAction::make(), DeleteAction::make()])
            ->emptyStateHeading('No branches')->emptyStateDescription('Branches let you give each outlet its own EGS unit.');
    }
}
