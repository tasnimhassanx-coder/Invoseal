<?php

namespace App\Filament\Resources\CompanyResource\RelationManagers;

use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class ApiKeysRelationManager extends RelationManager
{
    protected static string $relationship = 'apiKeys';

    protected static ?string $title = 'API keys';

    public function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->weight('semibold'),
            TextColumn::make('key_prefix')->label('Key')->formatStateUsing(fn ($state) => $state.'…')->fontFamily('mono'),
            TextColumn::make('last_used_at')->since()->placeholder('Never'),
            TextColumn::make('revoked_at')->label('Status')->badge()->formatStateUsing(fn ($state) => $state ? 'Revoked' : 'Active')->color(fn ($state) => $state ? 'danger' : 'success'),
        ])->emptyStateHeading('No API keys')->emptyStateDescription('Create keys under Setup → API keys.');
    }
}
