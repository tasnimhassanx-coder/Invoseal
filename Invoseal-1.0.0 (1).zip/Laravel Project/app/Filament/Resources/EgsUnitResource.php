<?php

namespace App\Filament\Resources;

use App\Enums\EgsStatus;
use App\Filament\Concerns\ScopedToCompanies;
use App\Filament\Resources\EgsUnitResource\Pages;
use App\Models\Branch;
use App\Models\Company;
use App\Models\EgsUnit;
use BackedEnum;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\ViewEntry;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class EgsUnitResource extends Resource
{
    use ScopedToCompanies;

    protected static ?string $model = EgsUnit::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedFingerPrint;

    protected static string|\UnitEnum|null $navigationGroup = 'Setup';

    protected static ?int $navigationSort = 2;

    protected static ?string $modelLabel = 'EGS unit';

    protected static ?string $recordTitleAttribute = 'name';

    public static function form(Schema $schema): Schema
    {
        return $schema->columns(2)->components([
            Section::make('Unit')->columnSpanFull()->columns(2)->schema([
                Select::make('company_id')->label('Company')->required()->native(false)->live()
                    ->options(fn () => auth()->user()->scopeCompanies(Company::query(), 'id')->pluck('name', 'id'))
                    ->afterStateUpdated(fn ($set, $state) => $set('environment', Company::find($state)?->environment ?? 'sandbox')),
                Select::make('branch_id')->label('Branch')->native(false)->placeholder('Head office')
                    ->options(fn (Get $get) => Branch::where('company_id', $get('company_id'))->pluck('name', 'id')),
                TextInput::make('name')->label('Unit name')->required()->maxLength(120)->helperText('For example "POS-1" or "ERP gateway". It appears in the certificate.'),
                Select::make('environment')->native(false)->required()->default('sandbox')
                    ->options(['sandbox' => 'Sandbox', 'simulation' => 'Simulation', 'production' => 'Production'])
                    ->helperText('Must match the environment where you generate the OTP in the Fatoora portal.'),
                CheckboxList::make('types')->label('Invoice types this unit will issue')->required()->columns(2)->default(['standard', 'simplified'])
                    ->options(['standard' => 'Standard tax invoices (B2B · clearance)', 'simplified' => 'Simplified tax invoices (B2C · reporting)'])
                    ->afterStateHydrated(function (CheckboxList $c, ?EgsUnit $record) {
                        if ($record) {
                            $f = str_pad($record->invoice_types, 2, '0');
                            $c->state(array_values(array_filter([$f[0] === '1' ? 'standard' : null, $f[1] === '1' ? 'simplified' : null])));
                        }
                    })->dehydrated(false)->columnSpanFull(),
            ]),
        ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->columns(3)->components([
            Section::make()->columnSpanFull()->schema([
                ViewEntry::make('status')->label('')->view('filament.entries.onboarding-steps'),
            ]),
            Section::make('Unit')->columnSpan(1)->schema([
                TextEntry::make('company.name')->label('Company'),
                TextEntry::make('name')->weight(FontWeight::Bold),
                TextEntry::make('status')->badge()->formatStateUsing(fn (EgsStatus $state) => $state->label())->color(fn (EgsStatus $state) => $state->color()),
                TextEntry::make('environment')->badge()->color('gray'),
                TextEntry::make('invoice_types')->label('Invoice types')->formatStateUsing(function ($state) {
                    $f = str_pad((string) $state, 2, '0');

                    return implode(' + ', array_filter([$f[0] === '1' ? 'Standard (B2B)' : null, $f[1] === '1' ? 'Simplified (B2C)' : null]));
                }),
            ]),
            Section::make('Certificate & chain')->columnSpan(1)->schema([
                TextEntry::make('certificate_expires_at')->label('Production certificate expires')->dateTime('d M Y')->placeholder('Not issued yet')
                    ->color(fn (EgsUnit $r) => ($d = $r->daysToExpiry()) !== null && $d <= (int) config('invoseal.certificate_warning_days') ? 'danger' : null)
                    ->helperText(fn (EgsUnit $r) => ($d = $r->daysToExpiry()) === null ? null : ($d < 0 ? 'Expired' : "{$d} days left")),
                TextEntry::make('last_icv')->label('Invoices signed (ICV)'),
                TextEntry::make('last_pih')->label('Last invoice hash')->placeholder('-')->extraAttributes(['class' => 'inv-mono']),
                TextEntry::make('onboarded_at')->label('Went live')->dateTime('d M Y H:i')->placeholder('-'),
            ]),
            Section::make('Compliance check results')->columnSpan(1)->schema([
                ViewEntry::make('compliance_results')->label('')->view('filament.entries.compliance'),
            ]),
            Section::make('Certificate signing request (CSR)')->columnSpanFull()->collapsible()->collapsed()
                ->description('The private key never leaves this server and is stored encrypted.')->schema([
                    TextEntry::make('csr')->label('')->placeholder('Generate the CSR in step 1.')->copyable()->extraAttributes(['class' => 'inv-mono', 'style' => 'white-space:pre-wrap']),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->defaultSort('id', 'desc')
            ->modifyQueryUsing(fn ($query) => $query->with('company')->withCount('invoices'))
            ->columns([
                TextColumn::make('name')->searchable()->weight(FontWeight::SemiBold)->description(fn (EgsUnit $r) => $r->company->name),
                TextColumn::make('status')->badge()->formatStateUsing(fn (EgsStatus $state) => $state->label())->color(fn (EgsStatus $state) => $state->color()),
                TextColumn::make('environment')->badge()->color('gray'),
                TextColumn::make('invoice_types')->label('Types')->formatStateUsing(function ($state) {
                    $f = str_pad((string) $state, 2, '0');

                    return implode(' + ', array_filter([$f[0] === '1' ? 'B2B' : null, $f[1] === '1' ? 'B2C' : null]));
                }),
                TextColumn::make('certificate_expires_at')->label('Certificate')->date('d M Y')->placeholder('-')
                    ->color(fn (EgsUnit $r) => ($d = $r->daysToExpiry()) !== null && $d <= (int) config('invoseal.certificate_warning_days') ? 'danger' : null),
                TextColumn::make('invoices_count')->label('Invoices')->alignCenter(),
            ])
            ->recordUrl(fn (EgsUnit $r) => static::getUrl('view', ['record' => $r]))
            ->emptyStateIcon(Heroicon::OutlinedFingerPrint)->emptyStateHeading('No EGS units')
            ->emptyStateDescription('An EGS unit holds the certificate that signs your invoices. Create one and run the onboarding wizard.');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListEgsUnits::route('/'),
            'create' => Pages\CreateEgsUnit::route('/create'),
            'view' => Pages\ViewEgsUnit::route('/{record}'),
            'edit' => Pages\EditEgsUnit::route('/{record}/edit'),
        ];
    }

    /** ["standard","simplified"] -> "11" etc. (stored as a 4-flag string, e.g. 1100) */
    public static function typesToFlags(array $types): string
    {
        return (in_array('standard', $types, true) ? '1' : '0').(in_array('simplified', $types, true) ? '1' : '0').'00';
    }
}
