<?php

namespace App\Filament\Resources;

use App\Filament\Concerns\ScopedToCompanies;
use App\Filament\Resources\CompanyResource\Pages;
use App\Filament\Resources\CompanyResource\RelationManagers;
use App\Models\Company;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Support\Str;

class CompanyResource extends Resource
{
    use ScopedToCompanies;

    protected static function companyColumn(): string
    {
        return 'id';
    }

    protected static ?string $model = Company::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedBuildingOffice2;

    protected static string|\UnitEnum|null $navigationGroup = 'Setup';

    protected static ?int $navigationSort = 1;

    protected static ?string $recordTitleAttribute = 'name';

    public static function form(Schema $schema): Schema
    {
        return $schema->columns(3)->components([
            Section::make('Legal identity')->columnSpan(2)->columns(2)->schema([
                TextInput::make('name')->label('Registered name (English)')->required()->maxLength(255)->helperText('Printed on every invoice as the seller name.'),
                TextInput::make('name_ar')->label('Registered name (Arabic)')->maxLength(255)->extraInputAttributes(['dir' => 'rtl']),
                TextInput::make('vat_number')->label('VAT number')->required()->length(15)->regex('/^3\d{13}3$/')
                    ->validationMessages(['regex' => 'A Saudi VAT number has 15 digits and starts and ends with 3.'])->placeholder('3xxxxxxxxxxxxx3'),
                TextInput::make('crn')->label('Commercial registration / ID')->required()->maxLength(30),
                Select::make('id_scheme')->label('ID type')->native(false)->default('CRN')
                    ->options(['CRN' => 'Commercial registration (CRN)', 'MOM' => 'Momra licence', 'MLS' => 'MLSD licence', 'SAG' => 'Sagia licence', 'TIN' => 'Tax identification (TIN)', '700' => '700 number', 'OTH' => 'Other']),
                TextInput::make('business_category')->label('Business category')->default('Supply activities')->required()->maxLength(120),
            ]),
            Section::make('Status')->columnSpan(1)->schema([
                Select::make('environment')->native(false)->required()->default('sandbox')
                    ->options(['sandbox' => 'Sandbox (developer portal)', 'simulation' => 'Simulation (pre-production)', 'production' => 'Production (real invoices)'])
                    ->helperText('Each EGS unit is onboarded against its own environment.'),
                Toggle::make('is_active')->label('Company is active')->default(true)->helperText('Inactive companies cannot issue invoices or use API keys.'),
            ]),
            Section::make('National address')->description('ZATCA rejects invoices whose seller address is incomplete.')->columnSpan(2)->columns(3)->schema([
                TextInput::make('street')->required()->columnSpan(2),
                TextInput::make('building_number')->label('Building no.')->required()->length(4)->numeric(false)->regex('/^\d{4}$/'),
                TextInput::make('plot_identification')->label('Plot no.')->maxLength(10),
                TextInput::make('district')->required(),
                TextInput::make('city')->required(),
                TextInput::make('postal_zone')->label('Postal code')->required()->regex('/^\d{5}$/')->length(5),
                Select::make('country')->native(false)->default('SA')->options(['SA' => 'Saudi Arabia'])->required(),
            ]),
            Section::make('Webhooks')->description('Invoseal posts invoice.cleared / reported / rejected / failed events here.')->columnSpan(1)->schema([
                TextInput::make('webhook_url')->label('Endpoint URL')->url()->maxLength(500)->placeholder('https://erp.example.com/hooks/invoseal'),
                TextInput::make('webhook_secret')->label('Signing secret')->readOnly()->copyable()->dehydrated(false)
                    ->visibleOn('edit')->helperText('HMAC-SHA256 of "timestamp.body" is sent in X-Invoseal-Signature.'),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('name')
            ->modifyQueryUsing(fn ($query) => $query->withCount(['invoices', 'egsUnits']))
            ->columns([
                TextColumn::make('name')->searchable()->weight(FontWeight::SemiBold)->description(fn (Company $r) => $r->name_ar),
                TextColumn::make('vat_number')->label('VAT')->searchable()->copyable(),
                TextColumn::make('environment')->badge()->color(fn (string $state) => match ($state) { 'production' => 'success', 'simulation' => 'warning', default => 'gray' }),
                TextColumn::make('egs_units_count')->label('EGS units')->alignCenter(),
                TextColumn::make('invoices_count')->label('Invoices')->alignCenter()->numeric(),
                IconColumn::make('is_active')->label('Active')->boolean(),
            ])
            ->recordActions([
                EditAction::make(),
                Action::make('rotateSecret')->label('Rotate webhook secret')->icon(Heroicon::OutlinedArrowPath)->color('gray')
                    ->visible(fn (Company $r) => auth()->user()->can('update', $r))->requiresConfirmation()
                    ->action(fn (Company $r) => $r->update(['webhook_secret' => 'whsec_'.Str::random(40)])),
            ])
            ->emptyStateIcon(Heroicon::OutlinedBuildingOffice2)->emptyStateHeading('No companies')->emptyStateDescription('Add the legal entity that issues invoices.');
    }

    public static function getRelations(): array
    {
        return [
            RelationManagers\EgsUnitsRelationManager::class,
            RelationManagers\BranchesRelationManager::class,
            RelationManagers\ApiKeysRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCompanies::route('/'),
            'create' => Pages\CreateCompany::route('/create'),
            'edit' => Pages\EditCompany::route('/{record}/edit'),
        ];
    }
}
