<?php

namespace App\Filament\Resources;

use App\Filament\Concerns\ScopedToCompanies;
use App\Filament\Resources\ApiKeyResource\Pages;
use App\Models\ApiKey;
use App\Models\Company;
use App\Services\AuditLogger;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class ApiKeyResource extends Resource
{
    use ScopedToCompanies;

    protected static ?string $model = ApiKey::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedKey;

    protected static string|\UnitEnum|null $navigationGroup = 'Setup';

    protected static ?int $navigationSort = 3;

    protected static ?string $modelLabel = 'API key';

    protected static ?string $recordTitleAttribute = 'name';

    /** The "Create API key" action's form (keys are only ever created through it, so the secret can be shown once). */
    public static function createAction(): Action
    {
        return Action::make('create')
            ->label('Create API key')
            ->icon(Heroicon::OutlinedPlus)
            ->visible(fn () => auth()->user()?->can('create', ApiKey::class))
            ->modalWidth('lg')
            ->modalHeading('Create API key')
            ->modalDescription('The key is displayed once. Store it in your ERP’s secret manager.')
            ->schema([
                Select::make('company_id')->label('Company')->native(false)->required()->searchable()
                    ->options(fn () => auth()->user()->scopeCompanies(Company::query(), 'id')->orderBy('name')->pluck('name', 'id')),
                TextInput::make('name')->label('Label')->required()->maxLength(120)->placeholder('e.g. ERPNext production'),
                CheckboxList::make('abilities')->options([
                    'invoices:read' => 'Read invoices, XML and PDF',
                    'invoices:write' => 'Validate, issue and retry invoices',
                ])->default(ApiKey::ABILITIES)->required(),
                TagsInput::make('ip_allowlist')->label('Allowed IPs (optional)')->placeholder('203.0.113.4 or 198.51.100.0/24')
                    ->helperText('Leave empty to allow any IP.')->nestedRecursiveRules([new \App\Rules\IpOrCidr()]),
                DateTimePicker::make('expires_at')->label('Expires (optional)')->native(false)->minDate(now()),
            ])
            ->action(function (array $data) {
                $user = auth()->user();
                abort_unless($user->can('create', ApiKey::class), 403);
                $company = $user->scopeCompanies(Company::query(), 'id')->findOrFail($data['company_id']);
                [$key, $plain] = ApiKey::issue($company, $data['name'], $data['abilities'], $data['ip_allowlist'] ?: null, $data['expires_at'] ?? null);
                AuditLogger::log('api_key.created', $key, ['name' => $key->name], $company);

                Notification::make()->success()->persistent()
                    ->title('API key created — copy it now')
                    ->body(new \Illuminate\Support\HtmlString(
                        '<div class="inv-secret">'.e($plain).'</div><div style="margin-top:.5rem;font-size:.8rem">It will not be shown again. Send it as <code>Authorization: Bearer …</code>.</div>'
                    ))->send();
            });
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->modifyQueryUsing(fn ($query) => $query->with('company'))
            ->columns([
                TextColumn::make('name')->searchable()->weight(FontWeight::SemiBold)->description(fn (ApiKey $r) => $r->company?->name),
                TextColumn::make('key_prefix')->label('Key')->fontFamily('mono')->formatStateUsing(fn ($state) => $state.'…'),
                TextColumn::make('abilities')->badge()->separator(',')->formatStateUsing(fn ($state) => str_replace('invoices:', '', (string) $state)),
                TextColumn::make('ip_allowlist')->label('IP allowlist')->badge()->color('gray')->placeholder('Any IP')->separator(','),
                TextColumn::make('last_used_at')->label('Last used')->since()->placeholder('Never')->description(fn (ApiKey $r) => $r->last_used_ip),
                TextColumn::make('status')->badge()->state(fn (ApiKey $r) => $r->revoked_at ? 'Revoked' : ($r->expires_at && $r->expires_at->isPast() ? 'Expired' : 'Active'))
                    ->color(fn ($state) => $state === 'Active' ? 'success' : 'danger'),
            ])
            ->recordActions([
                Action::make('revoke')->icon(Heroicon::OutlinedNoSymbol)->color('danger')->requiresConfirmation()
                    ->modalDescription('Requests using this key will be rejected immediately. This cannot be undone.')
                    ->visible(fn (ApiKey $r) => $r->revoked_at === null && auth()->user()->can('update', $r))
                    ->action(function (ApiKey $r) {
                        abort_unless(auth()->user()->can('update', $r), 403);
                        $r->update(['revoked_at' => now()]);
                        AuditLogger::log('api_key.revoked', $r, ['name' => $r->name]);
                        Notification::make()->title('Key revoked')->success()->send();
                    }),
            ])
            ->emptyStateIcon(Heroicon::OutlinedKey)->emptyStateHeading('No API keys yet')
            ->emptyStateDescription('Create a key so your ERP, POS or website can send invoices to Invoseal.');
    }

    public static function canCreate(): bool
    {
        return false; // creation happens through the header action above
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListApiKeys::route('/')];
    }
}
