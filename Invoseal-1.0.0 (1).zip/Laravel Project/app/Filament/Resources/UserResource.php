<?php

namespace App\Filament\Resources;

use App\Enums\Role;
use App\Filament\Resources\UserResource\Pages;
use App\Models\User;
use BackedEnum;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class UserResource extends Resource
{
    protected static ?string $model = User::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedUsers;

    protected static string|\UnitEnum|null $navigationGroup = 'Administration';

    protected static ?int $navigationSort = 1;

    protected static ?string $recordTitleAttribute = 'name';

    public static function form(Schema $schema): Schema
    {
        return $schema->columns(3)->components([
            Section::make('Account')->columnSpan(2)->columns(2)->schema([
                TextInput::make('name')->required()->maxLength(255),
                TextInput::make('email')->email()->required()->unique(ignoreRecord: true)->maxLength(255),
                TextInput::make('password')->password()->revealable()
                    ->required(fn (string $operation) => $operation === 'create')
                    ->minLength(10)->dehydrated(fn ($state) => filled($state))
                    ->helperText(fn (string $operation) => $operation === 'edit' ? 'Leave empty to keep the current password.' : 'At least 10 characters.'),
                Select::make('locale')->native(false)->default('en')->options(['en' => 'English', 'bn' => 'বাংলা', 'ar' => 'العربية'])
                    ->helperText('Language of validation messages shown to this user.'),
            ]),
            Section::make('Access')->columnSpan(1)->schema([
                Select::make('role')->native(false)->required()->default('operator')
                    ->options(collect(Role::cases())->mapWithKeys(fn (Role $r) => [$r->value => $r->label()]))
                    ->helperText('Admin: everything · Manager: setup + invoices · Operator: invoices · Viewer: read only.'),
                Select::make('companies')->relationship('companies', 'name')->multiple()->preload()->native(false)
                    ->helperText('Non-admins only see the companies selected here.'),
                Toggle::make('is_active')->label('Can sign in')->default(true),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('name')
            ->columns([
                TextColumn::make('name')->searchable()->weight(FontWeight::SemiBold)->description(fn (User $r) => $r->email),
                TextColumn::make('role')->badge()->formatStateUsing(fn ($state) => $state instanceof Role ? $state->label() : $state)
                    ->color(fn ($state) => match ($state instanceof Role ? $state->value : $state) { 'admin' => 'primary', 'manager' => 'info', 'operator' => 'gray', default => 'warning' }),
                TextColumn::make('companies.name')->badge()->color('gray')->limitList(3)->placeholder('All / none'),
                TextColumn::make('last_login_at')->label('Last sign-in')->since()->placeholder('Never'),
                IconColumn::make('is_active')->label('Active')->boolean(),
            ])
            ->recordActions([EditAction::make()])
            ->emptyStateHeading('No users');
    }

    /** The public demo must not let visitors lock each other out. */
    public static function canCreate(): bool
    {
        return ! config('invoseal.demo_mode') && parent::canCreate();
    }

    public static function canEdit(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return ! config('invoseal.demo_mode') && parent::canEdit($record);
    }

    public static function canDelete(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return ! config('invoseal.demo_mode') && parent::canDelete($record);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
        ];
    }
}
