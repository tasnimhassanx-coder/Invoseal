<?php

namespace App\Filament\Resources\InvoiceResource\Pages;

use App\Filament\Resources\InvoiceResource;
use App\Filament\Resources\InvoiceResource\Support\InvoiceForm;
use App\Models\Company;
use App\Models\Invoice;
use App\Services\InvoiceService;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;
use Filament\Schemas\Schema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\HtmlString;

class CreateInvoice extends CreateRecord
{
    protected static string $resource = InvoiceResource::class;

    protected static bool $canCreateAnother = false;

    protected ?string $heading = 'New invoice';

    public function form(Schema $schema): Schema
    {
        return InvoiceForm::configure($schema);
    }

    /** "Issue credit note" from an invoice pre-fills the form. */
    public function mount(): void
    {
        parent::mount();

        if ($id = request()->query('credit_for')) {
            $orig = auth()->user()->scopeCompanies(Invoice::query())->with('lines')->find($id);
            if ($orig) {
                $this->form->fill([
                    'company_id' => $orig->company_id,
                    'invoice_number' => 'CN-'.$orig->invoice_number,
                    'type' => $orig->type,
                    'sub_type' => 'credit_note',
                    'issue_date' => now('Asia/Riyadh')->toDateString(),
                    'issue_time' => now('Asia/Riyadh')->format('H:i:s'),
                    'payment_means' => $orig->payment_means,
                    'billing_reference' => $orig->invoice_number,
                    'reason' => '',
                    'buyer' => $orig->buyer ?? [],
                    'lines' => $orig->lines->map(fn ($l) => [
                        'name' => $l->name, 'quantity' => (float) $l->quantity, 'unit_price' => (float) $l->unit_price,
                        'discount' => (float) $l->discount, 'tax_category' => $l->tax_category, 'unit_code' => $l->unit_code,
                    ])->all(),
                ]);
            }
        }
    }

    protected function handleRecordCreation(array $data): Model
    {
        $company = auth()->user()->scopeCompanies(Company::query(), 'id')->findOrFail($data['company_id']);
        abort_unless(auth()->user()->can('create', Invoice::class), 403);

        $result = app(InvoiceService::class)->issue($company, InvoiceForm::toPayload($data));

        if (! $result->ok()) {
            $items = collect($result->issuesArray(app()->getLocale()))->where('severity', 'error')
                ->map(fn ($i) => '<li>'.e($i['message']).'</li>')->implode('');
            Notification::make()->danger()->persistent()->title('The invoice was not accepted')
                ->body(new HtmlString('<ul style="list-style:disc;padding-inline-start:1.1rem">'.$items.'</ul>'))->send();
            $this->halt();
        }

        return $result->invoice;
    }

    protected function getCreatedNotification(): ?Notification
    {
        $s = $this->record->status;

        return Notification::make()->title('Invoice '.$this->record->invoice_number.' - '.$s->label())
            ->{$s->color() === 'danger' ? 'danger' : ($s->color() === 'success' ? 'success' : 'warning')}();
    }
}
