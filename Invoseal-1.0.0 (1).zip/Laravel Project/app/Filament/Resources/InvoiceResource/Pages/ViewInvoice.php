<?php

namespace App\Filament\Resources\InvoiceResource\Pages;

use App\Enums\InvoiceStatus;
use App\Filament\Resources\InvoiceResource;
use App\Models\Invoice;
use App\Services\ArchiveService;
use App\Services\AuditLogger;
use App\Services\InvoicePdf;
use App\Services\SubmissionService;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ViewRecord;
use Filament\Support\Icons\Heroicon;

class ViewInvoice extends ViewRecord
{
    protected static string $resource = InvoiceResource::class;

    public function getTitle(): string
    {
        return 'Invoice '.$this->record->invoice_number;
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('retry')
                ->label('Send to ZATCA again')->icon(Heroicon::OutlinedArrowPath)->color('warning')
                ->visible(fn (Invoice $r) => in_array($r->status, [InvoiceStatus::Pending, InvoiceStatus::Failed], true) && auth()->user()->can('retry', $r))
                ->requiresConfirmation()
                ->action(function (Invoice $record, SubmissionService $svc) {
                    AuditLogger::log('invoice.retry_requested', $record);
                    $status = $svc->submit($record);
                    $this->record->refresh();
                    Notification::make()->title('Submission result: '.$status->label())
                        ->color($status->color())->{$status->color() === 'danger' ? 'danger' : ($status->color() === 'success' ? 'success' : 'warning')}()->send();
                }),
            Action::make('creditNote')
                ->label('Issue credit note')->icon(Heroicon::OutlinedReceiptPercent)->color('gray')
                ->visible(fn (Invoice $r) => $r->sub_type === 'invoice' && $r->status->isFinal() && $r->status !== InvoiceStatus::Rejected && auth()->user()->can('create', Invoice::class))
                ->url(fn (Invoice $r) => InvoiceResource::getUrl('create', ['credit_for' => $r->id])),
            Action::make('xml')
                ->label('XML')->icon(Heroicon::OutlinedArrowDownTray)->color('gray')
                ->action(fn (Invoice $r) => response()->streamDownload(fn () => print ($r->finalXml()), $r->invoice_number.'.xml', ['Content-Type' => 'application/xml'])),
            Action::make('pdf')
                ->label('PDF/A-3')->icon(Heroicon::OutlinedPrinter)->color('gray')
                ->action(fn (Invoice $r) => response()->streamDownload(fn () => print ((new InvoicePdf())->render($r)), $r->invoice_number.'.pdf', ['Content-Type' => 'application/pdf'])),
            Action::make('verify')
                ->label('Verify integrity')->icon(Heroicon::OutlinedShieldCheck)->color('gray')
                ->modalHeading('Integrity check')->modalSubmitAction(false)->modalCancelActionLabel('Close')
                ->modalContent(function (Invoice $r) {
                    $c = (new ArchiveService())->verify($r);
                    $labels = [
                        'hash' => 'Invoice hash matches the XML', 'signature' => 'ECDSA signature is valid for the certificate',
                        'signed_properties' => 'XAdES signed properties digest', 'certificate_digest' => 'Certificate digest',
                        'stored_hash_matches' => 'Stored hash equals recomputed hash', 'archive_file_matches' => 'Archive file is identical to the database copy',
                    ];

                    return view('filament.modals.integrity', ['checks' => $c, 'labels' => $labels]);
                }),
        ];
    }
}
