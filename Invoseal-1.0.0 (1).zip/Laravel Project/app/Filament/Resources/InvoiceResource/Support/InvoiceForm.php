<?php

namespace App\Filament\Resources\InvoiceResource\Support;

use App\Models\Company;
use App\Zatca\Calculator;
use App\Zatca\Dto\InvoiceData;
use App\Zatca\Dto\Line;
use App\Zatca\Dto\Party;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\TimePicker;
use Filament\Forms\Components\ToggleButtons;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Text;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;

/** The "New invoice" form: same payload shape as the REST API. */
final class InvoiceForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->columns(3)->components([
            Section::make('Document')->columnSpan(2)->columns(3)->schema([
                Select::make('company_id')->label('Company')->required()->native(false)
                    ->options(fn () => auth()->user()->scopeCompanies(Company::query()->where('is_active', true), 'id')->pluck('name', 'id'))
                    ->default(fn () => auth()->user()->scopeCompanies(Company::query()->where('is_active', true), 'id')->value('id'))->live()->columnSpan(2),
                TextInput::make('invoice_number')->label('Invoice number')->required()->maxLength(127)
                    ->default(fn () => 'INV-'.now('Asia/Riyadh')->format('ymd-His')),
                ToggleButtons::make('type')->label('Invoice type')->inline()->required()->default('simplified')->live()
                    ->options(['simplified' => 'Simplified (B2C) · reporting', 'standard' => 'Standard (B2B) · clearance'])->columnSpan(2),
                ToggleButtons::make('sub_type')->label('Kind')->inline()->required()->default('invoice')->live()
                    ->options(['invoice' => 'Invoice', 'credit_note' => 'Credit note', 'debit_note' => 'Debit note']),
                DatePicker::make('issue_date')->required()->default(fn () => now('Asia/Riyadh')->toDateString())->native(false)->displayFormat('d M Y'),
                TimePicker::make('issue_time')->required()->seconds(true)->default(fn () => now('Asia/Riyadh')->format('H:i:s'))->native(false),
                Select::make('payment_means')->label('Payment')->native(false)->default('10')->required()
                    ->options(['10' => 'Cash', '30' => 'Credit transfer', '42' => 'Bank account', '48' => 'Card', '1' => 'Not defined']),
                TextInput::make('billing_reference')->label('Original invoice number')->visible(fn (Get $get) => $get('sub_type') !== 'invoice')->required(fn (Get $get) => $get('sub_type') !== 'invoice'),
                TextInput::make('reason')->label('Reason')->maxLength(255)->visible(fn (Get $get) => $get('sub_type') !== 'invoice')->required(fn (Get $get) => $get('sub_type') !== 'invoice')->columnSpan(2),
            ]),
            Section::make('Totals')->columnSpan(1)->schema([
                Text::make(fn (Get $get) => new \Illuminate\Support\HtmlString(self::totalsHtml($get("company_id"), $get("type"), $get("lines") ?? []))),
            ]),
            Section::make('Buyer')->columnSpanFull()->columns(4)
                ->description(fn (Get $get) => $get('type') === 'standard' ? 'Required for standard (B2B) invoices' : 'Optional for simplified (B2C) invoices')
                ->collapsible()->schema([
                    TextInput::make('buyer.name')->label('Name')->required(fn (Get $get) => $get('type') === 'standard')->maxLength(255)->columnSpan(2),
                    TextInput::make('buyer.vat')->label('VAT number')->maxLength(15)->required(fn (Get $get) => $get('type') === 'standard')->placeholder('3xxxxxxxxxxxxx3'),
                    TextInput::make('buyer.id_number')->label('CR / ID number')->maxLength(30),
                    TextInput::make('buyer.street')->label('Street')->columnSpan(2),
                    TextInput::make('buyer.building')->label('Building no.')->maxLength(4),
                    TextInput::make('buyer.district')->label('District'),
                    TextInput::make('buyer.city')->label('City'),
                    TextInput::make('buyer.postal_zone')->label('Postal code')->maxLength(5),
                    TextInput::make('buyer.plot')->label('Plot no.')->maxLength(10),
                ]),
            Section::make('Line items')->columnSpanFull()->schema([
                Repeater::make('lines')->label('')->required()->minItems(1)->defaultItems(1)->live()
                    ->addActionLabel('Add line')->reorderable(false)->cloneable()
                    ->table([
                        Repeater\TableColumn::make('Item')->width('24%'),
                        Repeater\TableColumn::make('Qty')->width('8%'),
                        Repeater\TableColumn::make('Unit price')->width('11%'),
                        Repeater\TableColumn::make('Discount')->width('10%'),
                        Repeater\TableColumn::make('VAT')->width('14%'),
                        Repeater\TableColumn::make('Exemption reason')->width('24%'),
                        Repeater\TableColumn::make('Unit')->width('8%'),
                    ])
                    ->schema([
                        TextInput::make('name')->required()->maxLength(255),
                        TextInput::make('quantity')->numeric()->required()->default(1)->minValue(0.000001),
                        TextInput::make('unit_price')->numeric()->required()->minValue(0)->prefix('SAR'),
                        TextInput::make('discount')->numeric()->default(0)->minValue(0),
                        Select::make('tax_category')->native(false)->required()->default('S')->live()
                            ->options(['S' => '15% standard', 'Z' => '0% zero-rated', 'E' => 'Exempt', 'O' => 'Out of scope']),
                        Select::make('exemption_code')->native(false)->searchable()->placeholder('—')
                            ->options(self::EXEMPTION_CODES)->disabled(fn (Get $get) => ($get('tax_category') ?? 'S') === 'S')->dehydrated()
                            ->helperText(null),
                        TextInput::make('unit_code')->default('PCE')->maxLength(3),
                    ]),
            ]),
        ]);
    }

    /** Most-used ZATCA VAT exemption / zero-rating reason codes. */
    public const EXEMPTION_CODES = [
        'VATEX-SA-32' => 'Export of goods',
        'VATEX-SA-33' => 'Export of services',
        'VATEX-SA-34-1' => 'International transport of goods',
        'VATEX-SA-34-2' => 'International transport of passengers',
        'VATEX-SA-34-3' => 'Services directly connected to international transport',
        'VATEX-SA-34-4' => 'Supply of a means of transport',
        'VATEX-SA-34-5' => 'Services connected to a means of transport',
        'VATEX-SA-35' => 'Medicines and medical equipment',
        'VATEX-SA-36' => 'Qualifying metals',
        'VATEX-SA-EDU' => 'Private education to citizens',
        'VATEX-SA-HEA' => 'Private healthcare to citizens',
        'VATEX-SA-29' => 'Financial services (Article 29)',
        'VATEX-SA-29-7' => 'Life insurance services',
        'VATEX-SA-30' => 'Real estate transactions',
        'VATEX-SA-OOS' => 'Not subject to VAT (out of scope)',
    ];

    public const EXEMPTION_REASONS = [
        'VATEX-SA-32' => 'Export of goods',
        'VATEX-SA-33' => 'Export of services',
        'VATEX-SA-34-1' => 'The international transport of Goods',
        'VATEX-SA-34-2' => 'International transport of passengers',
        'VATEX-SA-34-3' => 'Services directly connected and incidental to a Supply of international passenger transport',
        'VATEX-SA-34-4' => 'Supply of a qualifying means of transport',
        'VATEX-SA-34-5' => 'Any services relating to Goods or passenger transportation, as defined in article twenty five of these Regulations',
        'VATEX-SA-35' => 'Medicines and medical equipment',
        'VATEX-SA-36' => 'Qualifying metals',
        'VATEX-SA-EDU' => 'Private education to citizen',
        'VATEX-SA-HEA' => 'Private healthcare to citizen',
        'VATEX-SA-29' => 'Financial services mentioned in Article 29 of the VAT Law',
        'VATEX-SA-29-7' => 'Life insurance services mentioned in Article 29 of the VAT Law',
        'VATEX-SA-30' => 'Real estate transactions mentioned in Article 30 of the VAT Law',
        'VATEX-SA-OOS' => 'Not subject to VAT',
    ];

    /** Turns the form state into the API payload shape. */
    public static function toPayload(array $data): array
    {
        $lines = array_map(function (array $l) {
            $cat = $l['tax_category'] ?? 'S';
            $l['tax_percent'] = $cat === 'S' ? 15 : 0;
            if ($cat === 'S') {
                unset($l['exemption_code']);
            } else {
                $code = $l['exemption_code'] ?? null;
                if (! $code || ! isset(self::EXEMPTION_CODES[$code])) {
                    $code = match ($cat) { 'Z' => 'VATEX-SA-32', 'E' => 'VATEX-SA-29', default => 'VATEX-SA-OOS' };
                }
                $l['exemption_code'] = $code;
                $l['exemption_reason'] = self::EXEMPTION_REASONS[$code] ?? self::EXEMPTION_CODES[$code];
            }

            return $l;
        }, array_values($data['lines'] ?? []));
        $data['lines'] = $lines;
        $data['buyer'] = array_filter((array) ($data['buyer'] ?? []), fn ($v) => $v !== null && $v !== '');

        return $data;
    }

    private static function totalsHtml(?int $companyId, ?string $type, array $lines): string
    {
        $dto = [];
        foreach ($lines as $l) {
            if (! is_array($l) || ! is_numeric($l['quantity'] ?? null) || ! is_numeric($l['unit_price'] ?? null)) {
                continue;
            }
            $payload = self::toPayload(['lines' => [$l]])['lines'][0];
            $dto[] = Line::fromArray($payload);
        }
        $inv = new InvoiceData('x', $type ?? 'simplified', 'invoice', '2000-01-01', '00:00:00', new Party('x'), new Party(''), $dto);
        (new Calculator())->apply($inv);
        $row = fn (string $k, string $v, bool $strong = false) => '<div style="display:flex;justify-content:space-between;padding:.35rem 0;'.($strong ? 'border-top:1px solid rgb(148 163 184 / .35);margin-top:.35rem;font-weight:700;font-size:1.15rem' : '').'"><span>'.$k.'</span><span style="font-variant-numeric:tabular-nums">'.$v.'</span></div>';

        return '<div class="inv-totals">'.$row('Subtotal', 'SAR '.number_format((float) $inv->taxExclusive, 2))
            .$row('VAT', 'SAR '.number_format((float) $inv->taxAmount, 2))
            .$row('Total', 'SAR '.number_format((float) $inv->taxInclusive, 2), true).'</div>';
    }
}
