<?php

namespace App\Filament\Concerns;

use Illuminate\Database\Eloquent\Builder;

/** Narrows a resource to the companies the signed-in user may see (admins see all). */
trait ScopedToCompanies
{
    protected static function companyColumn(): string
    {
        return 'company_id';
    }

    public static function getEloquentQuery(): Builder
    {
        $query = parent::getEloquentQuery();
        $user = auth()->user();

        return $user ? $user->scopeCompanies($query, static::companyColumn()) : $query->whereRaw('1 = 0');
    }
}
