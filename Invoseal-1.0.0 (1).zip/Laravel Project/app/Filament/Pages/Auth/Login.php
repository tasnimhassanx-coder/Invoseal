<?php

namespace App\Filament\Pages\Auth;

use Filament\Auth\Pages\Login as BaseLogin;

/** Pre-fills the demo credentials when DEMO_MODE=true so a visitor can try the product in one click. */
class Login extends BaseLogin
{
    public function mount(): void
    {
        parent::mount();

        if (config('invoseal.demo_mode')) {
            $this->form->fill([
                'email' => config('invoseal.demo_email'),
                'password' => config('invoseal.demo_password'),
                'remember' => true,
            ]);
        }
    }
}
