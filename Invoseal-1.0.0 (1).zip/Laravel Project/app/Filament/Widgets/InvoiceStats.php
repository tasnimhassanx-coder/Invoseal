<?php

namespace App\Filament\Widgets;

use App\Models\Invoice;
use Filament\Support\Icons\Heroicon;
use Filament\Widgets\StatsOverviewWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class InvoiceStats extends StatsOverviewWidget
{
    protected static ?int $sort = 1;

    protected ?string $pollingInterval = '30s';

    protected int|string|array $columnSpan = 'full';

    private function base()
    {
        return auth()->user()->scopeCompanies(Invoice::query());
    }

    /** @return list<int> counts per day for the last 7 days (oldest first) */
    private function spark(?array $statuses = null): array
    {
        $out = [];
        for ($d = 6; $d >= 0; $d--) {
            $q = $this->base()->whereDate('created_at', now()->subDays($d)->toDateString());
            if ($statuses) {
                $q->whereIn('status', $statuses);
            }
            $out[] = $q->count();
        }

        return $out;
    }

    protected function getColumns(): int|array|null
    {
        return ['@lg' => 3, '@4xl' => 5];
    }

    protected function getStats(): array
    {
        $today = $this->base()->whereDate('created_at', today())->count();
        $accepted = $this->base()->whereDate('created_at', today())->whereIn('status', ['cleared', 'reported'])->count();
        $attention = $this->base()->whereIn('status', ['rejected', 'failed'])->count();
        $pending = $this->base()->whereIn('status', ['pending', 'submitting'])->count();
        $month = (float) $this->base()->whereIn('status', ['cleared', 'reported'])->whereMonth('issue_date', now()->month)->whereYear('issue_date', now()->year)->sum('tax_inclusive');
        $rate = $today > 0 ? round($accepted / $today * 100) : null;

        return [
            Stat::make('Invoices today', number_format($today))
                ->description($rate !== null ? "{$rate}% accepted by ZATCA" : 'No invoices yet today')
                ->descriptionIcon(Heroicon::OutlinedCheckBadge)
                ->chart($this->spark())->color('primary'),
            Stat::make('Cleared & reported', number_format($accepted))
                ->description('Accepted today')
                ->descriptionIcon(Heroicon::OutlinedShieldCheck)
                ->chart($this->spark(['cleared', 'reported']))->color('success'),
            Stat::make('Needs attention', number_format($attention))
                ->description($attention ? 'Rejected or failed - review now' : 'Nothing to fix')
                ->descriptionIcon($attention ? Heroicon::OutlinedExclamationTriangle : Heroicon::OutlinedCheckBadge)
                ->chart($this->spark(['rejected', 'failed']))->color($attention ? 'danger' : 'gray'),
            Stat::make('In queue', number_format($pending))
                ->description($pending ? 'Waiting for ZATCA / retry' : 'Queue is empty')
                ->descriptionIcon(Heroicon::OutlinedArrowPath)
                ->color($pending ? 'warning' : 'gray'),
            Stat::make('Invoiced this month', 'SAR '.number_format($month, 2))
                ->description('Incl. VAT, accepted invoices')
                ->descriptionIcon(Heroicon::OutlinedBanknotes)->color('info'),
        ];
    }
}
