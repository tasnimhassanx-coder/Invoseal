<?php

namespace App\Filament\Widgets;

use App\Filament\Resources\EgsUnitResource;
use App\Models\EgsUnit;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget;

class CertificateStatus extends TableWidget
{
    protected static ?int $sort = 4;

    protected int|string|array $columnSpan = ['default' => 'full', 'lg' => 1];

    protected static ?string $heading = 'EGS units & certificates';

    public function table(Table $table): Table
    {
        return $table
            ->query(fn () => auth()->user()->scopeCompanies(EgsUnit::query())->with('company')->orderBy('certificate_expires_at'))
            ->columns([
                TextColumn::make('name')->label('Unit')->description(fn (EgsUnit $r) => $r->company->name)->weight('semibold'),
                TextColumn::make('status')->badge()->formatStateUsing(fn ($state) => $state->label())->color(fn ($state) => $state->color()),
                TextColumn::make('certificate_expires_at')->label('Certificate')
                    ->formatStateUsing(function ($state, EgsUnit $r) {
                        $d = $r->daysToExpiry();

                        return $d === null ? '-' : ($d < 0 ? 'Expired' : "{$d} days left");
                    })
                    ->badge()
                    ->color(function (EgsUnit $r) {
                        $d = $r->daysToExpiry();

                        return $d === null ? 'gray' : ($d < 0 ? 'danger' : ($d <= (int) config('invoseal.certificate_warning_days') ? 'warning' : 'success'));
                    }),
            ])
            ->recordUrl(fn (EgsUnit $r) => EgsUnitResource::getUrl('view', ['record' => $r]))
            ->paginated(false)
            ->emptyStateHeading('No EGS units yet')->emptyStateDescription('Create a company, then onboard an EGS unit.')
            ->modifyQueryUsing(fn ($query) => $query->limit(6));
    }
}
