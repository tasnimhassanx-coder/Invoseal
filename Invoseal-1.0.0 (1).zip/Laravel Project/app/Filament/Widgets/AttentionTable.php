<?php

namespace App\Filament\Widgets;

use App\Filament\Resources\InvoiceResource;
use App\Models\Invoice;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget;

class AttentionTable extends TableWidget
{
    protected static ?int $sort = 3;

    protected int|string|array $columnSpan = ['default' => 'full', 'lg' => 1];

    protected static ?string $heading = 'Needs attention';

    public function table(Table $table): Table
    {
        return $table
            ->query(fn () => auth()->user()->scopeCompanies(Invoice::query())->whereIn('status', ['rejected', 'failed', 'pending'])->latest('id'))
            ->columns([
                TextColumn::make('invoice_number')->label('Invoice')->weight('semibold'),
                TextColumn::make('status')->badge()->formatStateUsing(fn ($state) => $state->label())->color(fn ($state) => $state->color()),
                TextColumn::make('last_error')->label('Why')->limit(48)->tooltip(fn ($record) => $record->last_error)->placeholder('Waiting for retry')->wrap(),
            ])
            ->recordUrl(fn (Invoice $r) => InvoiceResource::getUrl('view', ['record' => $r]))
            ->paginated(false)->defaultSort('id', 'desc')
            ->emptyStateHeading('All clear')->emptyStateDescription('No rejected, failed or waiting invoices.')
            ->emptyStateIcon('heroicon-o-check-badge')
            ->modifyQueryUsing(fn ($query) => $query->limit(6));
    }
}
