<?php

namespace App\Filament\Widgets;

use App\Models\Invoice;
use Filament\Widgets\ChartWidget;

class InvoicesTrend extends ChartWidget
{
    protected static ?int $sort = 2;

    protected ?string $heading = 'Invoices - last 14 days';

    protected ?string $pollingInterval = '60s';

    protected int|string|array $columnSpan = ['default' => 'full', 'lg' => 2];

    protected ?string $maxHeight = '270px';

    protected function getType(): string
    {
        return 'line';
    }

    protected function getData(): array
    {
        $labels = [];
        $ok = [];
        $bad = [];
        $wait = [];
        for ($d = 13; $d >= 0; $d--) {
            $day = now()->subDays($d);
            $labels[] = $day->format('d M');
            $q = fn () => auth()->user()->scopeCompanies(Invoice::query())->whereDate('created_at', $day->toDateString());
            $ok[] = $q()->whereIn('status', ['cleared', 'reported'])->count();
            $bad[] = $q()->whereIn('status', ['rejected', 'failed'])->count();
            $wait[] = $q()->whereIn('status', ['pending', 'submitting'])->count();
        }

        $ds = fn (string $label, array $data, string $rgb) => [
            'label' => $label, 'data' => $data, 'borderColor' => "rgb($rgb)", 'backgroundColor' => "rgba($rgb,.12)",
            'fill' => true, 'tension' => .38, 'borderWidth' => 2, 'pointRadius' => 0, 'pointHoverRadius' => 4,
        ];

        return [
            'datasets' => [
                $ds('Accepted', $ok, '16,185,129'),
                $ds('Rejected / failed', $bad, '244,63,94'),
                $ds('Pending', $wait, '245,158,11'),
            ],
            'labels' => $labels,
        ];
    }

    protected function getOptions(): array
    {
        return [
            'plugins' => ['legend' => ['position' => 'bottom', 'labels' => ['usePointStyle' => true, 'boxWidth' => 8]]],
            'scales' => ['y' => ['beginAtZero' => true, 'ticks' => ['precision' => 0]], 'x' => ['grid' => ['display' => false]]],
            'interaction' => ['mode' => 'index', 'intersect' => false],
        ];
    }
}
