<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class IpOrCidr implements ValidationRule
{
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $value = (string) $value;
        $ok = filter_var($value, FILTER_VALIDATE_IP) !== false;
        if (! $ok && preg_match('#^([^/]+)/(\d{1,3})$#', $value, $m)) {
            $max = str_contains($m[1], ':') ? 128 : 32;
            $ok = filter_var($m[1], FILTER_VALIDATE_IP) !== false && (int) $m[2] <= $max;
        }
        if (! $ok) {
            $fail('“'.$value.'” is not a valid IP address or CIDR range.');
        }
    }
}
