<?php

namespace App\Jobs;

use App\Models\Invoice;
use App\Models\WebhookDelivery;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Throwable;

/** Posts a signed JSON event to the company's webhook URL (HMAC-SHA256 in X-Invoseal-Signature). */
class DeliverWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 6;

    public function __construct(public int $deliveryId) {}

    /** @return list<int> */
    public function backoff(): array
    {
        return [30, 120, 600, 3600, 14400];
    }

    public static function dispatchForInvoice(Invoice $invoice, string $event): void
    {
        $invoice->loadMissing('company');
        $payload = [
            'event' => $event,
            'created_at' => now()->toIso8601String(),
            'data' => [
                'uuid' => $invoice->uuid,
                'invoice_number' => $invoice->invoice_number,
                'external_reference' => $invoice->external_reference,
                'type' => $invoice->type,
                'sub_type' => $invoice->sub_type,
                'status' => $invoice->status->value,
                'total' => $invoice->tax_inclusive,
                'vat' => $invoice->tax_amount,
                'invoice_hash' => $invoice->invoice_hash,
                'has_warnings' => $invoice->has_warnings,
                'error' => $invoice->last_error,
            ],
        ];
        $d = WebhookDelivery::create([
            'company_id' => $invoice->company_id,
            'invoice_id' => $invoice->id,
            'event' => $event,
            'url' => $invoice->company->webhook_url,
            'payload' => $payload,
        ]);
        static::dispatch($d->id);
    }

    public function handle(): void
    {
        $d = WebhookDelivery::with('company')->find($this->deliveryId);
        if (! $d || $d->status === 'delivered') {
            return;
        }
        $body = json_encode($d->payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $ts = time();
        $sig = hash_hmac('sha256', $ts.'.'.$body, (string) $d->company->webhook_secret);

        $d->increment('attempts');
        try {
            $res = Http::timeout(10)->withHeaders([
                'Content-Type' => 'application/json',
                'X-Invoseal-Event' => $d->event,
                'X-Invoseal-Signature' => "t={$ts},v1={$sig}",
                'User-Agent' => 'Invoseal-Webhook/1.0',
            ])->withBody($body, 'application/json')->post($d->url);
        } catch (Throwable $e) {
            $d->update(['last_error' => mb_substr($e->getMessage(), 0, 500), 'status' => 'pending']);
            $this->release($this->backoff()[min($this->attempts() - 1, 4)]);

            return;
        }

        if ($res->successful()) {
            $d->update(['status' => 'delivered', 'last_status' => $res->status(), 'delivered_at' => now(), 'last_error' => null]);

            return;
        }
        $d->update(['last_status' => $res->status(), 'last_error' => 'HTTP '.$res->status()]);
        if ($this->attempts() >= $this->tries) {
            $d->update(['status' => 'failed']);

            return;
        }
        $this->release($this->backoff()[min($this->attempts() - 1, 4)]);
    }

    public function failed(Throwable $e): void
    {
        WebhookDelivery::whereKey($this->deliveryId)->update(['status' => 'failed', 'last_error' => mb_substr($e->getMessage(), 0, 500)]);
    }
}
