<?php

namespace App\Jobs;

use App\Enums\InvoiceStatus;
use App\Models\Invoice;
use App\Services\SubmissionService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * Submits one invoice. Retry scheduling lives in the database (next_retry_at) and in
 * `invoseal:retry-pending`, so a worker restart or an outage never loses an invoice.
 */
class SubmitInvoiceJob implements ShouldBeUnique, ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1;

    public int $uniqueFor = 120;

    public function __construct(public int $invoiceId) {}

    public function uniqueId(): string
    {
        return (string) $this->invoiceId;
    }

    public function handle(SubmissionService $service): void
    {
        $invoice = Invoice::with('egsUnit', 'company')->find($this->invoiceId);
        if (! $invoice || ! in_array($invoice->status, [InvoiceStatus::Pending, InvoiceStatus::Failed], true)) {
            return;
        }
        $service->submit($invoice);
    }
}
