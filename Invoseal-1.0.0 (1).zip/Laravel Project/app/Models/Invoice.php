<?php

namespace App\Models;

use App\Enums\InvoiceStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use LogicException;

class Invoice extends Model
{
    protected $guarded = [];

    protected $hidden = ['signed_xml', 'cleared_xml'];

    protected function casts(): array
    {
        return [
            'status' => InvoiceStatus::class,
            'issue_date' => 'date',
            'supply_date' => 'date',
            'retention_until' => 'date',
            'buyer' => 'array',
            'has_warnings' => 'boolean',
            'line_extension' => 'decimal:2',
            'tax_exclusive' => 'decimal:2',
            'tax_amount' => 'decimal:2',
            'tax_inclusive' => 'decimal:2',
            'next_retry_at' => 'datetime',
            'submitted_at' => 'datetime',
        ];
    }

    protected static function booted(): void
    {
        static::creating(fn (self $i) => $i->uuid ??= (string) Str::uuid());

        // Tax documents must be kept for the statutory retention period: they can never be deleted early.
        static::deleting(function (self $i) {
            if ($i->retention_until && $i->retention_until->isFuture()) {
                throw new LogicException('Invoices cannot be deleted before their retention period ends ('.$i->retention_until->toDateString().').');
            }
        });
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function egsUnit(): BelongsTo
    {
        return $this->belongsTo(EgsUnit::class);
    }

    public function lines(): HasMany
    {
        return $this->hasMany(InvoiceLine::class)->orderBy('line_no');
    }

    public function submissions(): HasMany
    {
        return $this->hasMany(Submission::class)->orderByDesc('id');
    }

    public function endpoint(): string
    {
        return $this->type === 'standard' ? 'clearance' : 'reporting';
    }

    public function isCreditOrDebit(): bool
    {
        return $this->sub_type !== 'invoice';
    }

    /** The XML that should be handed to the buyer: the ZATCA-cleared copy when there is one. */
    public function finalXml(): string
    {
        return $this->cleared_xml ?: $this->signed_xml;
    }
}
