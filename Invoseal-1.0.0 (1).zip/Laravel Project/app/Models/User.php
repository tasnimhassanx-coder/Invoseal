<?php

namespace App\Models;

use App\Enums\Role;
use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements FilamentUser
{
    use HasFactory, Notifiable;

    protected $fillable = ['name', 'email', 'password', 'role', 'is_active', 'locale', 'last_login_at'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'last_login_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
            'role' => Role::class,
        ];
    }

    public function canAccessPanel(Panel $panel): bool
    {
        return $this->is_active;
    }

    public function companies(): BelongsToMany
    {
        return $this->belongsToMany(Company::class);
    }

    public function isAdmin(): bool
    {
        return $this->role === Role::Admin;
    }

    public function canIssue(): bool
    {
        return $this->role?->canIssue() ?? false;
    }

    public function canManage(): bool
    {
        return $this->role?->canManage() ?? false;
    }

    /** IDs of companies this user may see; null means "all" (admins). */
    public function companyIds(): ?array
    {
        return $this->isAdmin() ? null : $this->companies()->pluck('companies.id')->all();
    }

    /** Restrict any company-owned query to what the user may see. */
    public function scopeCompanies(Builder $query, string $column = 'company_id'): Builder
    {
        $ids = $this->companyIds();

        return $ids === null ? $query : $query->whereIn($column, $ids);
    }
}
