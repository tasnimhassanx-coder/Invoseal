<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class ApiKey extends Model
{
    public const ABILITIES = ['invoices:read', 'invoices:write'];

    protected $guarded = [];

    protected $hidden = ['key_hash'];

    protected function casts(): array
    {
        return [
            'abilities' => 'array',
            'ip_allowlist' => 'array',
            'last_used_at' => 'datetime',
            'expires_at' => 'datetime',
            'revoked_at' => 'datetime',
        ];
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Create a key and return the model together with the plain-text key (shown exactly once).
     *
     * @return array{0:self,1:string}
     */
    public static function issue(Company $company, string $name, array $abilities = self::ABILITIES, ?array $ips = null, $expiresAt = null): array
    {
        $plain = 'isk_'.Str::random(40);
        $key = self::create([
            'company_id' => $company->id,
            'name' => $name,
            'key_prefix' => substr($plain, 0, 8),
            'key_hash' => hash('sha256', $plain),
            'abilities' => $abilities,
            'ip_allowlist' => $ips ?: null,
            'expires_at' => $expiresAt,
        ]);

        return [$key, $plain];
    }

    public static function findByPlain(string $plain): ?self
    {
        return self::where('key_hash', hash('sha256', $plain))->first();
    }

    public function isUsable(): bool
    {
        return $this->revoked_at === null && ($this->expires_at === null || $this->expires_at->isFuture());
    }

    public function can(string $ability): bool
    {
        return in_array($ability, $this->abilities ?? [], true);
    }

    public function ipAllowed(?string $ip): bool
    {
        $list = $this->ip_allowlist ?: [];
        if ($list === []) {
            return true;
        }
        foreach ($list as $rule) {
            if ($ip !== null && \Symfony\Component\HttpFoundation\IpUtils::checkIp($ip, trim($rule))) {
                return true;
            }
        }

        return false;
    }
}
