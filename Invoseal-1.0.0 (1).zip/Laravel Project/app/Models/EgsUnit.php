<?php

namespace App\Models;

use App\Enums\EgsStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class EgsUnit extends Model
{
    protected $guarded = [];

    protected $hidden = ['private_key', 'compliance_secret', 'production_secret'];

    protected function casts(): array
    {
        return [
            'status' => EgsStatus::class,
            'private_key' => 'encrypted',
            'compliance_secret' => 'encrypted',
            'production_secret' => 'encrypted',
            'compliance_results' => 'array',
            'certificate_issued_at' => 'datetime',
            'certificate_expires_at' => 'datetime',
            'onboarded_at' => 'datetime',
        ];
    }

    protected static function booted(): void
    {
        static::creating(fn (self $e) => $e->uuid ??= (string) Str::uuid());
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function isActive(): bool
    {
        return $this->status === EgsStatus::Active
            && $this->production_certificate
            && ($this->certificate_expires_at === null || $this->certificate_expires_at->isFuture());
    }

    public function daysToExpiry(): ?int
    {
        return $this->certificate_expires_at ? (int) now()->diffInDays($this->certificate_expires_at, false) : null;
    }

    /** Serial placed in the CSR subject alternative name: 1-<solution>|2-<version>|3-<uuid>. */
    public function csrSerial(): string
    {
        return '1-Invoseal|2-'.config('invoseal.version').'|3-'.$this->uuid;
    }
}
