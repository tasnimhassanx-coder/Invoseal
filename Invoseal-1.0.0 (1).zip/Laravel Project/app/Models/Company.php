<?php

namespace App\Models;

use App\Zatca\Dto\Party;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Company extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return ['webhook_secret' => 'encrypted', 'is_active' => 'boolean'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $c) {
            $c->uuid ??= (string) Str::uuid();
            $c->webhook_secret ??= 'whsec_'.Str::random(40);
        });
    }

    public function branches(): HasMany
    {
        return $this->hasMany(Branch::class);
    }

    public function egsUnits(): HasMany
    {
        return $this->hasMany(EgsUnit::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function apiKeys(): HasMany
    {
        return $this->hasMany(ApiKey::class);
    }

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class);
    }

    /** Seller block used on every invoice. */
    public function toParty(): Party
    {
        return new Party(
            name: $this->name,
            vat: $this->vat_number,
            idNumber: $this->crn,
            idScheme: $this->id_scheme ?: 'CRN',
            street: $this->street,
            building: $this->building_number,
            plot: $this->plot_identification,
            district: $this->district,
            city: $this->city,
            postalZone: $this->postal_zone,
            country: $this->country ?: 'SA',
        );
    }

    public function addressLine(): string
    {
        return trim(implode(', ', array_filter([$this->building_number.' '.$this->street, $this->district, $this->city, $this->postal_zone])));
    }
}
