<?php

namespace App\Http\Middleware;

use App\Models\ApiKey;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;

/**
 * Bearer / X-API-Key authentication. Usage in routes: ->middleware('api.key:invoices:write').
 * Checks: key exists, not revoked/expired, ability granted, caller IP in the allowlist, rate limit.
 */
class AuthenticateApiKey
{
    public function handle(Request $request, Closure $next, ?string $ability = null)
    {
        app()->setLocale($request->getPreferredLanguage(SetLocale::SUPPORTED) ?? 'en');

        $plain = $request->bearerToken() ?: $request->header('X-API-Key');
        $key = $plain ? ApiKey::findByPlain($plain) : null;

        if (! $key || ! $key->isUsable() || ! $key->company?->is_active) {
            return response()->json(['message' => 'Invalid, revoked or expired API key.'], 401);
        }
        if (! $key->ipAllowed($request->ip())) {
            return response()->json(['message' => 'This API key cannot be used from your IP address.'], 403);
        }
        if ($ability && ! $key->can($ability)) {
            return response()->json(['message' => "This API key lacks the {$ability} ability."], 403);
        }

        $limit = (int) config('invoseal.api_rate_limit');
        $bucket = 'api-key:'.$key->id;
        if (RateLimiter::tooManyAttempts($bucket, $limit)) {
            return response()->json(['message' => 'Too many requests.'], 429)
                ->header('Retry-After', (string) RateLimiter::availableIn($bucket));
        }
        RateLimiter::hit($bucket, 60);

        $key->forceFill(['last_used_at' => now(), 'last_used_ip' => $request->ip()])->saveQuietly();
        $request->attributes->set('api_key', $key);
        $request->attributes->set('company', $key->company);

        $response = $next($request);
        $response->headers->set('X-RateLimit-Limit', (string) $limit);
        $response->headers->set('X-RateLimit-Remaining', (string) RateLimiter::remaining($bucket, $limit));

        return $response;
    }
}
