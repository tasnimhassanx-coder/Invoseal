<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Picks en / bn / ar from the signed-in user's profile or the Accept-Language header (API clients). */
class SetLocale
{
    public const SUPPORTED = ['en', 'bn', 'ar'];

    public function handle(Request $request, Closure $next)
    {
        $locale = $request->user()?->locale ?? $request->getPreferredLanguage(self::SUPPORTED) ?? 'en';
        app()->setLocale(in_array($locale, self::SUPPORTED, true) ? $locale : 'en');

        return $next($request);
    }
}
