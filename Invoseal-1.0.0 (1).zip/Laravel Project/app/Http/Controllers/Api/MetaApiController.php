<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MetaApiController extends Controller
{
    public function health(): JsonResponse
    {
        try {
            DB::select('select 1');
            $db = 'ok';
        } catch (\Throwable) {
            $db = 'down';
        }

        return response()->json(['status' => $db === 'ok' ? 'ok' : 'degraded', 'version' => config('invoseal.version'), 'database' => $db, 'time' => now()->toIso8601String()], $db === 'ok' ? 200 : 503);
    }

    public function me(Request $request): JsonResponse
    {
        $c = $request->attributes->get('company');
        $key = $request->attributes->get('api_key');

        return response()->json(['data' => [
            'company' => ['name' => $c->name, 'vat_number' => $c->vat_number, 'environment' => $c->environment],
            'api_key' => ['name' => $key->name, 'abilities' => $key->abilities],
            'egs_units' => $c->egsUnits()->get()->map(fn ($u) => [
                'uuid' => $u->uuid, 'name' => $u->name, 'status' => $u->status->value, 'environment' => $u->environment,
                'invoice_types' => $u->invoice_types, 'certificate_expires_at' => $u->certificate_expires_at?->toIso8601String(),
                'last_icv' => $u->last_icv,
            ]),
            'pending_invoices' => Invoice::where('company_id', $c->id)->whereIn('status', ['pending', 'failed'])->count(),
        ]]);
    }
}
