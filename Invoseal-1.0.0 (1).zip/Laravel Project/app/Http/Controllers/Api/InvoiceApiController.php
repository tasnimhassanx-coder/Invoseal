<?php

namespace App\Http\Controllers\Api;

use App\Enums\InvoiceStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\InvoicePayloadRules;
use App\Jobs\SubmitInvoiceJob;
use App\Models\Invoice;
use App\Services\AuditLogger;
use App\Services\InvoicePdf;
use App\Services\InvoiceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class InvoiceApiController extends Controller
{
    public function __construct(private readonly InvoiceService $service) {}

    public function store(Request $request): JsonResponse
    {
        $company = $request->attributes->get('company');
        $payload = Validator::validate($request->all(), InvoicePayloadRules::rules());
        $payload = array_replace($request->all(), $payload);

        $result = $this->service->issue($company, $payload);

        if (! $result->ok()) {
            return response()->json([
                'message' => 'The invoice was not accepted. Fix the errors below and send it again.',
                'errors' => $result->issuesArray(),
            ], 422);
        }

        return response()->json([
            'data' => $this->present($result->invoice),
            'warnings' => $result->issuesArray(),
            'duplicate' => $result->duplicate,
        ], $result->duplicate ? 200 : 201);
    }

    /** Dry run: pre-validation + computed totals, nothing is stored and no counter is consumed. */
    public function validateOnly(Request $request): JsonResponse
    {
        $company = $request->attributes->get('company');
        $payload = Validator::validate($request->all(), InvoicePayloadRules::rules());
        $payload = array_replace($request->all(), $payload);
        $check = $this->service->check($company, $payload);
        $issues = array_map(fn ($i) => $i->toArray(), $check['issues']);

        return response()->json([
            'valid' => ! array_filter($issues, fn ($i) => $i['severity'] === 'error'),
            'issues' => $issues,
            'totals' => $check['totals'],
        ]);
    }

    public function index(Request $request): JsonResponse
    {
        $company = $request->attributes->get('company');
        $q = Invoice::where('company_id', $company->id)->orderByDesc('id');
        foreach (['status', 'type', 'sub_type'] as $f) {
            if ($v = $request->query($f)) {
                $q->where($f, $v);
            }
        }
        if ($v = $request->query('external_reference')) {
            $q->where('external_reference', $v);
        }
        if ($v = $request->query('invoice_number')) {
            $q->where('invoice_number', $v);
        }
        if ($v = $request->query('from')) {
            $q->whereDate('issue_date', '>=', $v);
        }
        if ($v = $request->query('to')) {
            $q->whereDate('issue_date', '<=', $v);
        }
        $page = $q->paginate(min(max((int) $request->query('per_page', 25), 1), 100));

        return response()->json([
            'data' => $page->getCollection()->map(fn (Invoice $i) => $this->present($i))->values(),
            'meta' => ['page' => $page->currentPage(), 'per_page' => $page->perPage(), 'total' => $page->total(), 'last_page' => $page->lastPage()],
        ]);
    }

    public function show(Request $request, string $uuid): JsonResponse
    {
        return response()->json(['data' => $this->present($this->find($request, $uuid), true)]);
    }

    public function xml(Request $request, string $uuid): Response
    {
        $invoice = $this->find($request, $uuid);

        return response($invoice->finalXml(), 200, [
            'Content-Type' => 'application/xml; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="'.$invoice->invoice_number.'.xml"',
        ]);
    }

    public function pdf(Request $request, string $uuid): Response
    {
        $invoice = $this->find($request, $uuid);

        return response((new InvoicePdf())->render($invoice), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="'.$invoice->invoice_number.'.pdf"',
        ]);
    }

    /** Re-send an invoice that is pending or failed (e.g. after fixing the certificate). Rejected invoices need a new, corrected invoice. */
    public function retry(Request $request, string $uuid): JsonResponse
    {
        $invoice = $this->find($request, $uuid);
        if (! in_array($invoice->status, [InvoiceStatus::Pending, InvoiceStatus::Failed], true)) {
            return response()->json(['message' => 'Only pending or failed invoices can be retried. A rejected invoice must be corrected and issued again.'], 409);
        }
        AuditLogger::log('invoice.retry_requested', $invoice);
        SubmitInvoiceJob::dispatchSync($invoice->id);

        return response()->json(['data' => $this->present($invoice->refresh())]);
    }

    private function find(Request $request, string $uuid): Invoice
    {
        return Invoice::where('company_id', $request->attributes->get('company')->id)->where('uuid', $uuid)->firstOrFail();
    }

    /** @return array<string,mixed> */
    private function present(Invoice $i, bool $detail = false): array
    {
        $out = [
            'uuid' => $i->uuid,
            'invoice_number' => $i->invoice_number,
            'external_reference' => $i->external_reference,
            'type' => $i->type,
            'sub_type' => $i->sub_type,
            'status' => $i->status->value,
            'issue_date' => $i->issue_date->format('Y-m-d'),
            'issue_time' => substr((string) $i->issue_time, 0, 8),
            'currency' => $i->currency,
            'totals' => [
                'subtotal' => (string) $i->tax_exclusive,
                'vat' => (string) $i->tax_amount,
                'total' => (string) $i->tax_inclusive,
            ],
            'icv' => $i->icv,
            'invoice_hash' => $i->invoice_hash,
            'qr_code' => $i->qr_code,
            'has_warnings' => $i->has_warnings,
            'error' => $i->last_error,
            'attempts' => $i->attempts,
            'next_retry_at' => $i->next_retry_at?->toIso8601String(),
            'submitted_at' => $i->submitted_at?->toIso8601String(),
            'created_at' => $i->created_at->toIso8601String(),
            'links' => [
                'xml' => url('/api/v1/invoices/'.$i->uuid.'/xml'),
                'pdf' => url('/api/v1/invoices/'.$i->uuid.'/pdf'),
            ],
        ];
        if ($detail) {
            $out['lines'] = $i->lines->map(fn ($l) => [
                'name' => $l->name, 'quantity' => (string) $l->quantity, 'unit_price' => (string) $l->unit_price,
                'discount' => (string) $l->discount, 'tax_category' => $l->tax_category, 'tax_percent' => (string) $l->tax_percent,
                'net' => (string) $l->net, 'tax' => (string) $l->tax, 'total' => (string) $l->gross,
            ])->all();
            $out['submissions'] = $i->submissions->map(fn ($s) => [
                'attempt' => $s->attempt, 'endpoint' => $s->endpoint, 'http_status' => $s->http_status, 'result' => $s->result,
                'errors' => $s->errors, 'warnings' => $s->warnings, 'at' => $s->created_at?->toIso8601String(),
            ])->all();
        }

        return $out;
    }
}
