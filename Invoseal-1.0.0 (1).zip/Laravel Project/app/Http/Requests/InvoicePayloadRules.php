<?php

namespace App\Http\Requests;

use Illuminate\Validation\Rule;

/** Shape validation of the invoice payload (business rules live in InvoiceValidator). */
final class InvoicePayloadRules
{
    public static function rules(): array
    {
        return [
            'invoice_number' => ['required', 'string', 'max:127'],
            'external_reference' => ['nullable', 'string', 'max:100'],
            'type' => ['nullable', Rule::in(['standard', 'simplified'])],
            'sub_type' => ['nullable', Rule::in(['invoice', 'credit_note', 'debit_note'])],
            'issue_date' => ['nullable', 'date_format:Y-m-d'],
            'issue_time' => ['nullable', 'date_format:H:i:s'],
            'supply_date' => ['nullable', 'date_format:Y-m-d'],
            'currency' => ['nullable', 'string', 'size:3'],
            'payment_means' => ['nullable', 'string', 'max:3'],
            'billing_reference' => ['nullable', 'string', 'max:127'],
            'reason' => ['nullable', 'string', 'max:255'],
            'note' => ['nullable', 'string', 'max:500'],
            'egs_unit' => ['nullable', 'uuid'],
            'branch_id' => ['nullable', 'integer'],
            'buyer' => ['nullable', 'array'],
            'buyer.name' => ['nullable', 'string', 'max:255'],
            'buyer.vat' => ['nullable', 'string', 'max:15'],
            'buyer.id_number' => ['nullable', 'string', 'max:30'],
            'buyer.id_scheme' => ['nullable', 'string', 'max:10'],
            'buyer.street' => ['nullable', 'string', 'max:255'],
            'buyer.building' => ['nullable', 'string', 'max:10'],
            'buyer.plot' => ['nullable', 'string', 'max:10'],
            'buyer.district' => ['nullable', 'string', 'max:255'],
            'buyer.city' => ['nullable', 'string', 'max:255'],
            'buyer.postal_zone' => ['nullable', 'string', 'max:10'],
            'buyer.country' => ['nullable', 'string', 'size:2'],
            'lines' => ['required', 'array', 'min:1', 'max:500'],
            'lines.*.name' => ['required', 'string', 'max:255'],
            'lines.*.quantity' => ['required', 'numeric', 'gt:0', 'max:999999999'],
            'lines.*.unit_price' => ['required', 'numeric', 'min:0', 'max:999999999'],
            'lines.*.discount' => ['nullable', 'numeric', 'min:0'],
            'lines.*.unit_code' => ['nullable', 'string', 'max:3'],
            'lines.*.tax_category' => ['nullable', Rule::in(['S', 'Z', 'E', 'O'])],
            'lines.*.tax_percent' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'lines.*.exemption_code' => ['nullable', 'string', 'max:40'],
            'lines.*.exemption_reason' => ['nullable', 'string', 'max:255'],
        ];
    }
}
