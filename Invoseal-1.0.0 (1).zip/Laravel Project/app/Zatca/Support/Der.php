<?php

declare(strict_types=1);

namespace App\Zatca\Support;

/**
 * Tiny DER reader. Only what is needed to pull the issuer name, serial number,
 * subject public key and signature value out of an X.509 certificate.
 */
final class Der
{
    /** @return array{tag:int,start:int,len:int,end:int,hdr:int} */
    public static function read(string $s, int $pos): array
    {
        $tag = ord($s[$pos]);
        $b = ord($s[$pos + 1]);
        $hdr = 2;
        if ($b & 0x80) {
            $bytes = $b & 0x7F;
            $len = 0;
            for ($i = 0; $i < $bytes; $i++) {
                $len = ($len << 8) | ord($s[$pos + 2 + $i]);
            }
            $hdr = 2 + $bytes;
        } else {
            $len = $b;
        }

        return ['tag' => $tag, 'start' => $pos + $hdr, 'len' => $len, 'end' => $pos + $hdr + $len, 'hdr' => $hdr];
    }

    /** @return list<array{tag:int,start:int,len:int,end:int,hdr:int}> direct children of a constructed node */
    public static function children(string $s, array $node): array
    {
        $out = [];
        $pos = $node['start'];
        while ($pos < $node['end']) {
            $c = self::read($s, $pos);
            $out[] = $c;
            $pos = $c['end'];
        }

        return $out;
    }

    public static function raw(string $s, array $node): string
    {
        return substr($s, $node['start'], $node['len']);
    }

    public static function oid(string $bytes): string
    {
        $first = ord($bytes[0]);
        $parts = [intdiv($first, 40), $first % 40];
        $val = 0;
        for ($i = 1, $n = strlen($bytes); $i < $n; $i++) {
            $b = ord($bytes[$i]);
            $val = ($val << 7) | ($b & 0x7F);
            if (! ($b & 0x80)) {
                $parts[] = $val;
                $val = 0;
            }
        }

        return implode('.', $parts);
    }
}
