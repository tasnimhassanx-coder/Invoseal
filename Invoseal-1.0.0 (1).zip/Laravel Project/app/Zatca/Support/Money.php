<?php

declare(strict_types=1);

namespace App\Zatca\Support;

use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;

/** Exact decimal helpers (no floats anywhere in the money path). */
final class Money
{
    public static function dec(string|int|float $v): BigDecimal
    {
        $s = is_string($v) ? trim($v) : (string) $v;

        return BigDecimal::of($s === '' ? '0' : $s);
    }

    /** Round half-up to 2 decimals and return as plain string, e.g. "12.30". */
    public static function two(BigDecimal $v): string
    {
        return (string) $v->toScale(2, RoundingMode::HALF_UP);
    }

    public static function round2(BigDecimal $v): BigDecimal
    {
        return $v->toScale(2, RoundingMode::HALF_UP);
    }
}
