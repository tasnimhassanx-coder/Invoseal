<?php

declare(strict_types=1);

namespace App\Zatca\Support;

/**
 * Minimal TLV (tag-length-value) encoder used for the ZATCA QR payload.
 * Every tag is a single byte, every length is a single byte (values must be < 256 bytes,
 * except the signature/public-key tags which are still < 256 for secp256k1 material).
 */
final class Tlv
{
    /** @param array<int,string> $fields tag => raw binary/string value */
    public static function encode(array $fields): string
    {
        $out = '';
        foreach ($fields as $tag => $value) {
            $len = strlen($value);
            if ($len > 255) {
                throw new \InvalidArgumentException("TLV value for tag {$tag} is {$len} bytes; maximum is 255.");
            }
            $out .= chr($tag).chr($len).$value;
        }

        return $out;
    }

    /** @return array<int,string> */
    public static function decode(string $bytes): array
    {
        $fields = [];
        $i = 0;
        $n = strlen($bytes);
        while ($i + 2 <= $n) {
            $tag = ord($bytes[$i]);
            $len = ord($bytes[$i + 1]);
            $fields[$tag] = substr($bytes, $i + 2, $len);
            $i += 2 + $len;
        }

        return $fields;
    }
}
