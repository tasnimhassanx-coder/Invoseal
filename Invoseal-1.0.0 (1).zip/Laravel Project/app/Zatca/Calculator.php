<?php

declare(strict_types=1);

namespace App\Zatca;

use App\Zatca\Dto\InvoiceData;
use App\Zatca\Support\Money;
use Brick\Math\BigDecimal;

/**
 * Computes line and document totals the way ZATCA / EN 16931 expect them:
 * line net = round2(qty x price - discount), line VAT = round2(net x rate),
 * VAT per category = round2(sum of nets x rate), document VAT = sum of category VAT.
 */
final class Calculator
{
    public function apply(InvoiceData $inv): InvoiceData
    {
        $lineSum = BigDecimal::zero();
        $groups = [];

        foreach ($inv->lines as $line) {
            $qty = Money::dec($line->quantity);
            $price = Money::dec($line->unitPrice);
            $disc = Money::dec($line->discount);
            $rate = Money::dec($line->taxPercent);

            $net = Money::round2($qty->multipliedBy($price)->minus($disc));
            $tax = Money::round2($net->multipliedBy($rate)->dividedBy(100, 6, \Brick\Math\RoundingMode::HALF_UP));

            $line->net = (string) $net;
            $line->tax = (string) $tax;
            $line->gross = (string) $net->plus($tax);
            $lineSum = $lineSum->plus($net);

            $key = $line->taxCategory.'|'.Money::two($rate);
            $groups[$key] ??= [
                'category' => $line->taxCategory,
                'percent' => Money::two($rate),
                'taxable' => BigDecimal::zero(),
                'code' => $line->exemptionCode,
                'reason' => $line->exemptionReason,
            ];
            $groups[$key]['taxable'] = $groups[$key]['taxable']->plus($net);
        }

        $taxTotal = BigDecimal::zero();
        $subtotals = [];
        foreach ($groups as $key => $g) {
            $rate = Money::dec($g['percent']);
            $tax = Money::round2($g['taxable']->multipliedBy($rate)->dividedBy(100, 6, \Brick\Math\RoundingMode::HALF_UP));
            $taxTotal = $taxTotal->plus($tax);
            $subtotals[$key] = [
                'category' => $g['category'],
                'percent' => $g['percent'],
                'taxable' => Money::two($g['taxable']),
                'tax' => (string) $tax,
                'code' => $g['code'],
                'reason' => $g['reason'],
            ];
        }

        $allowance = Money::round2(Money::dec($inv->allowanceTotal));
        $exclusive = $lineSum->minus($allowance);
        $inclusive = $exclusive->plus($taxTotal);
        $prepaid = Money::round2(Money::dec($inv->prepaid));

        $inv->lineExtension = Money::two($lineSum);
        $inv->allowanceTotal = Money::two($allowance);
        $inv->taxExclusive = Money::two($exclusive);
        $inv->taxAmount = Money::two($taxTotal);
        $inv->taxInclusive = Money::two($inclusive);
        $inv->prepaid = Money::two($prepaid);
        $inv->payable = Money::two($inclusive->minus($prepaid));
        $inv->taxSubtotals = $subtotals;

        return $inv;
    }
}
