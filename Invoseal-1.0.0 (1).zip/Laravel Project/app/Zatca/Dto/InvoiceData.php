<?php

declare(strict_types=1);

namespace App\Zatca\Dto;

final class InvoiceData
{
    public const TYPE_STANDARD = 'standard';     // B2B -> clearance
    public const TYPE_SIMPLIFIED = 'simplified'; // B2C -> reporting

    public const SUB_INVOICE = 'invoice';        // 388
    public const SUB_CREDIT = 'credit_note';     // 381
    public const SUB_DEBIT = 'debit_note';       // 383

    // computed by Calculator
    public string $lineExtension = '0.00';
    public string $taxExclusive = '0.00';
    public string $taxAmount = '0.00';
    public string $taxInclusive = '0.00';
    public string $allowanceTotal = '0.00';
    public string $prepaid = '0.00';
    public string $payable = '0.00';
    /** @var array<string,array{category:string,percent:string,taxable:string,tax:string,code:?string,reason:?string}> */
    public array $taxSubtotals = [];

    // set by the signing pipeline
    public int $icv = 1;
    public string $pih = '';
    public ?string $uuid = null;

    /** @param list<Line> $lines */
    public function __construct(
        public readonly string $number,
        public readonly string $type,
        public readonly string $subType,
        public readonly string $issueDate,     // Y-m-d
        public readonly string $issueTime,     // H:i:s
        public readonly Party $seller,
        public readonly Party $buyer,
        public array $lines,
        public readonly string $currency = 'SAR',
        public readonly ?string $supplyDate = null,
        public readonly ?string $supplyEndDate = null,
        public readonly string $paymentMeans = '10',
        public readonly ?string $billingReference = null,   // original invoice number (credit / debit notes)
        public readonly ?string $reason = null,              // reason for credit / debit note
        public readonly ?string $note = null,
        public readonly bool $summary = false,
        public readonly bool $nominal = false,
        public readonly bool $export = false,
        public readonly bool $thirdParty = false,
        public readonly bool $selfBilled = false,
    ) {}

    public function typeCode(): string
    {
        return match ($this->subType) {
            self::SUB_CREDIT => '381',
            self::SUB_DEBIT => '383',
            default => '388',
        };
    }

    /** The 7-character invoice type transaction code: NNPESNB */
    public function transactionCode(): string
    {
        return ($this->type === self::TYPE_STANDARD ? '01' : '02')
            .($this->thirdParty ? '1' : '0')
            .($this->nominal ? '1' : '0')
            .($this->export ? '1' : '0')
            .($this->summary ? '1' : '0')
            .($this->selfBilled ? '1' : '0');
    }

    public function isStandard(): bool
    {
        return $this->type === self::TYPE_STANDARD;
    }
}
