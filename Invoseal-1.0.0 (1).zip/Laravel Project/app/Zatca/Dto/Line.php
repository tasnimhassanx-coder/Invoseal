<?php

declare(strict_types=1);

namespace App\Zatca\Dto;

/** One invoice line. Monetary/quantity fields are decimal strings. After Calculator::apply they carry computed amounts. */
final class Line
{
    public string $net = '0.00';      // LineExtensionAmount
    public string $tax = '0.00';      // line VAT
    public string $gross = '0.00';    // net + tax (RoundingAmount)

    public function __construct(
        public readonly string $name,
        public readonly string $quantity,
        public readonly string $unitPrice,
        public readonly string $discount = '0',
        public readonly string $taxCategory = 'S',      // S standard, Z zero, E exempt, O out of scope
        public readonly string $taxPercent = '15',
        public readonly string $unitCode = 'PCE',
        public readonly ?string $exemptionCode = null,   // e.g. VATEX-SA-EDU
        public readonly ?string $exemptionReason = null,
    ) {}

    public static function fromArray(array $a): self
    {
        $cat = strtoupper((string) ($a['tax_category'] ?? 'S'));

        return new self(
            name: trim((string) ($a['name'] ?? '')),
            quantity: (string) ($a['quantity'] ?? '1'),
            unitPrice: (string) ($a['unit_price'] ?? '0'),
            discount: (string) ($a['discount'] ?? '0'),
            taxCategory: $cat,
            taxPercent: (string) ($a['tax_percent'] ?? ($cat === 'S' ? '15' : '0')),
            unitCode: strtoupper((string) ($a['unit_code'] ?? 'PCE')),
            exemptionCode: isset($a['exemption_code']) && $a['exemption_code'] !== '' ? (string) $a['exemption_code'] : null,
            exemptionReason: isset($a['exemption_reason']) && $a['exemption_reason'] !== '' ? (string) $a['exemption_reason'] : null,
        );
    }
}
