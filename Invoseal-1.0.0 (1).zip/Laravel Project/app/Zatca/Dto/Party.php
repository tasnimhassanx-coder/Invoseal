<?php

declare(strict_types=1);

namespace App\Zatca\Dto;

final class Party
{
    public function __construct(
        public readonly string $name = '',
        public readonly ?string $vat = null,
        public readonly ?string $idNumber = null,       // CRN / other registration id
        public readonly string $idScheme = 'CRN',        // CRN, MOM, MLS, SAG, TIN, 700, OTH, NAT, GCC, IQA, PAS
        public readonly ?string $street = null,
        public readonly ?string $building = null,
        public readonly ?string $plot = null,
        public readonly ?string $district = null,
        public readonly ?string $city = null,
        public readonly ?string $postalZone = null,
        public readonly string $country = 'SA',
    ) {}

    public static function fromArray(array $a): self
    {
        return new self(
            name: trim((string) ($a['name'] ?? '')),
            vat: self::nullable($a['vat'] ?? null),
            idNumber: self::nullable($a['id_number'] ?? $a['crn'] ?? null),
            idScheme: strtoupper((string) ($a['id_scheme'] ?? 'CRN')),
            street: self::nullable($a['street'] ?? null),
            building: self::nullable($a['building'] ?? null),
            plot: self::nullable($a['plot'] ?? null),
            district: self::nullable($a['district'] ?? null),
            city: self::nullable($a['city'] ?? null),
            postalZone: self::nullable($a['postal_zone'] ?? null),
            country: strtoupper((string) ($a['country'] ?? 'SA')) ?: 'SA',
        );
    }

    private static function nullable(mixed $v): ?string
    {
        $v = is_scalar($v) ? trim((string) $v) : '';

        return $v === '' ? null : $v;
    }
}
