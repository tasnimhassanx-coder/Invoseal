<?php

declare(strict_types=1);

namespace App\Zatca\Api;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;

/**
 * Thin client over the ZATCA Fatoora gateway (compliance, onboarding, clearance, reporting).
 * Pure transport: no database access, no retry policy (the queue owns retries).
 */
final class ZatcaClient
{
    public const BASE_URLS = [
        'sandbox' => 'https://gw-fatoora.zatca.gov.sa/e-invoicing/developer-portal',
        'simulation' => 'https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation',
        'production' => 'https://gw-fatoora.zatca.gov.sa/e-invoicing/core',
    ];

    public function __construct(
        private readonly string $environment = 'sandbox',
        private readonly ?string $baseUrl = null,
        private readonly int $timeout = 30,
        private readonly string $language = 'en',
    ) {}

    public function baseUrl(): string
    {
        return rtrim($this->baseUrl ?: (self::BASE_URLS[$this->environment] ?? self::BASE_URLS['sandbox']), '/');
    }

    /** Step 1 of onboarding: exchange CSR + OTP for a compliance CSID. */
    public function requestComplianceCsid(string $csrPem, string $otp): ZatcaResponse
    {
        return $this->send('POST', '/compliance', ['csr' => base64_encode($csrPem)], null, ['OTP' => $otp]);
    }

    /** Step 2: submit a sample invoice to the compliance checker. */
    public function complianceCheck(string $token, string $secret, string $signedXml, string $invoiceHash, string $uuid): ZatcaResponse
    {
        return $this->send('POST', '/compliance/invoices', $this->invoicePayload($signedXml, $invoiceHash, $uuid), [$token, $secret]);
    }

    /** Step 3: exchange the passed compliance CSID for a production CSID. */
    public function requestProductionCsid(string $token, string $secret, string $complianceRequestId): ZatcaResponse
    {
        return $this->send('POST', '/production/csids', ['compliance_request_id' => $complianceRequestId], [$token, $secret]);
    }

    /** Renew an expiring production certificate with a fresh CSR + OTP. */
    public function renewProductionCsid(string $token, string $secret, string $csrPem, string $otp): ZatcaResponse
    {
        return $this->send('PATCH', '/production/csids', ['csr' => base64_encode($csrPem)], [$token, $secret], ['OTP' => $otp]);
    }

    /** B2B: standard tax invoices are cleared by ZATCA before they are shared with the buyer. */
    public function clear(string $token, string $secret, string $signedXml, string $invoiceHash, string $uuid): ZatcaResponse
    {
        return $this->send('POST', '/invoices/clearance/single', $this->invoicePayload($signedXml, $invoiceHash, $uuid), [$token, $secret], ['Clearance-Status' => '1']);
    }

    /** B2C: simplified tax invoices are reported to ZATCA within 24 hours. */
    public function report(string $token, string $secret, string $signedXml, string $invoiceHash, string $uuid): ZatcaResponse
    {
        return $this->send('POST', '/invoices/reporting/single', $this->invoicePayload($signedXml, $invoiceHash, $uuid), [$token, $secret], ['Clearance-Status' => '0']);
    }

    /** @return array{invoiceHash:string,uuid:string,invoice:string} */
    private function invoicePayload(string $signedXml, string $hash, string $uuid): array
    {
        return ['invoiceHash' => $hash, 'uuid' => $uuid, 'invoice' => base64_encode($signedXml)];
    }

    /**
     * @param  array<string,mixed>  $json
     * @param  array{0:string,1:string}|null  $auth  [binarySecurityToken, secret]
     * @param  array<string,string>  $headers
     */
    private function send(string $method, string $path, array $json, ?array $auth = null, array $headers = []): ZatcaResponse
    {
        $started = hrtime(true);
        $req = Http::withHeaders(array_merge([
            'Accept' => 'application/json',
            'Accept-Language' => $this->language,
            'Accept-Version' => 'V2',
        ], $headers))->timeout($this->timeout)->acceptJson()->asJson();

        if ($auth !== null) {
            $req = $req->withBasicAuth($auth[0], $auth[1]);
        }

        try {
            $res = $req->send($method, $this->baseUrl().$path, ['json' => $json]);
        } catch (ConnectionException $e) {
            return new ZatcaResponse(0, [], (int) ((hrtime(true) - $started) / 1e6), $e->getMessage());
        }

        $body = $res->json();

        return new ZatcaResponse($res->status(), is_array($body) ? $body : ['raw' => $res->body()], (int) ((hrtime(true) - $started) / 1e6));
    }
}
