<?php

declare(strict_types=1);

namespace App\Zatca\Api;

/** Normalised view of a ZATCA gateway response. */
final class ZatcaResponse
{
    /** @param array<string,mixed> $body */
    public function __construct(
        public readonly int $status,
        public readonly array $body,
        public readonly int $durationMs = 0,
        public readonly ?string $transportError = null,
    ) {}

    public function isTransportFailure(): bool
    {
        return $this->transportError !== null;
    }

    /** HTTP 200 (ok) or 202 (accepted with warnings). */
    public function accepted(): bool
    {
        return in_array($this->status, [200, 202], true);
    }

    /** 5xx / 429 / timeouts are worth retrying; 4xx validation problems are not. */
    public function retryable(): bool
    {
        return $this->isTransportFailure() || $this->status >= 500 || $this->status === 429;
    }

    public function duplicate(): bool
    {
        return $this->status === 409;
    }

    public function unauthorized(): bool
    {
        return in_array($this->status, [401, 403], true);
    }

    /** @return list<array{type:string,code:string,category:string,message:string,status:string}> */
    public function errors(): array
    {
        return $this->messages('errorMessages');
    }

    /** @return list<array{type:string,code:string,category:string,message:string,status:string}> */
    public function warnings(): array
    {
        return $this->messages('warningMessages');
    }

    /** @return list<array{type:string,code:string,category:string,message:string,status:string}> */
    private function messages(string $key): array
    {
        $list = $this->body['validationResults'][$key] ?? [];
        if (! is_array($list)) {
            return [];
        }
        $out = [];
        foreach ($list as $m) {
            if (! is_array($m)) {
                continue;
            }
            $out[] = [
                'type' => (string) ($m['type'] ?? ''),
                'code' => (string) ($m['code'] ?? ''),
                'category' => (string) ($m['category'] ?? ''),
                'message' => (string) ($m['message'] ?? ''),
                'status' => (string) ($m['status'] ?? ''),
            ];
        }
        // top-level API errors (e.g. 400 without validationResults)
        if ($out === [] && $key === 'errorMessages' && ! $this->accepted()) {
            $code = (string) ($this->body['code'] ?? $this->body['category'] ?? 'HTTP-'.$this->status);
            $msg = (string) ($this->body['message'] ?? $this->body['dispositionMessage'] ?? $this->transportError ?? 'ZATCA rejected the request.');
            $out[] = ['type' => 'ERROR', 'code' => $code, 'category' => '', 'message' => $msg, 'status' => 'ERROR'];
        }

        return $out;
    }

    public function clearedInvoiceXml(): ?string
    {
        $b64 = $this->body['clearedInvoice'] ?? null;

        return is_string($b64) && $b64 !== '' ? (string) base64_decode($b64, true) : null;
    }

    public function clearanceStatus(): ?string
    {
        return isset($this->body['clearanceStatus']) ? (string) $this->body['clearanceStatus'] : null;
    }

    public function reportingStatus(): ?string
    {
        return isset($this->body['reportingStatus']) ? (string) $this->body['reportingStatus'] : null;
    }
}
