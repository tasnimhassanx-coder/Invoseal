<?php

declare(strict_types=1);

namespace App\Zatca\Validation;

/** A pre-validation finding. `code` is translated via lang/{en,bn,ar}/invoseal.php (issues.<code>). */
final class Issue
{
    public function __construct(
        public readonly string $code,
        public readonly string $field,
        public readonly bool $blocking = true,
        public readonly array $params = [],
    ) {}

    /** @return array{code:string,field:string,severity:string,message:string} */
    public function toArray(?string $locale = null): array
    {
        $key = 'invoseal.issues.'.$this->code;
        $msg = function_exists('__') ? __($key, $this->params, $locale) : $key;

        return [
            'code' => $this->code,
            'field' => $this->field,
            'severity' => $this->blocking ? 'error' : 'warning',
            'message' => $msg === $key ? $this->code : $msg,
        ];
    }
}
