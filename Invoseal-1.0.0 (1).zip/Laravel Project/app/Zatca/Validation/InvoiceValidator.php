<?php

declare(strict_types=1);

namespace App\Zatca\Validation;

use App\Zatca\Dto\InvoiceData;
use App\Zatca\Dto\Party;

/**
 * Catches the mistakes ZATCA would reject, before an invoice is signed and the chain counter is consumed.
 * Returns a list of Issue objects; blocking issues must be fixed, the rest are warnings.
 */
final class InvoiceValidator
{
    private const TAX_CATEGORIES = ['S', 'Z', 'E', 'O'];
    private const PAYMENT_MEANS = ['1', '10', '30', '42', '48', '54', '55', '58', '59'];
    private const UNIT_CODES_MAX = 3;

    /** @return list<Issue> */
    public function validate(InvoiceData $inv, ?\DateTimeImmutable $now = null): array
    {
        $now ??= new \DateTimeImmutable('now', new \DateTimeZone('Asia/Riyadh'));
        $issues = [];

        if ($inv->number === '' || strlen($inv->number) > 127) {
            $issues[] = new Issue('NUMBER_INVALID', 'invoice_number');
        }
        if (! in_array($inv->type, [InvoiceData::TYPE_STANDARD, InvoiceData::TYPE_SIMPLIFIED], true)) {
            $issues[] = new Issue('TYPE_INVALID', 'type');
        }
        if (! in_array($inv->subType, [InvoiceData::SUB_INVOICE, InvoiceData::SUB_CREDIT, InvoiceData::SUB_DEBIT], true)) {
            $issues[] = new Issue('SUBTYPE_INVALID', 'sub_type');
        }
        if ($inv->currency !== 'SAR') {
            $issues[] = new Issue('CURRENCY_UNSUPPORTED', 'currency', true, ['currency' => $inv->currency]);
        }

        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $inv->issueDate);
        $time = \DateTimeImmutable::createFromFormat('!H:i:s', $inv->issueTime);
        if (! $date || $date->format('Y-m-d') !== $inv->issueDate) {
            $issues[] = new Issue('DATE_INVALID', 'issue_date');
        } elseif ($date > $now->setTime(23, 59, 59)) {
            $issues[] = new Issue('DATE_FUTURE', 'issue_date');
        }
        if (! $time || $time->format('H:i:s') !== $inv->issueTime) {
            $issues[] = new Issue('TIME_INVALID', 'issue_time');
        }
        if ($date && $time && $inv->type === InvoiceData::TYPE_SIMPLIFIED) {
            $issued = new \DateTimeImmutable($inv->issueDate.' '.$inv->issueTime, new \DateTimeZone('Asia/Riyadh'));
            if ($now->getTimestamp() - $issued->getTimestamp() > 86400) {
                $issues[] = new Issue('REPORTING_OVERDUE', 'issue_date', false);
            }
        }

        $this->seller($inv->seller, $issues);
        $this->buyer($inv, $issues);

        if (! in_array($inv->paymentMeans, self::PAYMENT_MEANS, true)) {
            $issues[] = new Issue('PAYMENT_MEANS_INVALID', 'payment_means');
        }

        if ($inv->subType !== InvoiceData::SUB_INVOICE) {
            if (! $inv->billingReference) {
                $issues[] = new Issue('NOTE_NEEDS_REFERENCE', 'billing_reference');
            }
            if (! $inv->reason) {
                $issues[] = new Issue('NOTE_NEEDS_REASON', 'reason');
            }
        }

        if ($inv->lines === []) {
            $issues[] = new Issue('NO_LINES', 'lines');
        }
        foreach (array_values($inv->lines) as $i => $l) {
            $f = "lines.{$i}";
            if ($l->name === '') {
                $issues[] = new Issue('LINE_NAME_REQUIRED', "{$f}.name");
            }
            if (! is_numeric($l->quantity) || (float) $l->quantity <= 0) {
                $issues[] = new Issue('LINE_QTY_INVALID', "{$f}.quantity");
            }
            if (! is_numeric($l->unitPrice) || (float) $l->unitPrice < 0) {
                $issues[] = new Issue('LINE_PRICE_INVALID', "{$f}.unit_price");
            }
            if (! is_numeric($l->discount) || (float) $l->discount < 0
                || (is_numeric($l->quantity) && is_numeric($l->unitPrice) && (float) $l->discount > (float) $l->quantity * (float) $l->unitPrice + 0.005)) {
                $issues[] = new Issue('LINE_DISCOUNT_INVALID', "{$f}.discount");
            }
            if (! in_array($l->taxCategory, self::TAX_CATEGORIES, true)) {
                $issues[] = new Issue('TAX_CATEGORY_INVALID', "{$f}.tax_category");
            } elseif ($l->taxCategory === 'S' && (float) $l->taxPercent <= 0) {
                $issues[] = new Issue('TAX_PERCENT_INVALID', "{$f}.tax_percent");
            } elseif ($l->taxCategory !== 'S') {
                if ((float) $l->taxPercent != 0.0) {
                    $issues[] = new Issue('TAX_PERCENT_MUST_BE_ZERO', "{$f}.tax_percent");
                }
                if (! $l->exemptionCode) {
                    $issues[] = new Issue('EXEMPTION_CODE_REQUIRED', "{$f}.exemption_code");
                }
                if (! $l->exemptionReason) {
                    $issues[] = new Issue('EXEMPTION_REASON_REQUIRED', "{$f}.exemption_reason");
                }
            }
            if (strlen($l->unitCode) > self::UNIT_CODES_MAX || $l->unitCode === '') {
                $issues[] = new Issue('UNIT_CODE_INVALID', "{$f}.unit_code");
            }
        }

        return $issues;
    }

    /** @param list<Issue> $issues */
    private function seller(Party $p, array &$issues): void
    {
        if ($p->name === '') {
            $issues[] = new Issue('SELLER_NAME_REQUIRED', 'seller.name');
        }
        if (! self::validVat($p->vat)) {
            $issues[] = new Issue('SELLER_VAT_INVALID', 'seller.vat');
        }
        foreach (['street' => $p->street, 'building' => $p->building, 'district' => $p->district, 'city' => $p->city, 'postal_zone' => $p->postalZone] as $k => $v) {
            if (! $v) {
                $issues[] = new Issue('SELLER_ADDRESS_INCOMPLETE', "seller.{$k}");
            }
        }
        if ($p->building && ! preg_match('/^\d{4}$/', $p->building)) {
            $issues[] = new Issue('BUILDING_NUMBER_INVALID', 'seller.building');
        }
        if ($p->postalZone && ! preg_match('/^\d{5}$/', $p->postalZone)) {
            $issues[] = new Issue('POSTAL_ZONE_INVALID', 'seller.postal_zone');
        }
        if (! $p->idNumber) {
            $issues[] = new Issue('SELLER_ID_REQUIRED', 'seller.id_number');
        }
    }

    /** @param list<Issue> $issues */
    private function buyer(InvoiceData $inv, array &$issues): void
    {
        $b = $inv->buyer;
        if ($b->vat !== null && ! self::validVat($b->vat)) {
            $issues[] = new Issue('BUYER_VAT_INVALID', 'buyer.vat');
        }
        if (! $inv->isStandard()) {
            return;
        }
        if ($b->name === '') {
            $issues[] = new Issue('BUYER_NAME_REQUIRED', 'buyer.name');
        }
        foreach (['street' => $b->street, 'building' => $b->building, 'district' => $b->district, 'city' => $b->city, 'postal_zone' => $b->postalZone] as $k => $v) {
            if (! $v) {
                $issues[] = new Issue('BUYER_ADDRESS_INCOMPLETE', "buyer.{$k}");
            }
        }
        if ($b->country === 'SA' && $b->postalZone && ! preg_match('/^\d{5}$/', $b->postalZone)) {
            $issues[] = new Issue('POSTAL_ZONE_INVALID', 'buyer.postal_zone');
        }
        if ($b->country === 'SA' && $b->building && ! preg_match('/^\d{4}$/', $b->building)) {
            $issues[] = new Issue('BUILDING_NUMBER_INVALID', 'buyer.building');
        }
    }

    /** Saudi VAT numbers are 15 digits and start and end with 3. */
    public static function validVat(?string $vat): bool
    {
        return $vat !== null && (bool) preg_match('/^3\d{13}3$/', $vat);
    }
}
