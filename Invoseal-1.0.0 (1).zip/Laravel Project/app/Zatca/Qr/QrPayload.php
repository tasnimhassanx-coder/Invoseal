<?php

declare(strict_types=1);

namespace App\Zatca\Qr;

use App\Zatca\Support\Tlv;

/**
 * ZATCA QR payload (base64 of TLV).
 * Tags 1-5: seller, VAT no., timestamp, total, VAT. Phase 2 simplified invoices add
 * 6 invoice hash, 7 ECDSA signature, 8 public key (DER), 9 certificate signature.
 */
final class QrPayload
{
    public static function build(
        string $sellerName,
        string $vatNumber,
        string $timestamp,
        string $total,
        string $vatTotal,
        ?string $invoiceHashB64 = null,
        ?string $signatureB64 = null,
        ?string $publicKeyDer = null,
        ?string $certificateSignature = null,
    ): string {
        $fields = [1 => $sellerName, 2 => $vatNumber, 3 => $timestamp, 4 => $total, 5 => $vatTotal];
        if ($invoiceHashB64 !== null) {
            $fields[6] = $invoiceHashB64;
            $fields[7] = (string) $signatureB64;
            $fields[8] = (string) $publicKeyDer;
            if ($certificateSignature !== null) {
                $fields[9] = $certificateSignature;
            }
        }

        return base64_encode(Tlv::encode($fields));
    }

    /** @return array<int,string> */
    public static function decode(string $base64): array
    {
        return Tlv::decode((string) base64_decode($base64, true));
    }
}
