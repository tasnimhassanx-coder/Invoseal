<?php

declare(strict_types=1);

namespace App\Zatca\Xml;

use App\Zatca\Dto\InvoiceData;
use App\Zatca\Dto\Party;
use DOMDocument;
use DOMElement;

/**
 * Builds the unsigned ZATCA UBL 2.1 invoice (standard / simplified, invoice / credit / debit note).
 * The output is compact (no insignificant whitespace) so that canonicalisation is unambiguous.
 * Signature extensions and the QR reference are added later by InvoiceSigner.
 */
final class UblInvoiceBuilder
{
    public const NS_INVOICE = 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2';
    public const NS_CAC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2';
    public const NS_CBC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2';
    public const NS_EXT = 'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2';

    private DOMDocument $doc;

    public function build(InvoiceData $inv): string
    {
        $this->doc = new DOMDocument('1.0', 'UTF-8');
        $this->doc->preserveWhiteSpace = false;
        $this->doc->formatOutput = false;

        $root = $this->doc->createElementNS(self::NS_INVOICE, 'Invoice');
        $root->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:cac', self::NS_CAC);
        $root->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:cbc', self::NS_CBC);
        $root->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:ext', self::NS_EXT);
        $this->doc->appendChild($root);

        $cur = $inv->currency;

        $this->cbc($root, 'ProfileID', 'reporting:1.0');
        $this->cbc($root, 'ID', $inv->number);
        $this->cbc($root, 'UUID', (string) $inv->uuid);
        $this->cbc($root, 'IssueDate', $inv->issueDate);
        $this->cbc($root, 'IssueTime', $inv->issueTime);
        $this->cbc($root, 'InvoiceTypeCode', $inv->typeCode(), ['name' => $inv->transactionCode()]);
        if ($inv->note) {
            $this->cbc($root, 'Note', $inv->note, ['languageID' => 'ar']);
        }
        $this->cbc($root, 'DocumentCurrencyCode', $cur);
        $this->cbc($root, 'TaxCurrencyCode', 'SAR');

        if ($inv->billingReference) {
            $br = $this->cac($root, 'BillingReference');
            $ref = $this->cac($br, 'InvoiceDocumentReference');
            $this->cbc($ref, 'ID', $inv->billingReference);
        }

        // Invoice counter value + previous invoice hash
        $icv = $this->cac($root, 'AdditionalDocumentReference');
        $this->cbc($icv, 'ID', 'ICV');
        $this->cbc($icv, 'UUID', (string) $inv->icv);

        $pih = $this->cac($root, 'AdditionalDocumentReference');
        $this->cbc($pih, 'ID', 'PIH');
        $att = $this->cac($pih, 'Attachment');
        $this->cbc($att, 'EmbeddedDocumentBinaryObject', $inv->pih, ['mimeCode' => 'text/plain']);

        // Signature placeholder reference (required by ZATCA schema; removed again for hashing)
        $sig = $this->cac($root, 'Signature');
        $this->cbc($sig, 'ID', 'urn:oasis:names:specification:ubl:signature:Invoice');
        $this->cbc($sig, 'SignatureMethod', 'urn:oasis:names:specification:ubl:dsig:enveloped:xades');

        $this->party($root, 'AccountingSupplierParty', $inv->seller, true);
        $this->party($root, 'AccountingCustomerParty', $inv->buyer, false);

        $delivery = $this->cac($root, 'Delivery');
        $this->cbc($delivery, 'ActualDeliveryDate', $inv->supplyDate ?: $inv->issueDate);
        if ($inv->summary && $inv->supplyEndDate) {
            $this->cbc($delivery, 'LatestDeliveryDate', $inv->supplyEndDate);
        }

        $pm = $this->cac($root, 'PaymentMeans');
        $this->cbc($pm, 'PaymentMeansCode', $inv->paymentMeans);
        if ($inv->reason && $inv->subType !== InvoiceData::SUB_INVOICE) {
            $this->cbc($pm, 'InstructionNote', $inv->reason);
        }

        // Document level allowance (we only support line level discounts -> 0.00, kept for schema completeness)
        $ac = $this->cac($root, 'AllowanceCharge');
        $this->cbc($ac, 'ChargeIndicator', 'false');
        $this->cbc($ac, 'AllowanceChargeReason', 'discount');
        $this->amount($ac, 'Amount', $inv->allowanceTotal, $cur);
        // the document level tax category follows the dominant category of the invoice
        $first = array_values($inv->taxSubtotals)[0] ?? ['category' => 'S', 'percent' => '15.00', 'code' => null, 'reason' => null];
        $this->taxCategory($ac, $first['category'], $first['percent'], null, null, true);

        // TaxTotal #1 — amount only (in SAR)
        $tt1 = $this->cac($root, 'TaxTotal');
        $this->amount($tt1, 'TaxAmount', $inv->taxAmount, 'SAR');

        // TaxTotal #2 — with breakdown
        $tt2 = $this->cac($root, 'TaxTotal');
        $this->amount($tt2, 'TaxAmount', $inv->taxAmount, 'SAR');
        foreach ($inv->taxSubtotals as $st) {
            $sub = $this->cac($tt2, 'TaxSubtotal');
            $this->amount($sub, 'TaxableAmount', $st['taxable'], $cur);
            $this->amount($sub, 'TaxAmount', $st['tax'], 'SAR');
            $this->taxCategory($sub, $st['category'], $st['percent'], $st['code'], $st['reason'], true);
        }

        $lmt = $this->cac($root, 'LegalMonetaryTotal');
        $this->amount($lmt, 'LineExtensionAmount', $inv->lineExtension, $cur);
        $this->amount($lmt, 'TaxExclusiveAmount', $inv->taxExclusive, $cur);
        $this->amount($lmt, 'TaxInclusiveAmount', $inv->taxInclusive, $cur);
        $this->amount($lmt, 'AllowanceTotalAmount', $inv->allowanceTotal, $cur);
        $this->amount($lmt, 'PrepaidAmount', $inv->prepaid, $cur);
        $this->amount($lmt, 'PayableAmount', $inv->payable, $cur);

        foreach (array_values($inv->lines) as $i => $line) {
            $il = $this->cac($root, 'InvoiceLine');
            $this->cbc($il, 'ID', (string) ($i + 1));
            $this->cbc($il, 'InvoicedQuantity', $this->qty($line->quantity), ['unitCode' => $line->unitCode]);
            $this->amount($il, 'LineExtensionAmount', $line->net, $cur);

            if ($this->isPositive($line->discount)) {
                $lac = $this->cac($il, 'AllowanceCharge');
                $this->cbc($lac, 'ChargeIndicator', 'false');
                $this->cbc($lac, 'AllowanceChargeReason', 'discount');
                $this->amount($lac, 'Amount', $this->two($line->discount), $cur);
            }

            $tt = $this->cac($il, 'TaxTotal');
            $this->amount($tt, 'TaxAmount', $line->tax, 'SAR');
            $this->amount($tt, 'RoundingAmount', $line->gross, 'SAR');

            $item = $this->cac($il, 'Item');
            $this->cbc($item, 'Name', $line->name);
            $ctc = $this->cac($item, 'ClassifiedTaxCategory');
            $this->cbc($ctc, 'ID', $line->taxCategory);
            $this->cbc($ctc, 'Percent', $this->two($line->taxPercent));
            $ts = $this->cac($ctc, 'TaxScheme');
            $this->cbc($ts, 'ID', 'VAT');

            $price = $this->cac($il, 'Price');
            $this->amount($price, 'PriceAmount', $this->price($line->unitPrice), $cur);
        }

        return (string) $this->doc->saveXML();
    }

    private function party(DOMElement $root, string $wrapper, Party $p, bool $isSeller): void
    {
        $w = $this->cac($root, $wrapper);
        $party = $this->cac($w, 'Party');

        if ($p->idNumber) {
            $pi = $this->cac($party, 'PartyIdentification');
            $this->cbc($pi, 'ID', $p->idNumber, ['schemeID' => $p->idScheme]);
        }

        if ($p->street || $p->city || $p->building || $p->postalZone) {
            $addr = $this->cac($party, 'PostalAddress');
            if ($p->street) {
                $this->cbc($addr, 'StreetName', $p->street);
            }
            if ($p->building) {
                $this->cbc($addr, 'BuildingNumber', $p->building);
            }
            if ($p->plot) {
                $this->cbc($addr, 'PlotIdentification', $p->plot);
            }
            if ($p->district) {
                $this->cbc($addr, 'CitySubdivisionName', $p->district);
            }
            if ($p->city) {
                $this->cbc($addr, 'CityName', $p->city);
            }
            if ($p->postalZone) {
                $this->cbc($addr, 'PostalZone', $p->postalZone);
            }
            $country = $this->cac($addr, 'Country');
            $this->cbc($country, 'IdentificationCode', $p->country);
        }

        if ($p->vat) {
            $pts = $this->cac($party, 'PartyTaxScheme');
            $this->cbc($pts, 'CompanyID', $p->vat);
            $ts = $this->cac($pts, 'TaxScheme');
            $this->cbc($ts, 'ID', 'VAT');
        }

        if ($p->name !== '' || $isSeller) {
            $ple = $this->cac($party, 'PartyLegalEntity');
            $this->cbc($ple, 'RegistrationName', $p->name);
        }
    }

    private function taxCategory(DOMElement $parent, string $category, string $percent, ?string $code, ?string $reason, bool $withSchemeAttrs): void
    {
        $tc = $this->cac($parent, 'TaxCategory');
        $this->cbc($tc, 'ID', $category, $withSchemeAttrs ? ['schemeID' => 'UN/ECE 5305', 'schemeAgencyID' => '6'] : []);
        $this->cbc($tc, 'Percent', $this->two($percent));
        if ($category !== 'S') {
            if ($code) {
                $this->cbc($tc, 'TaxExemptionReasonCode', $code);
            }
            if ($reason) {
                $this->cbc($tc, 'TaxExemptionReason', $reason);
            }
        }
        $ts = $this->cac($tc, 'TaxScheme');
        $this->cbc($ts, 'ID', 'VAT', $withSchemeAttrs ? ['schemeID' => 'UN/ECE 5153', 'schemeAgencyID' => '6'] : []);
    }

    private function cbc(DOMElement $parent, string $name, string $value, array $attrs = []): DOMElement
    {
        $el = $this->doc->createElementNS(self::NS_CBC, 'cbc:'.$name);
        $el->appendChild($this->doc->createTextNode($value));
        foreach ($attrs as $k => $v) {
            $el->setAttribute($k, $v);
        }
        $parent->appendChild($el);

        return $el;
    }

    private function amount(DOMElement $parent, string $name, string $value, string $currency): DOMElement
    {
        return $this->cbc($parent, $name, $value, ['currencyID' => $currency]);
    }

    private function cac(DOMElement $parent, string $name): DOMElement
    {
        $el = $this->doc->createElementNS(self::NS_CAC, 'cac:'.$name);
        $parent->appendChild($el);

        return $el;
    }

    private function two(string $v): string
    {
        return number_format((float) $v, 2, '.', '');
    }

    private function price(string $v): string
    {
        // up to 4 decimals, at least 2 (ZATCA allows up to 4 for unit prices)
        $s = rtrim(rtrim(number_format((float) $v, 4, '.', ''), '0'), '.');
        if (! str_contains($s, '.')) {
            return $s.'.00';
        }
        $dec = strlen(substr($s, strpos($s, '.') + 1));

        return $dec < 2 ? $s.str_repeat('0', 2 - $dec) : $s;
    }

    private function qty(string $v): string
    {
        return number_format((float) $v, 6, '.', '');
    }

    private function isPositive(string $v): bool
    {
        return (float) $v > 0;
    }
}
