<?php

declare(strict_types=1);

namespace App\Zatca\Crypto;

use App\Zatca\Qr\QrPayload;
use DateTimeImmutable;
use DateTimeZone;
use DOMDocument;
use DOMElement;
use DOMXPath;
use RuntimeException;

/**
 * Applies the ZATCA Phase 2 signature to an unsigned UBL invoice:
 *  1. invoice hash  = base64(sha256(C14N(invoice minus UBLExtensions, cac:Signature, QR reference)))
 *  2. signature     = base64(ECDSA-SHA256(private key, raw invoice hash bytes))
 *  3. XAdES signed properties (certificate digest, issuer + serial, signing time) and their digest
 *  4. QR code (TLV, base64) for simplified invoices
 */
final class InvoiceSigner
{
    private const NS_INVOICE = 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2';
    private const NS_CAC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2';
    private const NS_CBC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2';
    private const NS_EXT = 'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2';
    private const NS_SIG = 'urn:oasis:names:specification:ubl:schema:xsd:CommonSignatureComponents-2';
    private const NS_SAC = 'urn:oasis:names:specification:ubl:schema:xsd:SignatureAggregateComponents-2';
    private const NS_SBC = 'urn:oasis:names:specification:ubl:schema:xsd:SignatureBasicComponents-2';
    private const NS_DS = 'http://www.w3.org/2000/09/xmldsig#';
    private const NS_XADES = 'http://uri.etsi.org/01903/v1.3.2#';
    private const NS_XMLNS = 'http://www.w3.org/2000/xmlns/';
    private const SHA256 = 'http://www.w3.org/2001/04/xmlenc#sha256';
    private const C14N11 = 'http://www.w3.org/2006/12/xml-c14n11';

    /** PIH used by the very first invoice of an EGS unit: base64(hex(sha256("0"))) */
    public static function firstPreviousHash(): string
    {
        return base64_encode(hash('sha256', '0'));
    }

    /** base64 raw SHA-256 of the canonicalised invoice, exactly as ZATCA's transforms define it. */
    public function invoiceHash(string $xml): string
    {
        $doc = $this->load($xml);
        $xp = $this->xpath($doc);
        foreach ($xp->query('/inv:Invoice/ext:UBLExtensions | /inv:Invoice/cac:Signature | /inv:Invoice/cac:AdditionalDocumentReference[cbc:ID="QR"]') ?: [] as $n) {
            $n->parentNode?->removeChild($n);
        }

        return base64_encode(hash('sha256', $doc->C14N(false, false), true));
    }

    /**
     * @return array{xml:string,hash:string,signature:string,qr:?string,uuid:string}
     */
    public function sign(string $unsignedXml, string $certificate, string $privateKeyPem, ?DateTimeImmutable $signingTime = null): array
    {
        $cert = CertificateInfo::fromAny($certificate);
        $key = openssl_pkey_get_private($privateKeyPem);
        if ($key === false) {
            throw new RuntimeException('Private key could not be read.');
        }

        $hash = $this->invoiceHash($unsignedXml);
        $hashBytes = (string) base64_decode($hash, true);
        if (! openssl_sign($hashBytes, $sigDer, $key, OPENSSL_ALGO_SHA256)) {
            throw new RuntimeException('ECDSA signing failed.');
        }
        $signature = base64_encode($sigDer);

        $doc = $this->load($unsignedXml);
        $xp = $this->xpath($doc);
        $root = $doc->documentElement;
        $isSimplified = str_starts_with((string) $xp->evaluate('string(/inv:Invoice/cbc:InvoiceTypeCode/@name)'), '02');

        // --- QR (simplified invoices only; ZATCA stamps the QR of cleared standard invoices) ---
        $qr = null;
        if ($isSimplified) {
            $qr = QrPayload::build(
                sellerName: (string) $xp->evaluate('string(/inv:Invoice/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName)'),
                vatNumber: (string) $xp->evaluate('string(/inv:Invoice/cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID)'),
                timestamp: (string) $xp->evaluate('string(/inv:Invoice/cbc:IssueDate)').'T'.(string) $xp->evaluate('string(/inv:Invoice/cbc:IssueTime)'),
                total: (string) $xp->evaluate('string(/inv:Invoice/cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount)'),
                vatTotal: (string) $xp->evaluate('string(/inv:Invoice/cac:TaxTotal[1]/cbc:TaxAmount)'),
                invoiceHashB64: $hash,
                signatureB64: $signature,
                publicKeyDer: $cert->publicKeyDer,
                certificateSignature: $cert->signatureBytes,
            );
            $sigRef = $xp->query('/inv:Invoice/cac:Signature')->item(0);
            $qrRef = $doc->createElementNS(self::NS_CAC, 'cac:AdditionalDocumentReference');
            $qrRef->appendChild($this->el($doc, self::NS_CBC, 'cbc:ID', 'QR'));
            $att = $doc->createElementNS(self::NS_CAC, 'cac:Attachment');
            $att->appendChild($this->el($doc, self::NS_CBC, 'cbc:EmbeddedDocumentBinaryObject', $qr, ['mimeCode' => 'text/plain']));
            $qrRef->appendChild($att);
            $root->insertBefore($qrRef, $sigRef);
        }

        // --- XAdES signature extension ---
        $time = ($signingTime ?? new DateTimeImmutable('now', new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('UTC'));
        $ublExt = $this->buildExtension($doc, $hash, $signature, $cert, $time->format('Y-m-d\TH:i:s\Z'));
        $root->insertBefore($ublExt, $root->firstChild);

        // The SignedProperties digest is taken from the node as it sits in the final document.
        $sp = $xp->query('//xades:SignedProperties')->item(0);
        $digestNode = $xp->query('//ds:Reference[@URI="#xadesSignedProperties"]/ds:DigestValue')->item(0);
        $digestNode->textContent = base64_encode(hash('sha256', $sp->C14N(true, false)));

        $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".$this->dedupeNamespaces((string) $doc->saveXML($root));

        return [
            'xml' => $xml,
            'hash' => $hash,
            'signature' => $signature,
            'qr' => $qr,
            'uuid' => (string) $xp->evaluate('string(/inv:Invoice/cbc:UUID)'),
        ];
    }

    /**
     * Local integrity check of a signed invoice: recompute the hash, the signed-properties digest,
     * the certificate digest and verify the ECDSA signature with the embedded certificate.
     *
     * @return array{hash:bool,signature:bool,signed_properties:bool,certificate_digest:bool}
     */
    public function verify(string $signedXml): array
    {
        $doc = $this->load($signedXml);
        $xp = $this->xpath($doc);
        $declaredHash = (string) $xp->evaluate('string(//ds:Reference[@Id="invoiceSignedData"]/ds:DigestValue)');
        $declaredProps = (string) $xp->evaluate('string(//ds:Reference[@URI="#xadesSignedProperties"]/ds:DigestValue)');
        $sigValue = (string) $xp->evaluate('string(//ds:SignatureValue)');
        $certB64 = (string) $xp->evaluate('string(//ds:X509Certificate)');
        $certDigest = (string) $xp->evaluate('string(//xades:CertDigest/ds:DigestValue)');
        $props = $xp->query('//xades:SignedProperties')->item(0);

        $recomputed = $this->invoiceHash($signedXml);
        $propsOk = $props instanceof DOMElement
            && $declaredProps === base64_encode(hash('sha256', $props->C14N(true, false)));
        $certOk = $certB64 !== '' && $certDigest === base64_encode(hash('sha256', $certB64));

        $sigOk = false;
        if ($certB64 !== '' && $sigValue !== '') {
            $pem = "-----BEGIN CERTIFICATE-----\n".chunk_split($certB64, 64, "\n")."-----END CERTIFICATE-----\n";
            $pub = openssl_pkey_get_public($pem);
            $sigOk = $pub !== false
                && openssl_verify((string) base64_decode($recomputed, true), (string) base64_decode($sigValue, true), $pub, OPENSSL_ALGO_SHA256) === 1;
        }

        return [
            'hash' => $declaredHash !== '' && hash_equals($declaredHash, $recomputed),
            'signature' => $sigOk,
            'signed_properties' => $propsOk,
            'certificate_digest' => $certOk,
        ];
    }

    private function buildExtension(DOMDocument $doc, string $hash, string $signature, CertificateInfo $cert, string $signingTime): DOMElement
    {
        $exts = $doc->createElementNS(self::NS_EXT, 'ext:UBLExtensions');
        $ext = $doc->createElementNS(self::NS_EXT, 'ext:UBLExtension');
        $exts->appendChild($ext);
        $ext->appendChild($this->el($doc, self::NS_EXT, 'ext:ExtensionURI', 'urn:oasis:names:specification:ubl:dsig:enveloped:xades'));
        $content = $doc->createElementNS(self::NS_EXT, 'ext:ExtensionContent');
        $ext->appendChild($content);

        $docSigs = $doc->createElementNS(self::NS_SIG, 'sig:UBLDocumentSignatures');
        $docSigs->setAttributeNS(self::NS_XMLNS, 'xmlns:sac', self::NS_SAC);
        $docSigs->setAttributeNS(self::NS_XMLNS, 'xmlns:sbc', self::NS_SBC);
        $content->appendChild($docSigs);
        $info = $doc->createElementNS(self::NS_SAC, 'sac:SignatureInformation');
        $docSigs->appendChild($info);
        $info->appendChild($this->el($doc, self::NS_CBC, 'cbc:ID', 'urn:oasis:names:specification:ubl:signature:1'));
        $info->appendChild($this->el($doc, self::NS_SBC, 'sbc:ReferencedSignatureID', 'urn:oasis:names:specification:ubl:signature:Invoice'));

        $ds = $doc->createElementNS(self::NS_DS, 'ds:Signature');
        $ds->setAttribute('Id', 'signature');
        $info->appendChild($ds);

        // SignedProperties are built first (inside the document) so their digest is taken from the real node.
        $obj = $doc->createElementNS(self::NS_DS, 'ds:Object');
        $qp = $doc->createElementNS(self::NS_XADES, 'xades:QualifyingProperties');
        $qp->setAttribute('Target', 'signature');
        $obj->appendChild($qp);
        $sp = $doc->createElementNS(self::NS_XADES, 'xades:SignedProperties');
        $sp->setAttribute('Id', 'xadesSignedProperties');
        $qp->appendChild($sp);
        $ssp = $doc->createElementNS(self::NS_XADES, 'xades:SignedSignatureProperties');
        $sp->appendChild($ssp);
        $ssp->appendChild($this->el($doc, self::NS_XADES, 'xades:SigningTime', $signingTime));
        $sc = $doc->createElementNS(self::NS_XADES, 'xades:SigningCertificate');
        $ssp->appendChild($sc);
        $c = $doc->createElementNS(self::NS_XADES, 'xades:Cert');
        $sc->appendChild($c);
        $cd = $doc->createElementNS(self::NS_XADES, 'xades:CertDigest');
        $c->appendChild($cd);
        $dm = $doc->createElementNS(self::NS_DS, 'ds:DigestMethod');
        $dm->setAttribute('Algorithm', self::SHA256);
        $cd->appendChild($dm);
        $cd->appendChild($this->el($doc, self::NS_DS, 'ds:DigestValue', base64_encode(hash('sha256', $cert->body))));
        $is = $doc->createElementNS(self::NS_XADES, 'xades:IssuerSerial');
        $c->appendChild($is);
        $is->appendChild($this->el($doc, self::NS_DS, 'ds:X509IssuerName', $cert->issuerName));
        $is->appendChild($this->el($doc, self::NS_DS, 'ds:X509SerialNumber', $cert->serialDecimal));

        // Declare namespaces on the apex only; exclusive C14N renders the minimal set.
        $ds->setAttributeNS(self::NS_XMLNS, 'xmlns:ds', self::NS_DS);
        $qp->setAttributeNS(self::NS_XMLNS, 'xmlns:xades', self::NS_XADES);

        $signedInfo = $doc->createElementNS(self::NS_DS, 'ds:SignedInfo');
        $ds->appendChild($signedInfo);
        $cm = $doc->createElementNS(self::NS_DS, 'ds:CanonicalizationMethod');
        $cm->setAttribute('Algorithm', self::C14N11);
        $signedInfo->appendChild($cm);
        $sm = $doc->createElementNS(self::NS_DS, 'ds:SignatureMethod');
        $sm->setAttribute('Algorithm', 'http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256');
        $signedInfo->appendChild($sm);

        $ref1 = $doc->createElementNS(self::NS_DS, 'ds:Reference');
        $ref1->setAttribute('Id', 'invoiceSignedData');
        $ref1->setAttribute('URI', '');
        $signedInfo->appendChild($ref1);
        $transforms = $doc->createElementNS(self::NS_DS, 'ds:Transforms');
        $ref1->appendChild($transforms);
        foreach (['not(//ancestor-or-self::ext:UBLExtensions)', 'not(//ancestor-or-self::cac:Signature)', "not(//ancestor-or-self::cac:AdditionalDocumentReference[cbc:ID='QR'])"] as $xpath) {
            $t = $doc->createElementNS(self::NS_DS, 'ds:Transform');
            $t->setAttribute('Algorithm', 'http://www.w3.org/TR/1999/REC-xpath-19991116');
            $t->appendChild($this->el($doc, self::NS_DS, 'ds:XPath', $xpath));
            $transforms->appendChild($t);
        }
        $t = $doc->createElementNS(self::NS_DS, 'ds:Transform');
        $t->setAttribute('Algorithm', self::C14N11);
        $transforms->appendChild($t);
        $dm1 = $doc->createElementNS(self::NS_DS, 'ds:DigestMethod');
        $dm1->setAttribute('Algorithm', self::SHA256);
        $ref1->appendChild($dm1);
        $ref1->appendChild($this->el($doc, self::NS_DS, 'ds:DigestValue', $hash));

        $ref2 = $doc->createElementNS(self::NS_DS, 'ds:Reference');
        $ref2->setAttribute('Type', 'http://www.w3.org/2000/09/xmldsig#SignatureProperties');
        $ref2->setAttribute('URI', '#xadesSignedProperties');
        $signedInfo->appendChild($ref2);
        $dm2 = $doc->createElementNS(self::NS_DS, 'ds:DigestMethod');
        $dm2->setAttribute('Algorithm', self::SHA256);
        $ref2->appendChild($dm2);
        $ref2->appendChild($this->el($doc, self::NS_DS, 'ds:DigestValue', ''));  // filled in once attached to the tree

        $ds->appendChild($this->el($doc, self::NS_DS, 'ds:SignatureValue', $signature));
        $ki = $doc->createElementNS(self::NS_DS, 'ds:KeyInfo');
        $x509 = $doc->createElementNS(self::NS_DS, 'ds:X509Data');
        $x509->appendChild($this->el($doc, self::NS_DS, 'ds:X509Certificate', $cert->body));
        $ki->appendChild($x509);
        $ds->appendChild($ki);
        $ds->appendChild($obj);

        return $exts;
    }

    /**
     * DOM serialisation repeats namespace declarations on nodes that were created before being attached.
     * They are harmless to canonical XML (so hashes are unaffected) but bloat the file; keep the first
     * declaration of each prefix, which always sits on an ancestor of every later use.
     */
    private function dedupeNamespaces(string $xml): string
    {
        $seen = [];

        return (string) preg_replace_callback('/<[A-Za-z][^<>]*>/', function (array $m) use (&$seen): string {
            return (string) preg_replace_callback('/ xmlns:([A-Za-z0-9]+)="([^"]*)"/', function (array $d) use (&$seen): string {
                $key = $d[1].'='.$d[2];
                if (isset($seen[$key])) {
                    return '';
                }
                $seen[$key] = true;

                return $d[0];
            }, $m[0]);
        }, $xml);
    }

    private function el(DOMDocument $doc, string $ns, string $qname, string $text, array $attrs = []): DOMElement
    {
        $e = $doc->createElementNS($ns, $qname);
        $e->appendChild($doc->createTextNode($text));
        foreach ($attrs as $k => $v) {
            $e->setAttribute($k, $v);
        }

        return $e;
    }

    private function load(string $xml): DOMDocument
    {
        $doc = new DOMDocument('1.0', 'UTF-8');
        $doc->preserveWhiteSpace = false;
        if (! @$doc->loadXML($xml, LIBXML_NONET | LIBXML_NOBLANKS)) {
            throw new RuntimeException('Invoice XML is not well-formed.');
        }

        return $doc;
    }

    private function xpath(DOMDocument $doc): DOMXPath
    {
        $xp = new DOMXPath($doc);
        $xp->registerNamespace('inv', self::NS_INVOICE);
        $xp->registerNamespace('cac', self::NS_CAC);
        $xp->registerNamespace('cbc', self::NS_CBC);
        $xp->registerNamespace('ext', self::NS_EXT);
        $xp->registerNamespace('ds', self::NS_DS);
        $xp->registerNamespace('xades', self::NS_XADES);

        return $xp;
    }
}
