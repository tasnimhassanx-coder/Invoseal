<?php

declare(strict_types=1);

namespace App\Zatca\Crypto;

use RuntimeException;

/**
 * Generates a secp256k1 key pair and a ZATCA-compliant CSR.
 * The certificate template name differs per environment (sandbox / simulation / production).
 */
final class CsrGenerator
{
    public const TEMPLATES = [
        'sandbox' => 'TSTZATCA-Code-Signing',
        'simulation' => 'PREZATCA-Code-Signing',
        'production' => 'ZATCA-Code-Signing',
    ];

    /**
     * @param  array{common_name:string,organization:string,organizational_unit:string,vat_number:string,serial:string,invoice_types:string,address:string,business_category:string,environment:string,country?:string}  $in
     * @return array{private_key:string,csr:string}  PEM strings
     */
    public function generate(array $in): array
    {
        $template = self::TEMPLATES[$in['environment']] ?? self::TEMPLATES['production'];
        $conf = $this->configFile($in, $template);

        try {
            $key = openssl_pkey_new([
                'private_key_type' => OPENSSL_KEYTYPE_EC,
                'curve_name' => 'secp256k1',
                'config' => $conf,
            ]);
            if ($key === false) {
                throw new RuntimeException('Could not generate secp256k1 key: '.$this->lastError());
            }

            $dn = [
                'countryName' => $in['country'] ?? 'SA',
                'organizationalUnitName' => $in['organizational_unit'],
                'organizationName' => $in['organization'],
                'commonName' => $in['common_name'],
            ];
            $csr = openssl_csr_new($dn, $key, [
                'digest_alg' => 'sha256',
                'config' => $conf,
                'req_extensions' => 'req_ext',
            ]);
            if ($csr === false) {
                throw new RuntimeException('Could not create CSR: '.$this->lastError());
            }
            if (! openssl_csr_export($csr, $csrPem)) {
                throw new RuntimeException('Could not export CSR: '.$this->lastError());
            }
            if (! openssl_pkey_export($key, $keyPem, null, ['config' => $conf])) {
                throw new RuntimeException('Could not export private key: '.$this->lastError());
            }
        } finally {
            @unlink($conf);
        }

        return ['private_key' => $keyPem, 'csr' => $csrPem];
    }

    private function configFile(array $in, string $template): string
    {
        $clean = static fn (string $v): string => str_replace(["\r", "\n", '$'], ['', '', ''], $v);
        $cfg = <<<CFG
        oid_section = OIDs
        [ OIDs ]
        certificateTemplateName = 1.3.6.1.4.1.311.20.2
        [ req ]
        default_bits = 2048
        prompt = no
        default_md = sha256
        distinguished_name = dn
        req_extensions = req_ext
        [ dn ]
        CN = placeholder
        [ req_ext ]
        certificateTemplateName = ASN1:PRINTABLESTRING:{$template}
        subjectAltName = dirName:alt_names
        [ alt_names ]
        SN = {$clean($in['serial'])}
        UID = {$clean($in['vat_number'])}
        title = {$clean($in['invoice_types'])}
        registeredAddress = {$clean($in['address'])}
        businessCategory = {$clean($in['business_category'])}
        CFG;

        $path = tempnam(sys_get_temp_dir(), 'invoseal-csr-');
        if ($path === false || file_put_contents($path, $cfg) === false) {
            throw new RuntimeException('Could not write temporary OpenSSL config.');
        }
        chmod($path, 0600);

        return $path;
    }

    private function lastError(): string
    {
        $errs = [];
        while (($e = openssl_error_string()) !== false) {
            $errs[] = $e;
        }

        return implode(' | ', $errs) ?: 'unknown OpenSSL error';
    }
}
