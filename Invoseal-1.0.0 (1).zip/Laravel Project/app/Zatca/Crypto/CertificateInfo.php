<?php

declare(strict_types=1);

namespace App\Zatca\Crypto;

use App\Zatca\Support\Der;
use DateTimeImmutable;

/**
 * Reads the pieces of an X.509 certificate that ZATCA signing needs:
 * the issuer name (RFC 2253 order), decimal serial, SPKI DER, signature bytes, validity.
 */
final class CertificateInfo
{
    private const OIDS = [
        '2.5.4.3' => 'CN', '2.5.4.6' => 'C', '2.5.4.7' => 'L', '2.5.4.8' => 'ST', '2.5.4.10' => 'O',
        '2.5.4.11' => 'OU', '0.9.2342.19200300.100.1.25' => 'DC', '1.2.840.113549.1.9.1' => 'E',
        '2.5.4.5' => 'SERIALNUMBER', '2.5.4.4' => 'SN',
    ];

    private function __construct(
        public readonly string $body,          // base64 body without PEM armour / line breaks
        public readonly string $der,
        public readonly string $issuerName,
        public readonly string $serialDecimal,
        public readonly string $publicKeyDer,
        public readonly string $signatureBytes,
        public readonly ?DateTimeImmutable $validFrom,
        public readonly ?DateTimeImmutable $validTo,
        public readonly string $subject,
    ) {}

    /** Accepts a PEM certificate or the bare base64 body. */
    public static function fromAny(string $cert): self
    {
        $body = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $cert) ?? '';
        $der = base64_decode($body, true);
        if ($der === false || $der === '') {
            throw new \InvalidArgumentException('Certificate is not valid base64/PEM.');
        }
        $pem = "-----BEGIN CERTIFICATE-----\n".chunk_split($body, 64, "\n")."-----END CERTIFICATE-----\n";
        $parsed = openssl_x509_parse($pem);
        if ($parsed === false) {
            throw new \InvalidArgumentException('Certificate could not be parsed by OpenSSL.');
        }

        // Certificate ::= SEQUENCE { tbsCertificate, signatureAlgorithm, signatureValue }
        $cert0 = Der::read($der, 0);
        $top = Der::children($der, $cert0);
        $tbs = $top[0];
        $sigVal = $top[2];
        $tbsKids = Der::children($der, $tbs);
        $i = 0;
        if ($tbsKids[0]['tag'] === 0xA0) { // explicit [0] version
            $i = 1;
        }
        // serial, sigAlg, issuer, validity, subject, spki
        $issuerNode = $tbsKids[$i + 2];
        $issuerName = self::formatName($der, $issuerNode);

        $pub = openssl_pkey_get_public($pem);
        $details = $pub ? openssl_pkey_get_details($pub) : null;
        $spkiPem = $details['key'] ?? '';
        $spkiDer = base64_decode(preg_replace('/-----(BEGIN|END) PUBLIC KEY-----|\s+/', '', $spkiPem) ?? '', true) ?: '';

        // signatureValue is a BIT STRING: first content byte = unused bits (0)
        $sig = substr(Der::raw($der, $sigVal), 1);

        return new self(
            body: $body,
            der: $der,
            issuerName: $issuerName,
            serialDecimal: (string) ($parsed['serialNumber'] ?? ''),
            publicKeyDer: $spkiDer,
            signatureBytes: $sig,
            validFrom: isset($parsed['validFrom_time_t']) ? (new DateTimeImmutable('@'.$parsed['validFrom_time_t'])) : null,
            validTo: isset($parsed['validTo_time_t']) ? (new DateTimeImmutable('@'.$parsed['validTo_time_t'])) : null,
            subject: (string) ($parsed['name'] ?? ''),
        );
    }

    /** Issuer in ZATCA/RFC 2253 order: most specific RDN first, e.g. "CN=X, DC=extgazt, DC=gov, DC=local". */
    private static function formatName(string $der, array $nameNode): string
    {
        $parts = [];
        foreach (Der::children($der, $nameNode) as $rdnSet) {
            foreach (Der::children($der, $rdnSet) as $atv) {
                $kids = Der::children($der, $atv);
                $oid = Der::oid(Der::raw($der, $kids[0]));
                $val = Der::raw($der, $kids[1]);
                $label = self::OIDS[$oid] ?? $oid;
                $parts[] = $label.'='.$val;
            }
        }

        return implode(', ', array_reverse($parts));
    }

    public function isExpired(?DateTimeImmutable $now = null): bool
    {
        return $this->validTo !== null && ($now ?? new DateTimeImmutable('now')) > $this->validTo;
    }
}
