<?php

namespace App\Services;

use App\Models\ApiKey;
use App\Models\AuditLog;
use App\Models\Company;
use Illuminate\Database\Eloquent\Model;

/** Append-only audit trail of who did what (users in the panel, API keys, the system itself). */
final class AuditLogger
{
    public static function log(string $action, ?Model $subject = null, array $meta = [], ?Company $company = null, ?ApiKey $apiKey = null): void
    {
        $request = app()->runningInConsole() ? null : request();
        $apiKey ??= $request?->attributes->get('api_key');

        AuditLog::create([
            'user_id' => auth()->id(),
            'api_key_id' => $apiKey?->id,
            'company_id' => $company?->id ?? ($subject instanceof Company ? $subject->id : ($subject?->company_id ?? null)),
            'action' => $action,
            'subject_type' => $subject ? class_basename($subject) : null,
            'subject_id' => $subject?->getKey(),
            'ip' => $request?->ip(),
            'meta' => $meta ?: null,
        ]);
    }
}
