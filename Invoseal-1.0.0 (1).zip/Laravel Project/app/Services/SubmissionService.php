<?php

namespace App\Services;

use App\Enums\InvoiceStatus;
use App\Jobs\DeliverWebhookJob;
use App\Models\Invoice;
use App\Models\Submission;
use App\Zatca\Api\ZatcaClient;
use App\Zatca\Api\ZatcaResponse;
use App\Zatca\Qr\QrPayload;

/**
 * Sends one signed invoice to ZATCA (clearance for standard / reporting for simplified)
 * and moves it through its lifecycle. Safe to call repeatedly: only pending/failed invoices are sent.
 */
class SubmissionService
{
    public function client(Invoice $invoice): ZatcaClient
    {
        $egs = $invoice->egsUnit;

        return new ZatcaClient(
            environment: $egs->environment,
            baseUrl: config('invoseal.zatca_base_url') ?: null,
            timeout: (int) config('invoseal.zatca_timeout'),
        );
    }

    /** @return InvoiceStatus the invoice status after this attempt */
    public function submit(Invoice $invoice): InvoiceStatus
    {
        // Claim the invoice so two workers can never submit the same one.
        $claimed = Invoice::whereKey($invoice->id)
            ->whereIn('status', [InvoiceStatus::Pending->value, InvoiceStatus::Failed->value])
            ->update(['status' => InvoiceStatus::Submitting->value]);
        if (! $claimed) {
            return $invoice->fresh()->status;
        }
        $invoice->refresh()->loadMissing('egsUnit');
        $egs = $invoice->egsUnit;

        $attempt = $invoice->attempts + 1;
        $client = $this->client($invoice);
        $token = (string) $egs->production_certificate;
        $secret = (string) $egs->production_secret;

        $res = $invoice->type === 'standard'
            ? $client->clear($token, $secret, $invoice->signed_xml, $invoice->invoice_hash, $invoice->uuid)
            : $client->report($token, $secret, $invoice->signed_xml, $invoice->invoice_hash, $invoice->uuid);

        $status = $this->apply($invoice, $res, $attempt);

        if ($status->isFinal() || $status === InvoiceStatus::Failed) {
            $this->notify($invoice, $status);
        }

        return $status;
    }

    private function apply(Invoice $invoice, ZatcaResponse $res, int $attempt): InvoiceStatus
    {
        $errors = $res->errors();
        $warnings = $res->warnings();
        $clearedOk = $invoice->type === 'standard'
            ? in_array($res->clearanceStatus(), [null, 'CLEARED'], true)
            : in_array($res->reportingStatus(), [null, 'REPORTED'], true);

        $update = ['attempts' => $attempt, 'submitted_at' => now(), 'next_retry_at' => null];
        $result = 'error';

        if ($res->accepted() && $clearedOk) {
            $result = $warnings || $res->status === 202 ? 'warning' : 'accepted';
            $status = $invoice->type === 'standard' ? InvoiceStatus::Cleared : InvoiceStatus::Reported;
            $update = array_merge($update, ['status' => $status, 'has_warnings' => $result === 'warning', 'last_error' => null]);
            if ($cleared = $res->clearedInvoiceXml()) {
                $update['cleared_xml'] = $cleared;
                $update['qr_code'] = $this->qrFrom($cleared) ?? $invoice->qr_code;
            }
        } elseif ($res->duplicate()) {
            // ZATCA already has this invoice: treat as delivered.
            $result = 'warning';
            $status = $invoice->type === 'standard' ? InvoiceStatus::Cleared : InvoiceStatus::Reported;
            $update = array_merge($update, ['status' => $status, 'has_warnings' => true, 'last_error' => 'ZATCA reported this invoice as already submitted (HTTP 409).']);
        } elseif ($res->retryable()) {
            $result = 'error';
            $maxAge = now()->subHours((int) config('invoseal.retry_max_hours'));
            $backoff = config('invoseal.retry_backoff');
            if ($invoice->created_at->lt($maxAge)) {
                $status = InvoiceStatus::Failed;
                $update = array_merge($update, ['status' => $status, 'last_error' => $this->describe($res)]);
            } else {
                $status = InvoiceStatus::Pending;
                $delay = $backoff[min($attempt - 1, count($backoff) - 1)];
                $update = array_merge($update, ['status' => $status, 'next_retry_at' => now()->addSeconds($delay), 'last_error' => $this->describe($res)]);
            }
        } elseif ($res->unauthorized()) {
            // Certificate / credentials problem: not retryable until an admin fixes the EGS unit.
            $status = InvoiceStatus::Failed;
            $update = array_merge($update, ['status' => $status, 'last_error' => 'ZATCA refused the credentials (HTTP '.$res->status.'). Check the EGS unit certificate.']);
        } else {
            $result = 'rejected';
            $status = InvoiceStatus::Rejected;
            $update = array_merge($update, ['status' => $status, 'last_error' => $this->describe($res)]);
        }

        Submission::create([
            'invoice_id' => $invoice->id,
            'endpoint' => $invoice->endpoint(),
            'attempt' => $attempt,
            'http_status' => $res->status,
            'result' => $result,
            'errors' => $errors ?: null,
            'warnings' => $warnings ?: null,
            'response' => $this->trimResponse($res->body),
            'transport_error' => $res->transportError ? mb_substr($res->transportError, 0, 500) : null,
            'duration_ms' => $res->durationMs,
        ]);
        $invoice->update($update);
        if ($status === InvoiceStatus::Cleared || $status === InvoiceStatus::Reported) {
            (new ArchiveService())->store($invoice->refresh());
        }
        AuditLogger::log('invoice.submitted', $invoice, ['status' => $status->value, 'http' => $res->status, 'attempt' => $attempt]);

        return $status;
    }

    private function describe(ZatcaResponse $res): string
    {
        if ($res->isTransportFailure()) {
            return 'Could not reach ZATCA: '.mb_substr((string) $res->transportError, 0, 300);
        }
        $first = $res->errors()[0] ?? null;
        if ($first) {
            $more = count($res->errors()) - 1;

            return trim(($first['code'] ? $first['code'].': ' : '').$first['message']).($more > 0 ? " (+{$more} more)" : '');
        }

        return 'ZATCA answered HTTP '.$res->status.'.';
    }

    /** Never keep the (large, base64) invoice inside the log row. */
    private function trimResponse(array $body): array
    {
        unset($body['clearedInvoice']);

        return $body;
    }

    private function qrFrom(string $xml): ?string
    {
        $doc = new \DOMDocument();
        if (! @$doc->loadXML($xml, LIBXML_NONET)) {
            return null;
        }
        $xp = new \DOMXPath($doc);
        $xp->registerNamespace('cac', 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $xp->registerNamespace('cbc', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        $v = trim((string) $xp->evaluate('string(//cac:AdditionalDocumentReference[cbc:ID="QR"]//cbc:EmbeddedDocumentBinaryObject)'));

        return $v !== '' ? $v : null;
    }

    private function notify(Invoice $invoice, InvoiceStatus $status): void
    {
        $company = $invoice->company;
        if ($company->webhook_url) {
            $event = match ($status) {
                InvoiceStatus::Cleared => 'invoice.cleared',
                InvoiceStatus::Reported => 'invoice.reported',
                InvoiceStatus::Rejected => 'invoice.rejected',
                default => 'invoice.failed',
            };
            DeliverWebhookJob::dispatchForInvoice($invoice, $event);
        }
    }

    /** Decoded QR fields for display (tag => value). */
    public static function qrFields(?string $qr): array
    {
        return $qr ? QrPayload::decode($qr) : [];
    }
}
