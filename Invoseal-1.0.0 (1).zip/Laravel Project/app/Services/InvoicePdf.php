<?php

namespace App\Services;

use App\Models\Invoice;
use Mpdf\Mpdf;

/**
 * Printable invoice as PDF/A-3b with the signed XML embedded as an associated file
 * (the "hybrid" invoice format: a human-readable page plus the machine-readable original).
 * Arabic text is shaped and laid out right-to-left by mPDF.
 */
class InvoicePdf
{
    public function render(Invoice $invoice): string
    {
        $invoice->loadMissing('company', 'lines', 'egsUnit');

        $tmp = storage_path('app/mpdf');
        if (! is_dir($tmp)) {
            @mkdir($tmp, 0775, true);
        }
        $xmlPath = $tmp.'/'.$invoice->uuid.'.xml';
        file_put_contents($xmlPath, $invoice->finalXml());

        try {
            $mpdf = new Mpdf([
                'mode' => 'utf-8',
                'format' => 'A4',
                'tempDir' => $tmp,
                'default_font' => 'dejavusans',
                'autoScriptToLang' => true,
                'autoLangToFont' => true,
                'margin_left' => 12, 'margin_right' => 12, 'margin_top' => 12, 'margin_bottom' => 14,
                'PDFA' => true,
                'PDFAauto' => true,
                'PDFAversion' => '3-B',
            ]);
            $mpdf->SetTitle($invoice->invoice_number.' - '.$invoice->company->name);
            $mpdf->SetAuthor($invoice->company->name);
            $mpdf->SetCreator('Invoseal');
            $mpdf->SetAssociatedFiles([[
                'name' => $invoice->invoice_number.'.xml',
                'mime' => 'text/xml',
                'description' => 'ZATCA UBL 2.1 invoice',
                'AFRelationship' => 'Alternative',
                'path' => $xmlPath,
            ]]);
            $mpdf->WriteHTML(view('invoice.pdf', [
                'i' => $invoice,
                'c' => $invoice->company,
                'qr' => $invoice->qr_code,
            ])->render());

            return $mpdf->Output('', 'S');
        } finally {
            @unlink($xmlPath);
        }
    }
}
