<?php

namespace App\Services;

use App\Models\Invoice;
use App\Zatca\Validation\Issue;

/** Outcome of an issue attempt: either a stored invoice or a list of blocking issues. */
final class InvoiceResult
{
    /** @param list<Issue> $issues */
    public function __construct(
        public readonly ?Invoice $invoice,
        public readonly array $issues = [],
        public readonly bool $duplicate = false,
    ) {}

    public function ok(): bool
    {
        return $this->invoice !== null;
    }

    /** @return list<Issue> */
    public function blocking(): array
    {
        return array_values(array_filter($this->issues, fn (Issue $i) => $i->blocking));
    }

    /** @return list<array{code:string,field:string,severity:string,message:string}> */
    public function issuesArray(?string $locale = null): array
    {
        return array_map(fn (Issue $i) => $i->toArray($locale), $this->issues);
    }
}
