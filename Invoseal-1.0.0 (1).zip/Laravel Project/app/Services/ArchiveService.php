<?php

namespace App\Services;

use App\Models\Invoice;
use Illuminate\Support\Facades\Storage;

/**
 * Immutable file archive of every invoice (signed XML, plus the ZATCA-cleared copy when there is one).
 * The database holds the same XML; the archive is the copy an auditor can browse on disk or back up separately.
 */
class ArchiveService
{
    public function path(Invoice $invoice, string $suffix = 'xml'): string
    {
        $d = $invoice->issue_date;

        return sprintf('archive/%s/%s/%s/%s.%s', $invoice->company->uuid, $d->format('Y'), $d->format('m'), $invoice->uuid, $suffix);
    }

    public function store(Invoice $invoice): void
    {
        $disk = Storage::disk(config('invoseal.archive_disk'));
        $disk->put($this->path($invoice), $invoice->signed_xml);
        if ($invoice->cleared_xml) {
            $disk->put($this->path($invoice, 'cleared.xml'), $invoice->cleared_xml);
        }
    }

    /** Re-hash and re-verify the stored XML; used by the "verify integrity" action. */
    public function verify(Invoice $invoice): array
    {
        $signer = new \App\Zatca\Crypto\InvoiceSigner();
        $checks = $signer->verify($invoice->signed_xml);
        $checks['stored_hash_matches'] = hash_equals($invoice->invoice_hash, $signer->invoiceHash($invoice->signed_xml));
        $disk = Storage::disk(config('invoseal.archive_disk'));
        $path = $this->path($invoice);
        $checks['archive_file_matches'] = $disk->exists($path) && hash_equals(hash('sha256', $invoice->signed_xml), hash('sha256', (string) $disk->get($path)));

        return $checks;
    }
}
