<?php

namespace App\Services;

use App\Enums\InvoiceStatus;
use App\Models\Company;
use App\Models\EgsUnit;
use App\Models\Invoice;
use App\Zatca\Calculator;
use App\Zatca\Crypto\InvoiceSigner;
use App\Zatca\Dto\InvoiceData;
use App\Zatca\Dto\Line;
use App\Zatca\Dto\Party;
use App\Zatca\Validation\InvoiceValidator;
use App\Zatca\Validation\Issue;
use App\Zatca\Xml\UblInvoiceBuilder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

/**
 * The heart of the gateway: payload -> validated, numbered, hash-chained, signed invoice that is
 * stored and handed to the submission queue.
 */
class InvoiceService
{
    public function __construct(
        private readonly InvoiceValidator $validator,
        private readonly Calculator $calculator,
        private readonly UblInvoiceBuilder $builder,
        private readonly InvoiceSigner $signer,
        private readonly SubmissionService $submissions,
    ) {}

    /** @param array<string,mixed> $p */
    public function issue(Company $company, array $p, ?EgsUnit $egs = null): InvoiceResult
    {
        // Idempotency: the same external_reference always returns the same invoice.
        $ref = isset($p['external_reference']) && $p['external_reference'] !== '' ? (string) $p['external_reference'] : null;
        if ($ref !== null && ($existing = Invoice::where('company_id', $company->id)->where('external_reference', $ref)->first())) {
            return new InvoiceResult($existing, [], true);
        }

        $data = $this->toData($company, $p);
        $issues = $this->validator->validate($data);

        $egs ??= $this->pickUnit($company, $p, $data);
        if (! $egs) {
            $issues[] = new Issue('NO_ACTIVE_EGS', 'egs_unit');
        } elseif (! $egs->isActive()) {
            $issues[] = new Issue('EGS_NOT_ACTIVE', 'egs_unit');
        } elseif (! $this->unitAllows($egs, $data)) {
            $issues[] = new Issue('EGS_TYPE_NOT_ALLOWED', 'type');
        }
        if (Invoice::where('company_id', $company->id)->where('invoice_number', $data->number)->exists()) {
            $issues[] = new Issue('DUPLICATE_NUMBER', 'invoice_number');
        }
        if (array_filter($issues, fn (Issue $i) => $i->blocking)) {
            return new InvoiceResult(null, $issues);
        }

        try {
            $invoice = DB::transaction(fn () => $this->persist($company, $egs, $data, $p, $ref));
        } catch (Throwable $e) {
            report($e);
            $issues[] = new Issue('SIGNING_FAILED', 'egs_unit', true, ['detail' => $e->getMessage()]);

            return new InvoiceResult(null, $issues);
        }

        AuditLogger::log('invoice.issued', $invoice, ['number' => $invoice->invoice_number, 'type' => $invoice->type], $company);

        if (config('invoseal.submission_mode') === 'sync') {
            $this->submissions->submit($invoice);
            $invoice->refresh();
        } else {
            \App\Jobs\SubmitInvoiceJob::dispatch($invoice->id)->afterCommit();
        }

        return new InvoiceResult($invoice, array_values(array_filter($issues, fn (Issue $i) => ! $i->blocking)));
    }

    /** Dry run used by the "validate" endpoint and the admin form: no numbers are consumed. */
    public function check(Company $company, array $p): array
    {
        $data = $this->toData($company, $p);
        $issues = $this->validator->validate($data);
        if (Invoice::where('company_id', $company->id)->where('invoice_number', $data->number)->exists()) {
            $issues[] = new Issue('DUPLICATE_NUMBER', 'invoice_number');
        }
        $this->calculator->apply($data);

        return ['issues' => $issues, 'totals' => [
            'line_extension' => $data->lineExtension, 'tax_amount' => $data->taxAmount,
            'tax_inclusive' => $data->taxInclusive, 'payable' => $data->payable,
        ]];
    }

    private function persist(Company $company, EgsUnit $egs, InvoiceData $data, array $p, ?string $ref): Invoice
    {
        // Lock the unit row so two concurrent requests can never share an ICV / previous-hash.
        $unit = EgsUnit::whereKey($egs->id)->lockForUpdate()->firstOrFail();
        $data->icv = (int) $unit->last_icv + 1;
        $data->pih = $unit->last_pih ?: InvoiceSigner::firstPreviousHash();
        $data->uuid = (string) Str::uuid();
        $this->calculator->apply($data);

        $xml = $this->builder->build($data);
        $signed = $this->signer->sign($xml, (string) base64_decode((string) $unit->production_certificate, true), (string) $unit->private_key);

        $invoice = Invoice::create([
            'uuid' => $data->uuid,
            'company_id' => $company->id,
            'egs_unit_id' => $unit->id,
            'external_reference' => $ref,
            'invoice_number' => $data->number,
            'type' => $data->type,
            'sub_type' => $data->subType,
            'issue_date' => $data->issueDate,
            'issue_time' => $data->issueTime,
            'supply_date' => $data->supplyDate,
            'currency' => $data->currency,
            'payment_means' => $data->paymentMeans,
            'billing_reference' => $data->billingReference,
            'reason' => $data->reason,
            'note' => $data->note,
            'buyer_name' => $data->buyer->name ?: null,
            'buyer_vat' => $data->buyer->vat,
            'buyer' => $p['buyer'] ?? null,
            'line_extension' => $data->lineExtension,
            'tax_exclusive' => $data->taxExclusive,
            'tax_amount' => $data->taxAmount,
            'tax_inclusive' => $data->taxInclusive,
            'icv' => $data->icv,
            'pih' => $data->pih,
            'invoice_hash' => $signed['hash'],
            'signed_xml' => $signed['xml'],
            'qr_code' => $signed['qr'],
            'status' => InvoiceStatus::Pending,
            'retention_until' => now()->addYears((int) config('invoseal.retention_years'))->toDateString(),
        ]);

        foreach (array_values($data->lines) as $i => $l) {
            $invoice->lines()->create([
                'line_no' => $i + 1,
                'name' => $l->name,
                'quantity' => $l->quantity,
                'unit_code' => $l->unitCode,
                'unit_price' => $l->unitPrice,
                'discount' => $l->discount ?: 0,
                'tax_category' => $l->taxCategory,
                'tax_percent' => $l->taxPercent,
                'exemption_code' => $l->exemptionCode,
                'exemption_reason' => $l->exemptionReason,
                'net' => $l->net,
                'tax' => $l->tax,
                'gross' => $l->gross,
            ]);
        }

        $unit->update(['last_icv' => $data->icv, 'last_pih' => $signed['hash']]);
        (new ArchiveService())->store($invoice);

        return $invoice;
    }

    /** @param array<string,mixed> $p */
    public function toData(Company $company, array $p): InvoiceData
    {
        $buyerArr = is_array($p['buyer'] ?? null) ? $p['buyer'] : [];
        $buyer = Party::fromArray($buyerArr);
        $type = $p['type'] ?? null;
        if (! $type) {
            $type = $buyer->vat ? InvoiceData::TYPE_STANDARD : InvoiceData::TYPE_SIMPLIFIED;
        }

        $tz = new \DateTimeZone('Asia/Riyadh');
        $now = new \DateTimeImmutable('now', $tz);

        return new InvoiceData(
            number: trim((string) ($p['invoice_number'] ?? '')),
            type: (string) $type,
            subType: (string) ($p['sub_type'] ?? InvoiceData::SUB_INVOICE),
            issueDate: (string) ($p['issue_date'] ?? $now->format('Y-m-d')),
            issueTime: (string) ($p['issue_time'] ?? $now->format('H:i:s')),
            seller: $company->toParty(),
            buyer: $buyer,
            lines: array_map(fn ($l) => Line::fromArray((array) $l), array_values((array) ($p['lines'] ?? []))),
            currency: strtoupper((string) ($p['currency'] ?? 'SAR')),
            supplyDate: isset($p['supply_date']) && $p['supply_date'] !== '' ? (string) $p['supply_date'] : null,
            paymentMeans: (string) ($p['payment_means'] ?? '10'),
            billingReference: ($p['billing_reference'] ?? null) ?: null,
            reason: ($p['reason'] ?? null) ?: null,
            note: ($p['note'] ?? null) ?: null,
        );
    }

    private function pickUnit(Company $company, array $p, InvoiceData $data): ?EgsUnit
    {
        $q = EgsUnit::where('company_id', $company->id)->where('status', 'active');
        if (! empty($p['egs_unit'])) {
            $q->where('uuid', $p['egs_unit']);
        }
        if (! empty($p['branch_id'])) {
            $q->where('branch_id', $p['branch_id']);
        }

        return $q->orderBy('id')->get()->first(fn (EgsUnit $u) => $u->isActive() && $this->unitAllows($u, $data))
            ?? $q->orderBy('id')->first();
    }

    private function unitAllows(EgsUnit $u, InvoiceData $d): bool
    {
        $flags = str_pad((string) $u->invoice_types, 2, '0');

        return $d->isStandard() ? ($flags[0] ?? '0') === '1' : ($flags[1] ?? '0') === '1';
    }
}
