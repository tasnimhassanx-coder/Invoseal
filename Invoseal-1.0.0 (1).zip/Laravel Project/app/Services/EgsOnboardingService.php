<?php

namespace App\Services;

use App\Enums\EgsStatus;
use App\Models\EgsUnit;
use App\Zatca\Api\ZatcaClient;
use App\Zatca\Calculator;
use App\Zatca\Crypto\CertificateInfo;
use App\Zatca\Crypto\CsrGenerator;
use App\Zatca\Crypto\InvoiceSigner;
use App\Zatca\Dto\InvoiceData;
use App\Zatca\Dto\Line;
use App\Zatca\Dto\Party;
use App\Zatca\Xml\UblInvoiceBuilder;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * CSID onboarding: CSR -> compliance CSID (needs the one-time OTP from the ZATCA/Fatoora portal)
 * -> compliance checks on sample invoices -> production CSID.
 */
class EgsOnboardingService
{
    public function __construct(
        private readonly CsrGenerator $csr = new CsrGenerator(),
        private readonly UblInvoiceBuilder $builder = new UblInvoiceBuilder(),
        private readonly InvoiceSigner $signer = new InvoiceSigner(),
        private readonly Calculator $calculator = new Calculator(),
    ) {}

    private function client(EgsUnit $egs): ZatcaClient
    {
        return new ZatcaClient($egs->environment, config('invoseal.zatca_base_url') ?: null, (int) config('invoseal.zatca_timeout'));
    }

    /** Step 1 - generate the secp256k1 key pair and the CSR. */
    public function prepare(EgsUnit $egs): EgsUnit
    {
        $c = $egs->company;
        $out = $this->csr->generate([
            'common_name' => 'EGS-'.$c->vat_number.'-'.Str::upper(Str::substr($egs->uuid, 0, 8)),
            'organization' => $c->name,
            'organizational_unit' => $egs->branch?->name ?: $c->name,
            'vat_number' => $c->vat_number,
            'serial' => $egs->csrSerial(),
            'invoice_types' => $egs->invoice_types,
            'address' => $c->addressLine() ?: 'Saudi Arabia',
            'business_category' => $c->business_category,
            'environment' => $egs->environment,
            'country' => $c->country ?: 'SA',
        ]);
        $egs->update([
            'private_key' => $out['private_key'],
            'csr' => $out['csr'],
            'status' => EgsStatus::CsrReady,
            'compliance_certificate' => null, 'compliance_secret' => null, 'compliance_request_id' => null,
            'production_certificate' => null, 'production_secret' => null, 'production_request_id' => null,
            'compliance_results' => null, 'last_icv' => 0, 'last_pih' => null,
        ]);
        AuditLogger::log('egs.csr_generated', $egs, [], $c);

        return $egs;
    }

    /** Step 2 - exchange the CSR + OTP for a compliance CSID. */
    public function requestComplianceCertificate(EgsUnit $egs, string $otp): EgsUnit
    {
        if (! $egs->csr) {
            throw new RuntimeException(__('invoseal.onboarding.need_csr'));
        }
        $res = $this->client($egs)->requestComplianceCsid($egs->csr, trim($otp));
        if (! $res->accepted() || empty($res->body['binarySecurityToken'])) {
            throw new RuntimeException($this->failure($res->errors()[0]['message'] ?? ($res->body['message'] ?? $res->transportError ?? 'HTTP '.$res->status)));
        }
        $egs->update([
            'compliance_certificate' => $res->body['binarySecurityToken'],
            'compliance_secret' => $res->body['secret'] ?? null,
            'compliance_request_id' => (string) ($res->body['requestID'] ?? ''),
            'status' => EgsStatus::ComplianceIssued,
        ]);
        AuditLogger::log('egs.compliance_csid', $egs, [], $egs->company);

        return $egs;
    }

    /**
     * Step 3 - ZATCA requires sample invoices of every type the unit will issue to pass its compliance check.
     *
     * @return list<array{label:string,passed:bool,status:int,messages:list<string>}>
     */
    public function runComplianceChecks(EgsUnit $egs): array
    {
        if (! $egs->compliance_certificate) {
            throw new RuntimeException(__('invoseal.onboarding.need_compliance_csid'));
        }
        $flags = str_pad((string) $egs->invoice_types, 2, '0');
        $types = array_filter([
            ($flags[0] ?? '0') === '1' ? InvoiceData::TYPE_STANDARD : null,
            ($flags[1] ?? '0') === '1' ? InvoiceData::TYPE_SIMPLIFIED : null,
        ]);

        $results = [];
        $icv = 0;
        $pih = InvoiceSigner::firstPreviousHash();
        $client = $this->client($egs);
        $cert = (string) base64_decode((string) $egs->compliance_certificate, true);

        foreach ($types as $type) {
            foreach ([InvoiceData::SUB_INVOICE, InvoiceData::SUB_CREDIT, InvoiceData::SUB_DEBIT] as $sub) {
                $data = $this->sample($egs, $type, $sub, ++$icv, $pih);
                $signed = $this->signer->sign($this->builder->build($data), $cert, (string) $egs->private_key);
                $pih = $signed['hash'];
                $res = $client->complianceCheck((string) $egs->compliance_certificate, (string) $egs->compliance_secret, $signed['xml'], $signed['hash'], (string) $data->uuid);

                $ok = $res->accepted() && ($res->errors() === []);
                $results[] = [
                    'label' => __('invoseal.onboarding.sample', ['type' => __('invoseal.types.'.$type), 'sub' => __('invoseal.sub_types.'.$sub)]),
                    'passed' => $ok,
                    'status' => $res->status,
                    'messages' => array_map(fn ($m) => trim(($m['code'] ? $m['code'].': ' : '').$m['message']), array_merge($res->errors(), $res->warnings())),
                ];
            }
        }

        $all = $results !== [] && ! in_array(false, array_column($results, 'passed'), true);
        $egs->update(['compliance_results' => $results, 'status' => $all ? EgsStatus::CompliancePassed : $egs->status]);
        AuditLogger::log('egs.compliance_checked', $egs, ['passed' => $all], $egs->company);

        return $results;
    }

    /** Step 4 - exchange the passed compliance CSID for the production CSID and go live. */
    public function activate(EgsUnit $egs): EgsUnit
    {
        if ($egs->status !== EgsStatus::CompliancePassed) {
            throw new RuntimeException(__('invoseal.onboarding.need_compliance_passed'));
        }
        $res = $this->client($egs)->requestProductionCsid((string) $egs->compliance_certificate, (string) $egs->compliance_secret, (string) $egs->compliance_request_id);
        if (! $res->accepted() || empty($res->body['binarySecurityToken'])) {
            throw new RuntimeException($this->failure($res->errors()[0]['message'] ?? ($res->body['message'] ?? $res->transportError ?? 'HTTP '.$res->status)));
        }
        $this->installProduction($egs, $res->body);
        AuditLogger::log('egs.activated', $egs, [], $egs->company);

        return $egs;
    }

    /** Renew an expiring production certificate: new key + CSR, authenticated with the current production CSID. */
    public function renew(EgsUnit $egs, string $otp): EgsUnit
    {
        if (! $egs->production_certificate) {
            throw new RuntimeException(__('invoseal.onboarding.need_production'));
        }
        $old = ['key' => $egs->private_key, 'csr' => $egs->csr];
        $out = $this->csr->generate([
            'common_name' => 'EGS-'.$egs->company->vat_number.'-'.Str::upper(Str::substr($egs->uuid, 0, 8)),
            'organization' => $egs->company->name,
            'organizational_unit' => $egs->branch?->name ?: $egs->company->name,
            'vat_number' => $egs->company->vat_number,
            'serial' => $egs->csrSerial(),
            'invoice_types' => $egs->invoice_types,
            'address' => $egs->company->addressLine() ?: 'Saudi Arabia',
            'business_category' => $egs->company->business_category,
            'environment' => $egs->environment,
        ]);
        $res = $this->client($egs)->renewProductionCsid((string) $egs->production_certificate, (string) $egs->production_secret, $out['csr'], trim($otp));
        if (! $res->accepted() || empty($res->body['binarySecurityToken'])) {
            throw new RuntimeException($this->failure($res->errors()[0]['message'] ?? ($res->body['message'] ?? $res->transportError ?? 'HTTP '.$res->status)));
        }
        $egs->update(['private_key' => $out['private_key'], 'csr' => $out['csr']]);
        $this->installProduction($egs, $res->body, resetChain: false);
        AuditLogger::log('egs.renewed', $egs, [], $egs->company);

        return $egs;
    }

    private function installProduction(EgsUnit $egs, array $body, bool $resetChain = true): void
    {
        $cert = CertificateInfo::fromAny((string) base64_decode((string) $body['binarySecurityToken'], true));
        $update = [
            'production_certificate' => $body['binarySecurityToken'],
            'production_secret' => $body['secret'] ?? null,
            'production_request_id' => (string) ($body['requestID'] ?? ''),
            'status' => EgsStatus::Active,
            'certificate_issued_at' => $cert->validFrom,
            'certificate_expires_at' => $cert->validTo,
            'onboarded_at' => now(),
        ];
        if ($resetChain) {
            $update += ['last_icv' => 0, 'last_pih' => null];
        }
        $egs->update($update);
    }

    private function failure(string $msg): string
    {
        return __('invoseal.onboarding.zatca_refused', ['message' => mb_substr($msg, 0, 300)]);
    }

    private function sample(EgsUnit $egs, string $type, string $sub, int $icv, string $pih): InvoiceData
    {
        $c = $egs->company;
        $buyer = $type === InvoiceData::TYPE_STANDARD
            ? new Party('Sample Buyer Co', '399999999800003', '2050010000', 'CRN', 'King Fahd Road', '1234', null, 'Al Olaya', 'Riyadh', '11564')
            : new Party('');
        $now = new \DateTimeImmutable('now', new \DateTimeZone('Asia/Riyadh'));
        $d = new InvoiceData(
            number: 'SAMPLE-'.strtoupper(substr($type, 0, 3)).'-'.strtoupper(substr($sub, 0, 3)).'-'.$icv,
            type: $type, subType: $sub,
            issueDate: $now->format('Y-m-d'), issueTime: $now->format('H:i:s'),
            seller: $c->toParty(), buyer: $buyer,
            lines: [new Line('Sample item', '2', '50.00', '0', 'S', '15')],
            billingReference: $sub === InvoiceData::SUB_INVOICE ? null : 'SAMPLE-ORIGINAL-1',
            reason: $sub === InvoiceData::SUB_INVOICE ? null : 'Compliance check',
        );
        $d->uuid = (string) Str::uuid();
        $d->icv = $icv;
        $d->pih = $pih;

        return $this->calculator->apply($d);
    }
}
