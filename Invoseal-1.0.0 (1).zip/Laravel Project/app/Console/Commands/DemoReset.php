<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class DemoReset extends Command
{
    protected $signature = 'invoseal:demo-reset';

    protected $description = 'Rebuild the demo database with fictional data (only when DEMO_MODE=true)';

    public function handle(): int
    {
        if (! config('invoseal.demo_mode')) {
            $this->error('Refusing to run: DEMO_MODE is not enabled.');

            return self::FAILURE;
        }
        $this->call('migrate:fresh', ['--seed' => true, '--force' => true]);

        return self::SUCCESS;
    }
}
