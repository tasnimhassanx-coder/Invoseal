<?php

namespace App\Console\Commands;

use App\Enums\EgsStatus;
use App\Models\EgsUnit;
use App\Models\User;
use Filament\Notifications\Notification;
use Illuminate\Console\Command;

class CheckCertificates extends Command
{
    protected $signature = 'invoseal:check-certificates';

    protected $description = 'Warn admins about production certificates that expire soon and mark expired units';

    public function handle(): int
    {
        $days = (int) config('invoseal.certificate_warning_days');
        $admins = User::whereIn('role', ['admin', 'manager'])->where('is_active', true)->get();

        EgsUnit::with('company')->where('status', EgsStatus::Active->value)->whereNotNull('certificate_expires_at')->get()
            ->each(function (EgsUnit $u) use ($days, $admins) {
                $left = $u->daysToExpiry();
                if ($left !== null && $left < 0) {
                    $u->update(['status' => EgsStatus::Expired]);
                    $this->error("{$u->company->name} / {$u->name}: certificate expired.");
                } elseif ($left !== null && $left <= $days) {
                    $this->warn("{$u->company->name} / {$u->name}: expires in {$left} day(s).");
                    foreach ($admins as $a) {
                        Notification::make()->warning()
                            ->title(__('invoseal.alerts.cert_expiring', ['unit' => $u->name, 'days' => $left]))
                            ->body($u->company->name)->sendToDatabase($a);
                    }
                }
            });

        return self::SUCCESS;
    }
}
