<?php

namespace App\Console\Commands;

use App\Enums\InvoiceStatus;
use App\Models\Invoice;
use App\Models\User;
use Filament\Notifications\Notification;
use Illuminate\Console\Command;

class AlertOverdueReporting extends Command
{
    protected $signature = 'invoseal:alert-overdue';

    protected $description = 'Warn when simplified invoices are close to missing the 24 hour reporting deadline';

    public function handle(): int
    {
        $hours = (int) config('invoseal.reporting_warning_hours');
        $count = Invoice::where('type', 'simplified')
            ->whereIn('status', [InvoiceStatus::Pending->value, InvoiceStatus::Failed->value])
            ->where('created_at', '<=', now()->subHours($hours))->count();
        if ($count > 0) {
            User::whereIn('role', ['admin', 'manager', 'operator'])->where('is_active', true)->get()
                ->each(fn (User $u) => Notification::make()->danger()
                    ->title(__('invoseal.alerts.reporting_overdue', ['count' => $count]))->sendToDatabase($u));
        }
        $this->info("{$count} invoice(s) near the reporting deadline.");

        return self::SUCCESS;
    }
}
