<?php

namespace App\Console\Commands;

use App\Enums\InvoiceStatus;
use App\Jobs\SubmitInvoiceJob;
use App\Models\Invoice;
use Illuminate\Console\Command;

class RetryPendingInvoices extends Command
{
    protected $signature = 'invoseal:retry-pending {--limit=200}';

    protected $description = 'Queue every pending invoice whose retry time has come (offline mode / ZATCA downtime recovery)';

    public function handle(): int
    {
        $n = 0;
        Invoice::where('status', InvoiceStatus::Pending->value)
            ->where(fn ($q) => $q->whereNull('next_retry_at')->orWhere('next_retry_at', '<=', now()))
            ->orderBy('id')->limit((int) $this->option('limit'))->pluck('id')
            ->each(function ($id) use (&$n) {
                SubmitInvoiceJob::dispatch($id);
                $n++;
            });
        $this->info("Queued {$n} invoice(s).");

        return self::SUCCESS;
    }
}
