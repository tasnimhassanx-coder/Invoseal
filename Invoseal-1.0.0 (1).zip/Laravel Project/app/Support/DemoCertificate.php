<?php

declare(strict_types=1);

namespace App\Support;

use App\Zatca\Crypto\CsrGenerator;

/**
 * Throw-away self-signed secp256k1 certificate shaped like a ZATCA EGS certificate.
 * Used by the demo seeder and the tests only. It is NOT issued by ZATCA and is never accepted by ZATCA.
 */
final class DemoCertificate
{
    /** @return array{private_key:string,certificate:string} */
    public static function make(string $vat = '399999999900003', string $org = 'Demo Company'): array
    {
        $out = (new CsrGenerator())->generate([
            'common_name' => 'TST-886431145-'.$vat,
            'organization' => $org,
            'organizational_unit' => 'Demo',
            'vat_number' => $vat,
            'serial' => '1-Invoseal|2-1.0|3-ed22f1d8-e6a2-1118-9b58-d9a8f11e445f',
            'invoice_types' => '1100',
            'address' => 'RRRD2929',
            'business_category' => 'Supply activities',
            'environment' => 'sandbox',
        ]);

        $conf = tempnam(sys_get_temp_dir(), 'inv-cfg-');
        file_put_contents($conf, "[req]\ndefault_bits=2048\ndistinguished_name=dn\n[dn]\n");
        $key = openssl_pkey_get_private($out['private_key']);
        $csr = openssl_csr_new(['commonName' => 'TST-886431145-'.$vat], $key, ['config' => $conf, 'digest_alg' => 'sha256']);
        $x509 = openssl_csr_sign($csr, null, $key, 365, ['config' => $conf, 'digest_alg' => 'sha256']);
        openssl_x509_export($x509, $pem);
        @unlink($conf);

        return ['private_key' => $out['private_key'], 'certificate' => $pem];
    }
}
