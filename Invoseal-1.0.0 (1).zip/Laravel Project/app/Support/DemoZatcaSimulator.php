<?php

declare(strict_types=1);

namespace App\Support;

use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\Http;

/**
 * DEMO MODE ONLY. Answers the ZATCA gateway calls locally so that a public demo can run the whole flow
 * (onboarding wizard, clearance, reporting) without real credentials, and without contacting ZATCA.
 * Certificates it "issues" are self-signed throw-away certificates for the CSR's own key and are not ZATCA certificates.
 */
final class DemoZatcaSimulator
{
    /** Set by the demo seeder, which installs its own scripted fakes. */
    public static bool $paused = false;

    public static function register(): void
    {
        Http::fake(function (Request $request) {
            if (self::$paused) {
                return null;
            }
            $url = $request->url();
            if (! str_contains($url, 'gw-fatoora.zatca.gov.sa')) {
                return null; // webhooks etc. behave normally
            }
            $path = parse_url($url, PHP_URL_PATH) ?: '';
            $json = $request->data();
            $ok = ['status' => 'PASS', 'infoMessages' => [], 'warningMessages' => [], 'errorMessages' => []];

            if (str_ends_with($path, '/compliance') && $request->method() === 'POST') {
                return Http::response(self::issue((string) ($json['csr'] ?? '')), 200);
            }
            if (str_ends_with($path, '/production/csids')) {
                [$token] = self::basicAuth($request);

                return Http::response(['requestID' => random_int(1000000000, 9999999999), 'dispositionMessage' => 'ISSUED',
                    'binarySecurityToken' => $token, 'secret' => bin2hex(random_bytes(16))], 200);
            }
            if (str_ends_with($path, '/compliance/invoices')) {
                return Http::response(['validationResults' => $ok, 'reportingStatus' => 'REPORTED', 'clearanceStatus' => 'CLEARED'], 200);
            }
            if (str_ends_with($path, '/invoices/clearance/single')) {
                return Http::response(['validationResults' => $ok, 'clearanceStatus' => 'CLEARED', 'clearedInvoice' => $json['invoice'] ?? ''], 200);
            }
            if (str_ends_with($path, '/invoices/reporting/single')) {
                return Http::response(['validationResults' => $ok, 'reportingStatus' => 'REPORTED'], 202);
            }

            return Http::response(['message' => 'Demo simulator: unsupported endpoint'], 404);
        });
    }

    /** @return array<string,mixed> */
    private static function issue(string $csrBase64): array
    {
        $csr = base64_decode($csrBase64, true) ?: '';
        $conf = tempnam(sys_get_temp_dir(), 'inv-sim-');
        file_put_contents($conf, "[req]\ndefault_bits=2048\ndistinguished_name=dn\n[dn]\n");
        $ca = openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']);
        $x509 = @openssl_csr_sign($csr, null, $ca, 365, ['config' => $conf, 'digest_alg' => 'sha256']);
        @unlink($conf);
        if (! $x509) {
            return ['errors' => [['code' => 'Invalid-CSR', 'message' => 'Demo simulator could not read the CSR.']]];
        }
        openssl_x509_export($x509, $pem);
        $body = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $pem);

        return ['requestID' => random_int(1000000000, 9999999999), 'dispositionMessage' => 'ISSUED',
            'binarySecurityToken' => base64_encode($body), 'secret' => bin2hex(random_bytes(16))];
    }

    /** @return array{0:string,1:string} */
    private static function basicAuth(Request $request): array
    {
        $h = $request->header('Authorization')[0] ?? '';
        $decoded = base64_decode(substr($h, 6), true) ?: ':';
        [$user, $pass] = array_pad(explode(':', $decoded, 2), 2, '');

        return [$user, $pass];
    }
}
