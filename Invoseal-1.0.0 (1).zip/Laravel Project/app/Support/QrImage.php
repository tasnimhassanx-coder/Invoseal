<?php

namespace App\Support;

use BaconQrCode\Renderer\Image\SvgImageBackEnd;
use BaconQrCode\Renderer\ImageRenderer;
use BaconQrCode\Renderer\RendererStyle\RendererStyle;
use BaconQrCode\Writer;

/** Server-side QR rendering (SVG), no JavaScript or image extension needed. */
final class QrImage
{
    public static function svg(string $payload, int $size = 220, int $margin = 1): string
    {
        $writer = new Writer(new ImageRenderer(new RendererStyle($size, $margin), new SvgImageBackEnd()));

        return $writer->writeString($payload, 'UTF-8');
    }

    public static function dataUri(string $payload, int $size = 220): string
    {
        return 'data:image/svg+xml;base64,'.base64_encode(self::svg($payload, $size));
    }
}
