# Invoseal — self-hosted ZATCA Phase 2 e-invoicing gateway

> One-time source-code purchase. Runs on **your** server. No per-invoice fees, no SaaS lock-in.

Invoseal sits between your ERP / POS / website and ZATCA's Fatoora platform. Your system posts plain JSON;
Invoseal builds the **UBL 2.1 XML**, chains and **signs** it, creates the **QR**, sends it to **clearance** (B2B) or
**reporting** (B2C), retries when ZATCA is down, archives everything for 6+ years and shows it all in a clean
admin panel.

**Built for** Saudi businesses that run their own software, ERP / accounting vendors who need a ready Phase 2
integration, and agencies delivering e-invoicing projects to several clients (multi-company out of the box).

**Stack:** Laravel 12 · Filament 4 admin panel · MySQL 8 / MariaDB · PHP 8.3 · Docker or plain VPS.

![Dashboard](docs/screenshots/02-dashboard.png)

## Modules / features

| Module | What you get |
|---|---|
| **REST API** | `POST /api/v1/invoices`, validate (dry-run), list, detail, XML, PDF, retry. Bearer API keys with abilities, IP allowlist (CIDR), per-key rate limit, idempotency via `external_reference`. OpenAPI spec in `docs/openapi.yaml`. |
| **UBL 2.1 XML** | Standard / simplified invoices, credit and debit notes, tax categories S / Z / E / O with ZATCA exemption codes, line discounts, SAR. |
| **Signing & QR** | Invoice hash chain (ICV / PIH per EGS unit), ECDSA secp256k1 signature, XAdES SignedProperties, 9-tag TLV QR code, UUID. |
| **Clearance / reporting** | B2B → clearance, B2C → reporting, picked automatically. Cleared XML from ZATCA is stored and served. |
| **CSID onboarding wizard** | Generate keys + CSR → compliance certificate (OTP) → compliance checks → production certificate, in four clicks. Renewal. Expiry alerts. |
| **Plain-language validation** | 36 pre-checks before anything is sent to ZATCA, with messages in **English, বাংলা and العربية**. |
| **Retry queue** | ZATCA down? The invoice is kept as *pending* and retried with back-off; overdue-24h-reporting alerts. Replay from the panel or API. |
| **Archive** | Immutable invoices (cannot be deleted during the retention period), signed XML + bilingual **PDF/A-3** with the XML embedded, integrity check button. |
| **Dashboard** | Today / month totals, acceptance rate, 14-day trend, items needing attention, certificate health. Light and dark mode. |
| **Multi-company / branch** | Many sellers, branches and EGS units in one install; users see only their companies. |
| **Webhooks** | `invoice.cleared / reported / rejected / failed`, HMAC-signed, retried, redeliver from the panel. |
| **Security** | Private keys & secrets encrypted at rest (APP_KEY), roles (admin / manager / operator / viewer), audit log, hashed API keys, login rate-limiting, policies on every write. |
| **Deploy** | `docker-compose.yml` (nginx + php-fpm + queue + scheduler + MySQL) or a classic VPS. |

More screenshots are in [`docs/screenshots/`](docs/screenshots) (1920×1080, light and dark).

| | |
|---|---|
| ![Invoices](docs/screenshots/03-invoices.png) | ![Invoice](docs/screenshots/04-invoice-detail.png) |
| ![New invoice](docs/screenshots/05-new-invoice.png) | ![Onboarding](docs/screenshots/06-csid-onboarding.png) |

## Quick start

```bash
cd "Laravel Project"
composer install --no-dev -o && npm ci && npm run build
cp .env.example .env && php artisan key:generate      # then edit DB_* in .env
php artisan migrate --seed                            # creates the admin (see HowToSetup.md)
php artisan serve                                     # → http://127.0.0.1:8000/admin
```

Full instructions for **VPS (Nginx + PHP-FPM + Supervisor + cron)** and **Docker** are in [`HowToSetup.md`](HowToSetup.md).
Try everything with fictional data: `DEMO_MODE=true php artisan migrate:fresh --seed` (login `admin@invoseal.test` / `password`).

A minimal API call:

```bash
curl -X POST https://invoseal.example.com/api/v1/invoices \
  -H "Authorization: Bearer $INVOSEAL_KEY" -H "Content-Type: application/json" \
  -d '{"invoice_number":"INV-1001","lines":[{"name":"Notebook","quantity":2,"unit_price":50}]}'
```

## What is in this package

```
README.md  HowToSetup.md  CLAUDE.md  CHANGELOG.md  LICENSE-NOTE.md
docker-compose.yml  docker/           Docker stack
database/schema.sql  database/seed.sql  (also inside "Laravel Project/database/")
docs/                               OpenAPI, architecture, ZATCA onboarding, webhooks, security, screenshots
Laravel Project/                    the application (source, migrations, tests, composer.lock, package-lock.json)
```

## Quality

* 41 automated tests (signing/hash/QR/TLV, invoice pipeline, API auth and isolation, PDF/A-3, admin-panel roles and company scoping, the full onboarding wizard against a simulated ZATCA).
* `composer.lock` and `package-lock.json` are committed.
* No credentials in the source. Demo data is fictional.

## Please read: ZATCA compliance status

Invoseal implements ZATCA's published Phase 2 technical specification (UBL 2.1 profile, hash chain, ECDSA signature,
XAdES, TLV QR, CSID flow, clearance/reporting APIs). It was developed and tested **offline**: the signing and XML are
self-verified (hash, signature, SignedProperties digest, QR round-trip) and the ZATCA HTTP flow is covered with simulated
responses. **Before you go live, run your onboarding against ZATCA's Developer Portal sandbox and the Simulation environment**
(the wizard does exactly this) and validate sample invoices with ZATCA's SDK. Details and known limits are in
[`LICENSE-NOTE.md`](LICENSE-NOTE.md) and [`docs/zatca-onboarding.md`](docs/zatca-onboarding.md).

Known limits of v1.0: SAR only (no foreign-currency invoices), no document-level discount (use line discounts), admin
panel is English (validation messages are EN/BN/AR), PDF layout is fixed (A4, bilingual).

## Licence

Commercial one-time licence — see [`LICENSE-NOTE.md`](LICENSE-NOTE.md).
